# Documento de Requisitos do Produto (PRD)
# CIP Shopee - Centro de Inteligência Pardal

## 1. Visão Geral do Produto

O CIP Shopee (Centro de Inteligência Pardal) é uma solução SaaS avançada para vendedores da plataforma Shopee que funciona como um centro de inteligência completo, automatizando e otimizando tarefas operacionais através de IA. O sistema oferece funcionalidades de otimização de anúncios com conteúdo pronto para uso (copy e cola), criação de novos anúncios, análise contínua da loja com recomendações acionáveis, e um centro de notícias e eventos para maximizar oportunidades de vendas.

## 2. Público-alvo

- Vendedores individuais da Shopee sobrecarregados com tarefas operacionais
- Pequenos e médios negócios com recursos limitados para marketing e otimização
- Empreendedores que buscam escalar suas operações rapidamente
- Profissionais de e-commerce que gerenciam múltiplas lojas

## 3. Problemas a Serem Resolvidos

- Tempo excessivo gasto na criação e otimização manual de anúncios
- Incerteza sobre quais aspectos da loja precisam de melhorias prioritárias
- Dificuldade em criar textos persuasivos e otimizados para SEO
- Perda de oportunidades promocionais por falta de informação atualizada
- Gestão ineficiente de campanhas publicitárias
- Dificuldade em acompanhar e reagir à concorrência

## 4. Plano de Implementação Faseada

### Fase 1: MVP Essencial (1-2 meses)
- Sistema de login/senha
- Otimizador de anúncios "copy e cola" via web scraping
- Criador de anúncios básico
- Gerenciador de anúncios simples
- Dashboard analítico simplificado
- Centro de notícias básico
- Estrutura de abstração de dados para futura migração para API

### Fase 2: Aprimoramentos (3-4 meses após lançamento)
- Templates e modelos para criação de anúncios
- Análise de concorrência básica
- Dashboard analítico aprimorado com mais métricas
- Alertas por categoria de produto
- Guias para eventos principais
- **Iniciar processo de solicitação de acesso à API da Shopee**
- **Implementação de sistema de cache para reduzir carga de scraping**

### Fase 3: Transição para API e Funcionalidades Avançadas (5-8 meses)
- **Migração gradual de web scraping para API Shopee onde disponível**
- **Implementação de camada de abstração para coexistência de fontes de dados**
- Dashboard analítico completo com todas as métricas
- Centro de notícias inteligente personalizado
- Sistema de pontos e benefícios para retenção
- **Novas funcionalidades possibilitadas pela API oficial**

### Fase 4: Escala Completa (9+ meses)
- **Integração completa com API da Shopee**
- **Otimização de performance e escalabilidade**
- **Expansão para outros marketplaces**
- Funcionalidades avançadas e análise preditiva
- **Possíveis integrações com outros sistemas do vendedor**

## 5. Funcionalidades Detalhadas

### 5.1 Otimizador de Anúncios "Copy e Cola"
- Input simples: URL do anúncio existente
- Análise automática e geração de pacote completo:
  - Título otimizado para SEO (pronto para copy e cola)
  - Descrição persuasiva (pronta para copy e cola)
  - Sugestões de preço competitivo
  - Palavras-chave otimizadas 
  - Sugestões de melhoria geral
- Interface com botões para copiar cada elemento ou todo o pacote
- **Fonte de dados: Web scraping (Fase 1-2), API Shopee (Fase 3+)**

### 5.2 Criador de Anúncios Completos
- Interface simples: "O que deseja vender?"
- Geração automática de anúncio completo:
  - Título otimizado para SEO e conversão
  - Descrição detalhada e persuasiva
  - Variações de produto (cores, tamanhos, etc.)
  - Sugestão de categoria ideal
  - Especificações técnicas organizadas
- Tudo pronto para copiar e colar diretamente na Shopee
- **Possibilidade futura: Publicação direta via API (Fase 3+)**

### 5.3 Dashboard Analítico da Loja
- Score de saúde da loja (0-100)
- Métricas-chave com visualização de tendências:
  - Taxa de conversão
  - Tráfego por produto
  - Posicionamento em buscas
  - Competitividade de preços
  - Performance de anúncios
- Lista priorizada de ações recomendadas
- Alertas para problemas detectados
- Visualização de tendências e comparativos
- **Dados mais precisos e completos via API (Fase 3+)**

### 5.4 Centro de Notícias e Eventos Shopee
- Feed atualizado de campanhas e eventos promocionais
- Calendário visual com datas importantes
- Alertas personalizados para eventos relevantes
- Guias de participação em cada evento
- Estatísticas de desempenho de eventos anteriores
- Sistema de lembretes para datas críticas
- **Fonte de dados: Web scraping (Fase 1-2), API Shopee para datas oficiais (Fase 3+)**

### 5.5 Gerenciador de Anúncios
- Upload e análise de relatórios de campanhas
- Visualização de performance por métrica
- Recomendações para otimização de campanhas:
  - Ajustes de orçamento
  - Palavras-chave a adicionar/remover
  - Melhores horários para anúncios
- Exportação fácil das recomendações
- **Integração direta com campanhas via API (Fase 3+)**

## 6. Experiência de Usuário e Interface

### 6.1 Design Geral
- Interface moderna com elementos de neomorfismo e glassmorphism
- Sistema de cores:
  - Principal: Azul royal profundo (#1a3a8f)
  - Secundária: Laranja vibrante (#ff6b35)
  - Acentos: Verde-água, vermelho suave e roxo profundo
- Tipografia clara e moderna
- Elementos animados sutis que transmitem "inteligência em ação"
- Modos claro/escuro
- Design responsivo para todas as plataformas
- **Indicadores de fonte de dados (Scraping/API) para transparência**

### 6.2 Dashboard Principal
- Visualização central do score da loja
- Widgets personalizáveis
- Alertas prominentes para ações prioritárias
- Acesso rápido a todas as ferramentas
- **Status do sistema mostrando disponibilidade de API**

### 6.3 Navegação e Fluxos
- Máximo 2-3 cliques para qualquer ação importante
- Processos guiados para tarefas complexas
- Interface intuitiva com feedback visual para todas as ações
- Sistema de tooltips contextuais para orientação

## 7. Sistema SaaS e Modelo de Negócio

### 7.1 Planos e Preços
- **Plano Gratuito**: Funcionalidades limitadas (3 produtos/mês)
- **Plano Essencial**: R$ 97/mês - Acesso a todas as ferramentas básicas
- **Plano Plus**: R$ 147/mês - Recursos avançados e análises detalhadas
- **Plano Business**: R$ 297/mês - Recursos avançados, API prioritária e suporte VIP (Fase 3+)

### 7.2 Estratégias de Retenção
- Dashboard analítico que se torna mais valioso com o tempo
- Histórico de dados e análises comparativas exclusivas
- Programa de pontos por ação realizada no sistema
- Benefícios progressivos com a permanência
- Desconto significativo para pagamento anual
- **Benefícios exclusivos para usuários de longo prazo**

## 8. Requisitos Técnicos

### 8.1 Arquitetura
- Frontend: Next.js com Tailwind CSS
- Backend: Node.js/Express
- Banco de dados: PostgreSQL
- IA: Integrações com OpenAI/Claude
- Hosting: Railway (inicial) com possibilidade de migração
- **Camada de abstração para fontes de dados (Scraping/API)**
- **Sistema de cache para reduzir carga e melhorar performance**

### 8.2 Estratégia de Dados e Integrações

#### 8.2.1 Fase Inicial (Web Scraping)
- Web scraping da Shopee para anúncios e concorrência
- Processamento de uploads de relatórios
- Armazenamento e análise de dados históricos
- Sistema de proxy e rotação de IPs para evitar bloqueios
- Mecanismos de retry e fallback para garantir confiabilidade

#### 8.2.2 Transição para API Shopee
- Processo de solicitação de acesso à API oficial
- Implementação gradual começando por endpoints de menor restrição
- Camada de serviço abstrata permitindo uso de qualquer fonte
- Fallback automático para scraping quando necessário
- Sistema de limitação de taxa para respeitar quotas da API

#### 8.2.3 Fase Avançada (API Completa)
- Utilização completa da API onde disponível
- Mecanismos de sincronização em tempo real
- Integração direta para publicação e edição de anúncios
- Webhooks para atualizações em tempo real
- Otimização de uso de quota API

## 9. Métricas de Sucesso

### Fase 1 (MVP)
- 200+ usuários ativos mensais em 3 meses
- Taxa de conversão gratuito para pago: 15%
- NPS (Net Promoter Score) mínimo de 40
- Redução média de 80% no tempo de criação/otimização de anúncios

### Fase 2 e 3
- Retenção de 70%+ após 3 meses
- 1000+ usuários pagantes em 12 meses
- Crescimento médio de 25% nas métricas dos vendedores
- Aumento progressivo de usuários do plano plus
- **Aprovação para acesso à API da Shopee**

### Fase 4
- Escala de 5.000+ usuários ativos
- Expansão para pelo menos um marketplace adicional
- **95%+ de confiabilidade dos dados via API**
- Tempo de resposta do sistema abaixo de 2 segundos para 99% das operações

## 10. Diferencial Competitivo

- **Experiência "copy e cola"**: Resultados prontos para uso imediato
- **Dashboard analítico exclusivo**: Visão completa da saúde da loja
- **Inteligência em tempo real**: Alertas e recomendações proativas
- **Centro de notícias integrado**: Nunca perca oportunidades promocionais
- **Interface premium**: Design avançado e intuitivo
- **Estratégia híbrida de dados**: Garantia de funcionamento com ou sem API

## 11. Riscos e Mitigações

### 11.1 Riscos Relacionados à Fonte de Dados
- **Risco**: Mudanças na estrutura do site Shopee afetando scraping
  - **Mitigação**: Sistema de alerta para detecção de mudanças e time de atualização rápida
  
- **Risco**: Bloqueio de IPs durante scraping
  - **Mitigação**: Sistema de rotação de IPs, limites de requisição, comportamento humano simulado

- **Risco**: Negação de acesso à API oficial da Shopee
  - **Mitigação**: Manter scraping como solução viável de longo prazo; foco em benefícios mútuos para Shopee

- **Risco**: Limitações de uso da API
  - **Mitigação**: Sistema de cache eficiente; estratégia híbrida de uso de dados

### 11.2 Outros Riscos
- **Risco**: Mudanças na plataforma Shopee
  - **Mitigação**: Monitoramento constante e atualizações rápidas
  
- **Risco**: Escalabilidade
  - **Mitigação**: Arquitetura preparada para crescimento com custos controlados
  
- **Risco**: Retenção de usuários
  - **Mitigação**: Recursos específicos para demonstração contínua de valor

## 12. Roadmap de Longo Prazo

- Integração com múltiplos marketplaces além da Shopee
- Módulo avançado de análise competitiva
- Sistema de automação para participação em eventos
- IA personalizada por nicho de produto
- Aplicativo móvel com notificações em tempo real
- **Programa de parceiros oficiais Shopee (se disponível)**
- **Expansão para APIs de outros marketplaces regionais**
- **Integração com sistemas ERP e gestão de estoque**
