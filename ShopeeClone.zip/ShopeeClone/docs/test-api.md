# Documentação para Testes da API

## 1. Testando o processamento de respostas do OpenAI Assistant

Endpoint: `POST /api/test-assistant-response`

Este endpoint recebe uma resposta simulada do OpenAI Assistant e retorna o resultado do processamento.

### Exemplo de requisição:

```json
{
  "assistantResponse": {
    "recommendations": [
      "Otimize suas imagens para melhorar a qualidade visual",
      "Adicione mais palavras-chave relevantes nos títulos",
      "Responda às perguntas dos clientes em menos de 24 horas",
      "Atualizar preços para ficar mais competitivo"
    ],
    "fullAnalysis": "Sua loja está com desempenho razoável, mas pode melhorar significativamente em algumas áreas. As imagens dos produtos precisam de melhor qualidade e os títulos carecem de palavras-chave relevantes. A taxa de resposta às perguntas dos clientes está abaixo do ideal e os preços estão ligeiramente acima da média do mercado.",
    "data": {
      "score": 68,
      "issues": [
        "Qualidade de imagem baixa",
        "Poucas palavras-chave nos títulos",
        "Tempo de resposta lento"
      ],
      "suggestions": [
        "Use imagens de alta resolução",
        "Inclua 5-7 palavras-chave relevantes",
        "Configure notificações para responder rapidamente"
      ]
    },
    "products": [
      {
        "title": "Fone de Ouvido Bluetooth",
        "description": "Fone de ouvido sem fio com cancelamento de ruído",
        "price": 149.99,
        "category": "Eletrônicos",
        "shopeeUrl": "https://shopee.com.br/product/12345678/98765432",
        "keywords": ["bluetooth", "fone", "sem fio", "cancelamento"],
        "optimization": {
          "title": "Fone de Ouvido Bluetooth TWS com Cancelamento de Ruído Ativo - 40h Bateria",
          "description": "Fone de ouvido sem fio com tecnologia Bluetooth 5.2, cancelamento ativo de ruído (ANC), resistência à água IPX5, estojo carregador com bateria de longa duração de até 40 horas e microfones com redução de ruído para chamadas cristalinas.",
          "price": 159.99,
          "keywords": ["bluetooth", "fone", "sem fio", "cancelamento", "anc", "tws", "ipx5", "à prova d'água", "40h bateria"],
          "improvements": [
            "Adicionar especificações técnicas completas",
            "Mencionar compatibilidade com Android e iOS",
            "Incluir imagens do produto em uso"
          ],
          "estimatedImprovement": 32
        }
      }
    ]
  }
}
```

### Exemplo de resposta:

O sistema processará a resposta do assistente, validará os dados e retornará:

```json
{
  "success": true,
  "original": { ... conteúdo da requisição original ... },
  "processed": {
    "recommendations": [
      "→ Otimize suas imagens para melhorar a qualidade visual",
      "→ Adicione mais palavras-chave relevantes nos títulos",
      "→ Responda às perguntas dos clientes em menos de 24 horas",
      "→ Atualizar preços para ficar mais competitivo"
    ],
    "fullAnalysis": "Sua loja está com desempenho razoável, mas pode melhorar significativamente em algumas áreas. As imagens dos produtos precisam de melhor qualidade e os títulos carecem de palavras-chave relevantes. A taxa de resposta às perguntas dos clientes está abaixo do ideal e os preços estão ligeiramente acima da média do mercado.",
    "data": {
      "score": 68,
      "issues": [
        "Qualidade de imagem baixa",
        "Poucas palavras-chave nos títulos",
        "Tempo de resposta lento"
      ],
      "suggestions": [
        "Use imagens de alta resolução",
        "Inclua 5-7 palavras-chave relevantes",
        "Configure notificações para responder rapidamente"
      ]
    },
    "products": [
      {
        "title": "Fone de Ouvido Bluetooth",
        "description": "Fone de ouvido sem fio com cancelamento de ruído",
        "shopeeUrl": "https://shopee.com.br/product/12345678/98765432",
        "price": 149.99,
        "category": "Eletrônicos",
        "dataSource": "ASSISTANT",
        "keywords": ["bluetooth", "fone", "sem fio", "cancelamento"],
        "optimization": {
          "title": "Fone de Ouvido Bluetooth TWS com Cancelamento de Ruído Ativo - 40h Bateria",
          "description": "Fone de ouvido sem fio com tecnologia Bluetooth 5.2, cancelamento ativo de ruído (ANC), resistência à água IPX5, estojo carregador com bateria de longa duração de até 40 horas e microfones com redução de ruído para chamadas cristalinas.",
          "price": 159.99,
          "keywords": ["bluetooth", "fone", "sem fio", "cancelamento", "anc", "tws", "ipx5", "à prova d'água", "40h bateria"],
          "improvements": [
            "Adicionar especificações técnicas completas",
            "Mencionar compatibilidade com Android e iOS",
            "Incluir imagens do produto em uso"
          ],
          "estimatedImprovement": 32
        }
      }
    ]
  }
}
```

## 2. Processando uma otimização de produto

Endpoint: `POST /api/process-optimization`

Este endpoint aplica otimizações a um produto existente com base na resposta do OpenAI Assistant.

### Exemplo de requisição:

```json
{
  "productId": 3,
  "assistantResponse": {
    "products": [
      {
        "title": "Produto Original",
        "description": "Descrição original",
        "optimization": {
          "title": "Título Otimizado - Mais Atrativo e com Palavras-chave",
          "description": "Descrição otimizada com mais detalhes e informações relevantes para o cliente. Inclui características técnicas, benefícios e informações de uso.",
          "price": 159.99,
          "keywords": ["palavra-chave1", "palavra-chave2", "palavra-chave3"],
          "improvements": [
            "Adicionar mais imagens do produto",
            "Incluir um vídeo demonstrativo",
            "Destacar garantia e política de devolução"
          ],
          "estimatedImprovement": 35
        }
      }
    ],
    "recommendations": [
      "Otimize todos os títulos com palavras-chave relevantes",
      "Adicione mais imagens para cada produto",
      "Mantenha os preços competitivos"
    ]
  }
}
```

### Exemplo de resposta:

```json
{
  "success": true,
  "optimization": {
    "id": 5,
    "productId": 3,
    "userId": 1,
    "optimizedTitle": "Título Otimizado - Mais Atrativo e com Palavras-chave",
    "optimizedDescription": "Descrição otimizada com mais detalhes e informações relevantes para o cliente. Inclui características técnicas, benefícios e informações de uso.",
    "suggestedPrice": 159.99,
    "optimizedKeywords": ["palavra-chave1", "palavra-chave2", "palavra-chave3"],
    "generalImprovements": [
      "Adicionar mais imagens do produto",
      "Incluir um vídeo demonstrativo",
      "Destacar garantia e política de devolução"
    ],
    "dataSource": "ASSISTANT",
    "estimatedImprovement": 35,
    "createdAt": "2025-05-10T18:52:34.210Z"
  }
}
```

## 3. Callback do n8n

Endpoint: `POST /api/agent-callback`

Este endpoint recebe dados de execução do n8n após processamento do assistente.

### Exemplo de requisição:

```json
{
  "userId": "1",
  "timestamp": "2025-05-10T12:34:56.789Z",
  "assistantResponse": {
    "recommendations": [
      "Otimize seus títulos com palavras-chave de maior volume de busca",
      "Responda mensagens em até 4 horas para aumentar taxa de conversão",
      "Participe das campanhas sazonais da plataforma"
    ],
    "fullAnalysis": "A análise completa da sua loja indica um bom desempenho geral, mas com oportunidades significativas de melhoria nas áreas de SEO, tempo de resposta e participação em eventos promocionais.",
    "data": {
      "score": 75,
      "issues": [
        "Baixa visibilidade nas buscas",
        "Tempo de resposta acima da média",
        "Baixa participação em eventos"
      ]
    },
    "products": [
      {
        "title": "Produto Exemplo",
        "description": "Descrição do produto exemplo",
        "shopeeUrl": "https://shopee.com.br/product/12345/67890",
        "optimization": {
          "title": "Produto Exemplo Premium - Versão 2023 com Garantia Estendida",
          "description": "Descrição do produto exemplo premium com detalhes completos de materiais, dimensões e instruções de uso. Garantia de 12 meses direto do fabricante.",
          "price": 129.90,
          "keywords": ["premium", "garantia", "versão 2023"],
          "improvements": [
            "Adicionar tabela de especificações",
            "Incluir seção de perguntas frequentes"
          ]
        }
      }
    ]
  }
}
```

### Exemplo de resposta:

```json
{
  "success": true,
  "message": "Callback processado com sucesso",
  "agentId": 2
}
```