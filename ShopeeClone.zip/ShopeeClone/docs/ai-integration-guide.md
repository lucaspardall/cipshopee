# Guia de Integração com o Assistente OpenAI

## Formato de Comunicação JSON Object

O CIP Shopee está configurado para se comunicar com o assistente especializado (asst_cgxU21QjfDBPGEhFm4J3HXU7) usando o formato JSON Object. Este formato facilita o processamento dos dados e garante consistência nas respostas.

### Exemplo de Requisição para Otimização de Produto

A requisição para o assistente segue este formato:

```javascript
const response = await openai.chat.completions.create({
  model: "gpt-4o",
  messages: [
    {
      role: "system",
      content: "Você é um especialista em otimização de anúncios da Shopee seguindo o Método Pardal 10/10."
    },
    {
      role: "user",
      content: `Use o seu conhecimento do Método Pardal 10/10 para otimizar este anúncio da Shopee:
      
      URL: ${productUrl}
      Título: ${originalTitle}
      Descrição: ${originalDescription}
      Preço: R$${originalPrice.toFixed(2)}
      
      Execute a função OTIMIZADOR DE ANÚNCIOS para criar uma versão aprimorada seguindo o Método Pardal 10/10.
      
      REQUISITOS OBRIGATÓRIOS:
      1. Título [máx 120 caracteres]: Aplique a fórmula dos Dossiês Pardal
      2. Descrição: CRIE UMA DESCRIÇÃO DETALHADA E COMPLETA com pelo menos 10-15 linhas
      3. Preços: Calcule o preço sugerido e um preço com desconto
      4. Palavras-chave: Forneça 5-7 palavras-chave de alto volume
      5. Melhorias: Liste 4-6 melhorias específicas em português
      6. Plano de Boost: Crie um "Plano de Boost 7 Dias" com ações táticas específicas
      
      Responda APENAS com o JSON a seguir (sem comentários adicionais)`
    }
  ],
  response_format: { type: "json_object" }
});
```

### Exemplo de Resposta do Assistente

O assistente responderá com um JSON estruturado como este:

```json
{
  "optimizedTitle": "🔥 Sutiã de Amamentação Renda Reforçada Click Fácil - Confortável e Elegante - Frete Grátis",
  "titleJustification": "Aplicada a fórmula científica dos Dossiês Pardal: emoji + palavra-chave principal (Sutiã de Amamentação) + benefícios principais (Renda Reforçada, Click Fácil) + gatilho de urgência (Frete Grátis). Esta estrutura aumenta CTR em 37%.",
  "optimizedDescription": "✨ SUTIÃ DE AMAMENTAÇÃO PREMIUM - CONFORTO E PRATICIDADE\n\nSeja bem-vinda à nossa loja! Este sutiã de amamentação foi desenvolvido especialmente para mamães que buscam conforto sem abrir mão da beleza. 💖\n\n✅ TECIDO PREMIUM: Confeccionado com algodão e elastano de alta qualidade\n✅ FECHO CLICK PRÁTICO: Abertura com uma mão para amamentação fácil\n✅ RENDA REFORÇADA: Detalhes em renda que não deformam com o tempo\n✅ SUSTENTAÇÃO PERFEITA: Alças ajustáveis e reforçadas\n✅ SEM BOJO: Para amamentação natural e saudável\n✅ CONFORTO GARANTIDO: Uso prolongado sem desconforto\n\n🔍 TABELA DE TAMANHOS:\nP - Para busto de 85-90cm\nM - Para busto de 90-95cm\nG - Para busto de 95-100cm\nGG - Para busto de 100-105cm\n\n🚚 FRETE GRÁTIS PARA TODO BRASIL!\n🔒 GARANTIA DE 30 DIAS\n⚡ ENVIO EM ATÉ 24 HORAS ÚTEIS\n\n❓ DÚVIDAS? Estamos à disposição para te ajudar! Entre em contato antes de avaliar.\n\n👶 DICA DE USO: Recomendamos a compra de 3 unidades para rotação durante o período de amamentação, garantindo mais higiene e praticidade no seu dia a dia.\n\n🛒 COMPRE AGORA e tenha a melhor experiência de amamentação com nosso sutiã premium!",
  "descriptionJustification": "Implementado formato escaneável validado pelo Método Pardal 10/10, com blocos bem definidos, cada um começando com emoji estratégico e foco em benefícios específicos. Este formato aumenta o tempo de permanência na página em 42%.",
  "suggestedPrice": 89.90,
  "discountPrice": 79.90,
  "priceJustification": "Preço ajustado seguindo a fórmula de precificação do Método Pardal: valor percebido (+15%) com desconto psicológico (-10%) para criar urgência. Esta estratégia aumenta a taxa de conversão em 31%.",
  "keywords": ["sutiã amamentação", "sutiã maternidade", "lingerie materna", "sutiã abertura fácil", "sutiã renda amamentação", "sutiã confortável amamentação", "sutiã sem bojo"],
  "keywordsJustification": "Palavras-chave selecionadas com base no Dossiê SEO Shopee 2025, focando em termos de alto volume específicos para o nicho materno.",
  "generalImprovements": [
    "Adicione um vídeo demonstrando o fecho click rápido em uso por uma mãe real",
    "Inclua pelo menos 6 fotos, incluindo detalhes da renda e do sistema de abertura",
    "Adicione selo de 'Produto Mais Vendido' para aumentar a confiança",
    "Crie pacotes com desconto para compra de 2 ou mais unidades",
    "Ofereça envio expresso como opção adicional para gestantes de último trimestre",
    "Implemente respostas automáticas para perguntas frequentes em até 5 minutos"
  ],
  "improvementsJustification": "Melhorias recomendadas com base nos 6 pilares de conversão do Método Pardal para produtos maternos.",
  "boostPlan": [
    "Dia 1: Ative cupom de 5% OFF para primeiras 50 compras",
    "Dia 2: Poste 2 stories com depoimentos reais de clientes",
    "Dia 3: Ofereça brinde surpresa para compras acima de R$120",
    "Dia 4: Faça live demonstrando o produto em uso",
    "Dia 5: Crie um anúncio pago com foco em palavras-chave maternas",
    "Dia 6: Envie mensagens personalizadas agradecendo compras recentes",
    "Dia 7: Faça uma campanha relâmpago de 6 horas com frete grátis sem valor mínimo"
  ],
  "justification": "Otimização completa baseada no Método Pardal 10/10, seguindo os princípios validados em mais de 1.200 lojas Shopee no Brasil, com foco especial no nicho materno. Expectativa de aumento de tráfego de 35-40% e aumento de conversão de 25-30% nos primeiros 15 dias após implementação."
}
```

## Instruções para o Assistente

Para garantir a melhor resposta do assistente, a solicitação deve ser clara e específica:

1. **Usar um prompt estruturado**: Explicitar exatamente o que se espera em cada seção da resposta.
2. **Especificar o formato JSON**: Sempre incluir o parâmetro `response_format: { type: "json_object" }` na chamada da API.
3. **Incluir todos os dados necessários**: Fornecer título original, descrição, preço e URL quando disponíveis.
4. **Especificar requisitos do Método Pardal 10/10**: Mencionar explicitamente que o processamento deve seguir este método.

## Processamento das Respostas

O sistema está configurado para:

1. Extrair e processar o JSON retornado
2. Lidar com casos onde o JSON retornado não está completo (utilizando fallbacks)
3. Formatar adequadamente o plano de boost para exibição 
4. Garantir que a descrição otimizada contenha 10-15 linhas com formatação adequada

## Campos Obrigatórios na Resposta

Os seguintes campos são considerados obrigatórios em cada resposta:

- `optimizedTitle`: Título otimizado seguindo a fórmula do Método Pardal
- `optimizedDescription`: Descrição detalhada e completa com emojis e formatação
- `suggestedPrice`: Preço sugerido seguindo a fórmula de precificação
- `discountPrice`: Preço com desconto para criar urgência
- `keywords`: Lista de palavras-chave de alto volume
- `generalImprovements`: Lista de melhorias específicas recomendadas
- `boostPlan`: Plano de 7 dias com ações táticas específicas

Todos os outros campos (justificativas) são recomendados, mas não essenciais para o funcionamento do sistema.