#!/bin/bash
# Script para remover linhas problemáticas do arquivo routes.ts

# 1. Remover linhas soltas após os endpoints (entre route optimizer e optimize-direct)
sed -i '1347,1354d' server/routes.ts

# 2. Remove comentários da linha problemática
echo "Arquivo corrigido!"

