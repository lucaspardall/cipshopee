import pg from 'pg';

const { Pool } = pg;

const pool = new Pool({
  connectionString: 'postgresql://neondb_owner:npg_WmDhf5UX1Mop@ep-shy-flower-a40lz6lh.us-east-1.aws.neon.tech/neondb?sslmode=require'
});

async function addNews() {
  try {
    // Verifica se já existem notícias
    const checkResult = await pool.query('SELECT COUNT(*) FROM news');
    const count = parseInt(checkResult.rows[0].count);
    
    if (count > 0) {
      console.log(`Já existem ${count} notícias no banco de dados. Nada foi adicionado.`);
      return;
    }

    // Adiciona notícias
    const news = [
      {
        title: 'Grande Promoção Shopee 5.5',
        content: 'Prepare seu estoque para a grande promoção 5.5 da Shopee. Inscreva seus produtos e aproveite as taxas promocionais. São esperados milhões de compradores ativos durante o evento.',
        category: 'EVENTS',
        imageUrl: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop',
        url: '/news/promo-55',
        publishDate: new Date()
      },
      {
        title: 'Shopee Anuncia Mudanças no Algoritmo de Busca',
        content: 'A Shopee anunciou hoje mudanças importantes no algoritmo de busca. A partir do próximo mês, produtos com melhores avaliações receberão mais destaque nos resultados de busca. Vendedores devem focar em melhorar a satisfação dos clientes para manter posições de destaque.',
        category: 'PLATFORM',
        imageUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop',
        url: '/news/algoritmo',
        publishDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000) // 2 dias atrás
      },
      {
        title: 'Novas Políticas de Frete para Vendedores',
        content: 'A Shopee está implementando novas políticas de frete que beneficiam vendedores com alto volume de vendas. Vendedores com mais de 100 pedidos mensais receberão subsídios de até 15% no valor do frete. Além disso, o programa de frete grátis está sendo reformulado para melhorar a experiência de compra.',
        category: 'POLICY',
        imageUrl: 'https://images.unsplash.com/photo-1505236858219-8359eb29e329?auto=format&fit=crop',
        url: '/news/frete',
        publishDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) // 5 dias atrás
      },
      {
        title: 'Workshop de Otimização de Anúncios',
        content: 'A Shopee realizará no próximo dia 20 um workshop online gratuito sobre otimização de anúncios. Especialistas da plataforma compartilharão dicas exclusivas sobre keywords, imagens e descrições que geram mais conversões. Vagas limitadas!',
        category: 'EDUCATION',
        imageUrl: 'https://images.unsplash.com/photo-1529651737248-dad5e287768e?auto=format&fit=crop',
        url: '/news/workshop',
        publishDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000) // 1 dia atrás
      },
      {
        title: 'Nova Categoria de Produtos Sustentáveis',
        content: 'A partir do próximo mês, a Shopee lançará uma nova categoria dedicada a produtos sustentáveis e eco-friendly. Vendedores com produtos nesta categoria receberão selo especial e destaque na plataforma. Prepare seus produtos sustentáveis para esta nova oportunidade!',
        category: 'PLATFORM',
        imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop',
        url: '/news/sustentavel',
        publishDate: new Date()
      }
    ];

    // Insere as notícias
    for (const item of news) {
      await pool.query(
        'INSERT INTO news (title, content, category, image_url, url, publish_date) VALUES ($1, $2, $3, $4, $5, $6)',
        [item.title, item.content, item.category, item.imageUrl, item.url, item.publishDate]
      );
    }

    console.log(`${news.length} notícias adicionadas com sucesso!`);
  } catch (error) {
    console.error('Erro ao adicionar notícias:', error);
  } finally {
    await pool.end();
  }
}

addNews();