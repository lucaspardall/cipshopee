import { pgTable, text, serial, integer, boolean, timestamp, json, real, varchar, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for express-session with PostgreSQL)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").unique(),
  name: text("name"),
  profileImageUrl: text("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  
  // Loja Shopee
  shopeeStoreUrl: text("shopee_store_url"),
  storeScore: integer("store_score"),
  
  // Informações do OAuth Shopee
  shopeeApiEnabled: boolean("shopee_api_enabled").default(false),
  shopeeShopId: text("shopee_shop_id"),
  shopeeAccessToken: text("shopee_access_token"),          // Novo
  shopeeRefreshToken: text("shopee_refresh_token"),        // Novo
  shopeeTokenExpiresAt: timestamp("shopee_token_expires_at"), // Novo
  shopeePartnerShopId: text("shopee_partner_shop_id"),     // Novo
  shopeeConnectedAt: timestamp("shopee_connected_at"),     // Novo
  
  // Preferências do usuário
  preferredDataSource: text("preferred_data_source").default("MANUAL"), // Mudou de SCRAPING para MANUAL
  emailNotificationsEnabled: boolean("email_notifications_enabled").default(true),
  
  // Campos legados (manter compatibilidade)
  shopeeApiToken: text("shopee_api_token"),
  shopeeApiRefreshToken: text("shopee_api_refresh_token"),
  shopeeApiExpires: timestamp("shopee_api_expires"),
  
  // Progresso da jornada do vendedor
  sellerJourneyProgress: integer("seller_journey_progress").default(0),    // 0-100 porcentagem de progresso geral
  sellerJourneyStep: integer("seller_journey_step").default(1),            // Etapa atual (1, 2, 3, 4, 5)
  completedJourneySteps: text("completed_journey_steps").array().default(['[]']), // Array de passos concluídos
  lastJourneyUpdate: timestamp("last_journey_update"),                     // Última atualização
  sellerJourneyTier: text("seller_journey_tier").default("novice"),        // Novato, Intermediário, Avançado, Expert
  unlockableFeatures: jsonb("unlockable_features").default({}),            // Features desbloqueáveis no progresso
});

// Products model
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category"),
  price: real("price"),
  shopeeUrl: text("shopee_url"),
  shopeeProductId: text("shopee_product_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  dataSource: text("data_source").default("MANUAL"), // Mudou de SCRAPING para MANUAL
  views: integer("views"),
  sales: integer("sales"),
  conversionRate: real("conversion_rate"),
  searchRanking: integer("search_ranking"),
  performanceScore: integer("performance_score"),
  originalTitle: text("original_title"),
  originalDescription: text("original_description"),
  variations: json("variations"),
  specifications: json("specifications"),
  keywords: text("keywords").array(),
  imageUrl: text("image_url"),
  images: json("images"),
  
  // Novos campos para entrada manual/API
  originalImages: jsonb("original_images"),     // Array de URLs de imagens
  currentSku: text("current_sku"),              // SKU atual do produto
  variationAttributes: jsonb("variation_attributes"), // Lista de variações (cor, tamanho, etc)
  isLive: boolean("is_live").default(true),     // Se o produto está ativo na Shopee
  lastUpdatedFromShopee: timestamp("last_updated_from_shopee"), // Quando foi atualizado da API
});

// Optimizations model
export const optimizations = pgTable("optimizations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  productId: integer("product_id").notNull(),
  optimizedTitle: text("optimized_title"),
  optimizedDescription: text("optimized_description"),
  suggestedPrice: real("suggested_price"),
  discountPrice: real("discount_price"),
  optimizedKeywords: text("optimized_keywords").array(),
  generalImprovements: json("general_improvements"),
  boostPlan: text("boost_plan").array(),
  titleJustification: text("title_justification"),
  descriptionJustification: text("description_justification"),
  priceJustification: text("price_justification"),
  keywordsJustification: text("keywords_justification"),
  improvementsJustification: text("improvements_justification"),
  justification: text("justification"),
  createdAt: timestamp("created_at").defaultNow(),
  dataSource: text("data_source").default("SCRAPING"),
  estimatedImprovement: integer("estimated_improvement")
});

// StoreAnalytics model
export const storeAnalytics = pgTable("store_analytics", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: timestamp("date").defaultNow(),
  lastUpdated: timestamp("last_updated"),
  overallScore: integer("overall_score").notNull(),
  listingQualityScore: integer("listing_quality_score"),
  priceCompetitivenessScore: integer("price_competitiveness_score"),
  marketingEffectivenessScore: integer("marketing_effectiveness_score"),
  customerSatisfactionScore: integer("customer_satisfaction_score"),
  visibilityScore: integer("visibility_score"),
  dataSource: text("data_source").default("SCRAPING"),
  metricsData: json("metrics_data"),
  priorityActions: json("priority_actions"),
  conversionRateScore: integer("conversion_rate_score"),
  performanceIssues: json("performance_issues")
});

// Events model
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  priority: text("priority").default("MEDIUM"),
  category: text("category"),
  imageUrl: text("image_url")
});

// News model
export const news = pgTable("news", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  publishDate: timestamp("publish_date").defaultNow(),
  category: text("category"),
  imageUrl: text("image_url"),
  url: text("url")
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertProductSchema = createInsertSchema(products).omit({ id: true, createdAt: true, updatedAt: true });
export const insertOptimizationSchema = createInsertSchema(optimizations).omit({ id: true, createdAt: true });
export const insertStoreAnalyticsSchema = createInsertSchema(storeAnalytics).omit({ id: true });
export const insertEventSchema = createInsertSchema(events).omit({ id: true });
export const insertNewsSchema = createInsertSchema(news).omit({ id: true, publishDate: true });

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

export type InsertOptimization = z.infer<typeof insertOptimizationSchema>;
export type Optimization = typeof optimizations.$inferSelect;

export type InsertStoreAnalytics = z.infer<typeof insertStoreAnalyticsSchema>;
export type StoreAnalytics = typeof storeAnalytics.$inferSelect;

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

export type InsertNews = z.infer<typeof insertNewsSchema>;
export type News = typeof news.$inferSelect;

// DataSource enum for type safety
export enum DataSourceType {
  SCRAPING = "SCRAPING",
  API = "API",
  AUTO = "AUTO"
}

// Priority enum for events
export enum Priority {
  HIGH = "HIGH",
  MEDIUM = "MEDIUM",
  LOW = "LOW"
}

// Tabela para agentes automatizados
export const agentConfigs = pgTable("agent_configs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  n8nWorkflowId: varchar("n8n_workflow_id", { length: 255 }),
  status: varchar("status", { length: 50 }).default("configuring").notNull(),
  scanFrequency: varchar("scan_frequency", { length: 50 }).default("daily").notNull(),
  storeUrl: varchar("store_url", { length: 255 }),
  notificationEnabled: boolean("notification_enabled").default(true).notNull(),
  optimizationTargets: jsonb("optimization_targets").notNull(),
  useCustomAssistant: boolean("use_custom_assistant").default(false),
  openaiAssistantId: varchar("openai_assistant_id", { length: 255 }),
  lastRun: timestamp("last_run"),
  lastExecutionError: text("last_execution_error"),
  nextScheduledRun: timestamp("next_scheduled_run"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Schema para inserção de agentes
export const insertAgentConfigSchema = createInsertSchema(agentConfigs).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertAgentConfig = z.infer<typeof insertAgentConfigSchema>;
export type AgentConfig = typeof agentConfigs.$inferSelect;
