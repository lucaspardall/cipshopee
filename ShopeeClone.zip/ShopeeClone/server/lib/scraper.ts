import axios from 'axios';
import * as cheerio from 'cheerio';
import { HttpsProxyAgent } from 'https-proxy-agent';

// Lista de proxies públicos, serviços e VPNs que podem ser usados para contornar bloqueios
// Usando proxies públicos conhecidos e confiáveis
const FREE_PROXIES = [
  // Serviços de proxy que podem ser usados sem configuração complexa
  'http://proxy.scrapingbee.com:8886?key=RQEVAI5DVVWPLKRC9Y2NYWH0L92FW9M8CGHBBMXUKP5RHS4ZW1G2NBGNJ7I8HR8MA23DQT4TFFL2OJBQ',
  'http://172.67.181.50:80',     // CloudFlare
  'http://104.26.5.47:80',       // CloudFlare
  'http://104.18.20.226:80',     // CloudFlare 
  'http://193.239.86.249:8080',  // Proxy HTTP aberto
  'http://160.16.84.114:3128',   // Proxy japonês
  'http://52.24.80.96:80',       // AWS
  'http://23.94.59.153:3128',    // Datacenter US
  'http://177.91.111.253:8080',  // Brasil
  'http://186.193.181.204:8080', // Brasil
];

// Obter um proxy aleatório da lista
function getRandomProxy(): string {
  return FREE_PROXIES[Math.floor(Math.random() * FREE_PROXIES.length)];
}

interface ScrapedProduct {
  title: string;
  description: string;
  price: number;
  category?: string;
  images?: string[];
  specifications?: Record<string, string>;
  variations?: Record<string, string[]>;
  shopeeUrl?: string;
}

/**
 * Extracts a product ID from a Shopee URL
 */
function extractShopeeProductId(url: string): { shopId: string; itemId: string } | null {
  try {
    // Formato padrão de URL da Shopee: https://shopee.com.br/product/{shop_id}/{item_id}
    // ou https://shopee.com.br/[product-name]-i.{shop_id}.{item_id}
    const regex1 = /\/product\/(\d+)\/(\d+)/;
    const regex2 = /-i\.(\d+)\.(\d+)/;
    
    let match = url.match(regex1);
    if (match && match.length >= 3) {
      return { shopId: match[1], itemId: match[2] };
    }
    
    match = url.match(regex2);
    if (match && match.length >= 3) {
      return { shopId: match[1], itemId: match[2] };
    }
    
    return null;
  } catch (error) {
    console.error('Error extracting Shopee product ID:', error);
    return null;
  }
}

/**
 * Gera um user agent aleatório para evitar detecção de webscraping
 */
function getRandomUserAgent(): string {
  const userAgents = [
    // Navegadores desktop comuns
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
    'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:123.0) Gecko/20100101 Firefox/123.0',
    // Navegadores móveis
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/118.0.5993.69 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (Linux; Android 13; SM-S901B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
    // Navegadores mais antigos (menos suspeitos)
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15',
    // Bots bons conhecidos (pouco utilizados em bloqueios)
    'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
    'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)'
  ];
  
  return userAgents[Math.floor(Math.random() * userAgents.length)];
}

/**
 * Scrapes product data from Shopee using cheerio
 * Implementação aprimorada com medidas anti-bloqueio
 */
// Função auxiliar para padronizar URLs da Shopee
function normalizeShopeeUrl(inputUrl: string): URL {
  const url = new URL(inputUrl);
  
  // Forçar uso consistente do domínio brasileiro
  if (url.hostname.includes('shopee')) {
    // Se estiver usando qualquer domínio Shopee, padronizar para shopee.com.br
    const originalHostname = url.hostname;
    url.hostname = 'shopee.com.br';
    console.log(`Normalizando domínio: ${originalHostname} -> shopee.com.br`);
  }
  
  return url;
}

export async function scrapeShopeeProduct(url: string): Promise<ScrapedProduct | null> {
  try {
    console.log(`Iniciando processo de scraping para URL: ${url}`);
    
    // Simular um delay variável como comportamento humano (1-3 segundos)
    const humanDelay = Math.floor(Math.random() * 2000) + 1000;
    console.log(`Aguardando ${humanDelay}ms antes de fazer a requisição...`);
    await new Promise(resolve => setTimeout(resolve, humanDelay));
    
    // Normalizar a URL para o domínio padrão da Shopee
    let urlWithParams;
    try {
      urlWithParams = normalizeShopeeUrl(url);
      // Adicionar parâmetros aleatórios típicos de navegação normal em e-commerce
      urlWithParams.searchParams.append('_t', Date.now().toString());
      urlWithParams.searchParams.append('__classic__', '1');
      urlWithParams.searchParams.append('smtt', Math.floor(Math.random() * 10).toString());
      // Adicionar parâmetro para garantir versão desktop
      urlWithParams.searchParams.append('sp_atk', 'uuid-' + Date.now());
      
      console.log(`URL normalizada: ${urlWithParams.toString()}`);
    } catch (e) {
      console.error('Erro ao normalizar a URL:', e);
      // Se falhar, tenta usar a URL original
      urlWithParams = new URL(url);
    }
    
    // Configurar headers para simular um navegador real
    // Muito detalhado para evitar detecção e bloqueio
    const headers = {
      'User-Agent': getRandomUserAgent(),
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
      'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
      'Accept-Encoding': 'gzip, deflate, br',
      'Cache-Control': 'max-age=0',
      'Connection': 'keep-alive',
      'DNT': '1', // Do Not Track
      'Sec-Ch-Ua': '"Chromium";v="118", "Google Chrome";v="118"',
      'Sec-Ch-Ua-Mobile': Math.random() > 0.7 ? '?1' : '?0', // Aleatoriamente móvel ou desktop
      'Sec-Ch-Ua-Platform': Math.random() > 0.6 ? '"Android"' : '"Windows"',
      'Sec-Fetch-Dest': 'document',
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-Site': 'cross-site',
      'Sec-Fetch-User': '?1',
      'Upgrade-Insecure-Requests': '1',
      'Pragma': 'no-cache',
      // Escolher um referente plausível
      'Referer': Math.random() > 0.5 ? 'https://www.google.com/' : 'https://shopee.com.br/search'
    };

    console.log(`Iniciando scraping da URL: ${urlWithParams.toString()}`);
    
    // Implementar sistema de tentativas com diferentes configurações e proxies
    let response;
    let attempts = 0;
    const maxAttempts = 5; // Aumentando para 5 tentativas com os diferentes proxies
    let lastError;
    
    while (attempts < maxAttempts) {
      try {
        console.log(`Tentativa ${attempts + 1} de ${maxAttempts} para URL: ${urlWithParams.toString()}`);
        
        // Adicionar um delay entre tentativas (exceto na primeira)
        if (attempts > 0) {
          const retryDelay = 2000 * attempts; // Backoff exponencial
          console.log(`Aguardando ${retryDelay}ms antes da próxima tentativa...`);
          await new Promise(resolve => setTimeout(resolve, retryDelay));
          
          // Tentar variar o User-Agent em cada nova tentativa
          headers['User-Agent'] = getRandomUserAgent();
        }

        // Configurações para o proxy
        let axiosConfig: any = { 
          headers, 
          timeout: Math.floor(Math.random() * 5000) + 20000, // 20-25 segundos (mais longo para maior chance de sucesso)
          maxRedirects: 5,
          validateStatus: (status: number) => status < 400 // Considerar 3xx como sucesso
        };
        
        // A partir da segunda tentativa, usar proxy
        if (attempts > 0) {
          const proxyUrl = getRandomProxy();
          console.log(`Usando proxy: ${proxyUrl}`);
          
          // Configurar o proxy agent
          const proxyAgent = new HttpsProxyAgent(proxyUrl);
          axiosConfig.httpsAgent = proxyAgent;
          axiosConfig.proxy = false; // Desativar o proxy interno do Axios
          
          // Adicionar headers específicos para melhorar a chance de sucesso
          axiosConfig.headers['Accept-Language'] = 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7';
          axiosConfig.headers['Cache-Control'] = 'no-cache';
          axiosConfig.headers['Pragma'] = 'no-cache';
          axiosConfig.headers['Sec-Ch-Ua'] = '"Google Chrome";v="119", "Chromium";v="119", "Not?A_Brand";v="24"';
          axiosConfig.headers['Sec-Ch-Ua-Mobile'] = '?0';
          axiosConfig.headers['Sec-Ch-Ua-Platform'] = '"Windows"';
          axiosConfig.headers['Sec-Fetch-Dest'] = 'document';
          axiosConfig.headers['Sec-Fetch-Mode'] = 'navigate';
          axiosConfig.headers['Sec-Fetch-Site'] = 'none';
          axiosConfig.headers['Sec-Fetch-User'] = '?1';
          axiosConfig.headers['Upgrade-Insecure-Requests'] = '1';
        }
        
        response = await axios.get(urlWithParams.toString(), axiosConfig);
        
        // Se chegou aqui, a requisição foi bem-sucedida
        console.log(`Tentativa ${attempts + 1} bem-sucedida com status: ${response.status}`);
        
        // Verificar se obtivemos um conteúdo HTML válido
        if (response.data && response.data.includes('<html')) {
          console.log('Conteúdo HTML válido obtido');
          break;
        } else {
          console.warn('Resposta não contém HTML válido, tentando novamente');
          attempts++;
        }
      } catch (error: any) {
        lastError = error;
        console.log(`Erro na tentativa ${attempts + 1}: ${error.message || 'Erro desconhecido'}`);
        attempts++;
        
        // Se for o último erro, registrar mais detalhes
        if (attempts === maxAttempts) {
          console.error('Erro detalhado na última tentativa:', error);
        }
      }
    }
    
    // Se não conseguiu obter resposta após todas as tentativas
    if (!response) {
      throw new Error(`Falha após ${maxAttempts} tentativas: ${lastError?.message || 'Erro desconhecido'}`);
    }
    
    console.log(`Resposta obtida com status: ${response.status}`);
    const $ = cheerio.load(response.data);

    // Extrair informações do script de dados estruturados 
    let structuredData: any = null;
    try {
      // Shopee normalmente inclui dados estruturados em formato JSON-LD
      const scriptTags = $('script[type="application/ld+json"]');
      console.log(`Encontradas ${scriptTags.length} tags script com JSON-LD`);
      
      scriptTags.each((_, element) => {
        try {
          const content = $(element).html();
          if (content) {
            const parsed = JSON.parse(content);
            if (parsed && (parsed['@type'] === 'Product' || (Array.isArray(parsed) && parsed[0]?.['@type'] === 'Product'))) {
              structuredData = Array.isArray(parsed) ? parsed[0] : parsed;
              console.log('Dados estruturados de produto encontrados!');
              return false; // Break the loop
            }
          }
        } catch (error) {
          console.log('Erro ao analisar JSON-LD:', error instanceof Error ? error.message : String(error));
        }
      });
    } catch (error) {
      console.log('Erro ao processar dados estruturados:', error instanceof Error ? error.message : String(error));
    }
    
    // Extrair título do produto com múltiplas estratégias
    let title = '';
    if (structuredData?.name) {
      title = structuredData.name;
      console.log('Título obtido dos dados estruturados:', title);
    } else {
      title = $('meta[property="og:title"]').attr('content') || 
              $('meta[name="title"]').attr('content') || 
              $('title').text() ||
              $('._44qnta').text() ||  // Seletor específico da Shopee
              $('h1').first().text();  // Estratégia genérica - primeiro h1
              
      console.log('Título obtido dos metadados/HTML:', title);
    }
    
    // Extrair descrição do produto com múltiplas estratégias
    let description = '';
    if (structuredData?.description) {
      description = structuredData.description;
      console.log('Descrição obtida dos dados estruturados');
    } else {
      // Tentar vários seletores para descrição - adicionando mais seletores específicos da Shopee
      const selectors = [
        '.product-detail__product-description',
        '.U85vF1',   // Seletor específico da Shopee 
        '.product-detail',
        '[data-testid="pdp-product-description"]',
        '#product-detail',
        '.product-detail-content', // Novo seletor Shopee
        '.product-detail-description', // Novo seletor
        '.detail-content', // Novo seletor
        '.qrm04f', // Novo seletor Shopee
        '.rqoNv1', // Novo seletor Shopee
        '.IpLrFV', // Outro seletor Shopee recente
        '.shopee-product-detail', // Seletor genérico Shopee
        '#description' // Seletor comum
      ];
      
      // Primeiro tentamos com seletores específicos
      for (const selector of selectors) {
        const desc = $(selector).text().trim();
        if (desc && desc.length > 20) { // Assumir que uma descrição válida tem pelo menos 20 caracteres
          description = desc;
          console.log(`Descrição obtida do seletor: ${selector}`);
          break;
        }
      }
      
      // Se não encontrar nos seletores, tentamos encontrar uma div grande que pode conter a descrição
      if (!description) {
        $('div').each((_, element) => {
          const text = $(element).text().trim();
          // Se encontramos um div com bastante texto (mais de 200 caracteres) pode ser a descrição
          if (text.length > 200 && !description) {
            description = text;
            console.log('Descrição obtida via busca em divs grandes');
          }
        });
      }
      
      // Se ainda não encontrar, usar meta tags
      if (!description) {
        description = $('meta[property="og:description"]').attr('content') || 
                     $('meta[name="description"]').attr('content') ||
                     '';
        if (description) console.log('Descrição obtida dos metadados');
      }
      
      // Último recurso: extrair todo o texto do corpo HTML e filtrar
      if (!description) {
        const bodyText = $('body').text();
        // Limpar texto e tentar extrair uma parte significativa
        if (bodyText && bodyText.length > 300) {
          // Pegar um trecho razoável do meio do texto, que frequentemente contém a descrição
          description = bodyText.substring(Math.floor(bodyText.length * 0.3), Math.floor(bodyText.length * 0.7));
          console.log('Descrição obtida de extração de texto do corpo');
        }
      }
    }
    
    // Extrair preço do produto com múltiplas estratégias
    let price = 0;
    if (structuredData?.offers?.price) {
      price = parseFloat(structuredData.offers.price);
      console.log('Preço obtido dos dados estruturados:', price);
    } else {
      // Tentar vários seletores para preço
      const selectors = [
        '.AJyN7v', // Novo seletor Shopee
        '._9CNLW6', // Seletor antigo
        '.productDetail_price',
        '.product-price',
        '[data-testid="pdp-product-price"]',
        '.price_final',
        '.price-current',
        '.current-price'
      ];
      
      let priceText = '';
      for (const selector of selectors) {
        priceText = $(selector).text().trim();
        if (priceText) {
          console.log(`Preço obtido do seletor: ${selector} -> ${priceText}`);
          break;
        }
      }
      
      // Se não encontrar nos seletores, tentar meta tags
      if (!priceText) {
        const metaPrice = $('meta[property="product:price:amount"]').attr('content') || 
                         $('meta[itemprop="price"]').attr('content') || '';
        if (metaPrice) {
          priceText = metaPrice;
          console.log('Preço obtido dos metadados:', priceText);
        }
      }
      
      if (priceText) {
        // Limpar o texto de preço e converter para número
        priceText = priceText.replace(/[^\d,.]/g, '')
                           .replace('.', '')  // Remover separadores de milhar
                           .replace(',', '.'); // Converter vírgula para ponto decimal
        price = parseFloat(priceText);
        console.log('Preço limpo e convertido:', price);
      }
    }
    
    // Extrair categoria do produto
    let category = '';
    if (structuredData?.category) {
      category = structuredData.category;
      console.log('Categoria obtida dos dados estruturados:', category);
    } else {
      category = $('meta[property="product:category"]').attr('content') ||
               $('meta[itemprop="category"]').attr('content') ||
               $('.breadcrumb-item').last().text().trim();
      if (category) console.log('Categoria obtida dos metadados/breadcrumbs:', category);
    }
    
    // Extrair imagens do produto
    const images: string[] = [];
    
    // Tentar obter imagens dos dados estruturados primeiro
    if (structuredData?.image) {
      const imageData = structuredData.image;
      if (typeof imageData === 'string') {
        images.push(imageData);
      } else if (Array.isArray(imageData)) {
        imageData.forEach(img => {
          if (typeof img === 'string') images.push(img);
          else if (img.url) images.push(img.url);
        });
      }
      console.log(`${images.length} imagens obtidas dos dados estruturados`);
    }
    
    // Se não encontrou imagens nos dados estruturados, tentar no HTML
    if (images.length === 0) {
      // Tentar meta tags
      $('meta[property="og:image"]').each((_, element) => {
        const imageUrl = $(element).attr('content');
        if (imageUrl) images.push(imageUrl);
      });
      
      // Tentar divs de galeria de imagens
      $('.product-image img, .product-gallery img, [data-testid="pdp-image-gallery"] img').each((_, element) => {
        const src = $(element).attr('src') || $(element).attr('data-src');
        if (src && !src.includes('placeholder') && !images.includes(src)) {
          images.push(src);
        }
      });
      
      console.log(`${images.length} imagens obtidas do HTML`);
    }
    
    // Extrair especificações do produto
    const specifications: Record<string, string> = {};
    
    // Tentar vários seletores para especificações
    const specSelectors = [
      '.product-detail__item',
      '.product-specifications',
      '.product-attributes',
      '[data-testid="pdp-product-specs"]',
      '.specs-table'
    ];
    
    for (const selector of specSelectors) {
      let foundSpecs = false;
      
      $(selector).each((_, element) => {
        const key = $(element).find('.product-detail__item-key, .spec-name, .attribute-name').text().trim();
        const value = $(element).find('.product-detail__item-val, .spec-value, .attribute-value').text().trim();
        
        if (key && value) {
          specifications[key] = value;
          foundSpecs = true;
        }
      });
      
      if (foundSpecs) {
        console.log(`Especificações obtidas do seletor: ${selector}`);
        break;
      }
    }
    
    // Extrair variações do produto (como cores, tamanhos, etc)
    const variations: Record<string, string[]> = {};
    
    // Tentar vários seletores para variações
    const variationSelectors = [
      '.product-variation__options',
      '.product-options',
      '.product-variants',
      '[data-testid="pdp-product-variations"]'
    ];
    
    for (const selector of variationSelectors) {
      let foundVariations = false;
      
      $(selector).each((index, element) => {
        const variationTitle = $(element).prev('.product-variation__title, .option-name, .variant-name').text().trim();
        const variationValues: string[] = [];
        
        $(element).find('.product-variation__option, .option-value, .variant-value').each((_, optionElement) => {
          const value = $(optionElement).text().trim();
          if (value) variationValues.push(value);
        });
        
        if (variationTitle && variationValues.length > 0) {
          variations[variationTitle] = variationValues;
          foundVariations = true;
        } else if (variationValues.length > 0) {
          // Se não encontrar um título, usar nomes genéricos
          variations[`Opção ${index + 1}`] = variationValues;
          foundVariations = true;
        }
      });
      
      if (foundVariations) {
        console.log(`Variações obtidas do seletor: ${selector}`);
        break;
      }
    }
    
    // Verificar se temos dados suficientes para considerar o scraping bem-sucedido
    // Precisamos de pelo menos título e preço para considerar sucesso parcial
    const success = !!(title && price > 0);
    
    if (success) {
      console.log('Scraping bem-sucedido via HTML');
      // DIAGNÓSTICO - Para verificar exatamente o que foi extraído da descrição
      console.log("=== DIAGNÓSTICO DE SCRAPING - DESCRIÇÃO ORIGINAL COMPLETA ===");
      console.log(description);
      console.log("=== FIM DO DIAGNÓSTICO DE DESCRIÇÃO ===");
      
      return {
        title: title || 'Produto sem título',
        description: description || 'Sem descrição disponível',
        price,
        category: category || undefined,
        images: images.length ? images : undefined,
        specifications: Object.keys(specifications).length ? specifications : undefined,
        variations: Object.keys(variations).length ? variations : undefined
      };
    } else {
      console.log('Scraping HTML incompleto, faltam dados essenciais');
      return null;
    }
  } catch (error) {
    console.error('Erro ao fazer scraping do produto Shopee:', error);
    return null;
  }
}

/**
 * Fallback method that uses Shopee's unofficial API to get product data
 */
async function fallbackToShopeeApi(shopId: string, itemId: string): Promise<ScrapedProduct | null> {
  try {
    console.log(`Tentando API não oficial da Shopee para shopId=${shopId}, itemId=${itemId}`);
    
    // URL da API não oficial da Shopee - tentar nova versão da API v4
    const apiUrl = `https://shopee.com.br/api/v4/item/get?itemid=${itemId}&shopid=${shopId}`;
    
    const headers = {
      'User-Agent': getRandomUserAgent(),
      'Accept': 'application/json',
      'X-API-SOURCE': 'pc',
      'X-Shopee-Language': 'pt-BR',
      'X-Requested-With': 'XMLHttpRequest',
      'Referer': `https://shopee.com.br/product/${shopId}/${itemId}`,
      'If-None-Match-': '*'
    };
    
    // Adicionar delay para simular comportamento humano
    await new Promise(resolve => setTimeout(resolve, Math.floor(Math.random() * 1000) + 500));
    
    const response = await axios.get(apiUrl, { 
      headers,
      timeout: 10000
    });
    
    console.log(`Resposta da API obtida com status: ${response.status}`);
    const data = response.data;
    
    if (!data || !data.data || !data.data.name) {
      console.log('Resposta da API não contém dados válidos do produto');
      return null;
    }
    
    const product = data.data;
    console.log(`Dados do produto obtidos via API: ${product.name}`);
    
    // Extrair variações
    const variations: Record<string, string[]> = {};
    if (product.models && product.tier_variations) {
      product.tier_variations.forEach((tier: any, index: number) => {
        if (tier.name && tier.options) {
          variations[tier.name] = tier.options;
        }
      });
    }
    
    // Extrair especificações
    const specifications: Record<string, string> = {};
    if (product.attributes) {
      product.attributes.forEach((attr: any) => {
        if (attr.name && attr.value) {
          specifications[attr.name] = attr.value;
        }
      });
    }
    
    // Extrair imagens
    const images: string[] = [];
    if (product.images) {
      product.images.forEach((img: string) => {
        const imgUrl = `https://down-br.img.susercontent.com/${img}`;
        images.push(imgUrl);
      });
    }
    
    // Calcular preço real
    let price = 0;
    if (product.price) {
      price = product.price / 100000; // Converter de centavos para reais
    } else if (product.price_min && product.price_max) {
      // Se houver variação de preço, usar o valor médio
      price = (product.price_min + product.price_max) / 2 / 100000;
    }
    
    return {
      title: product.name,
      description: product.description || '',
      price,
      category: product.category_path ? product.category_path.join(' > ') : undefined,
      images: images.length ? images : undefined,
      specifications: Object.keys(specifications).length ? specifications : undefined,
      variations: Object.keys(variations).length ? variations : undefined
    };
  } catch (error) {
    console.error('Erro ao usar API da Shopee como fallback:', error);
    return null;
  }
}

/**
 * Função auxiliar para tentar API alternativa da Shopee
 */
async function tryAlternativeApi(url: string): Promise<ScrapedProduct | null> {
  try {
    console.log(`Tentando API alternativa para ${url}`);
    
    // Extrair o nome do produto da URL para busca
    const urlParts = url.split('/');
    const productNamePart = urlParts[urlParts.length - 1].split('-i.')[0];
    const searchTerm = productNamePart.replace(/-/g, ' ').trim();
    
    if (!searchTerm || searchTerm.length < 3) {
      console.log('Nome do produto não identificado da URL para busca alternativa');
      return null;
    }
    
    // URL da API de busca da Shopee
    const searchApiUrl = `https://shopee.com.br/api/v4/search/search_items?keyword=${encodeURIComponent(searchTerm)}&limit=5`;
    
    const headers = {
      'User-Agent': getRandomUserAgent(),
      'Accept': 'application/json',
      'X-API-SOURCE': 'pc',
      'Referer': 'https://shopee.com.br/search'
    };
    
    const response = await axios.get(searchApiUrl, { headers, timeout: 10000 });
    
    if (response.data?.items && response.data.items.length > 0) {
      // Encontrou resultados de busca, pegar o primeiro
      const firstItem = response.data.items[0].item_basic;
      
      if (firstItem?.name) {
        console.log(`Produto encontrado via API de busca: ${firstItem.name}`);
        
        // Usar as informações deste produto
        return {
          title: firstItem.name,
          description: firstItem.description || '',
          price: firstItem.price / 100000,
          category: undefined, // API de busca não retorna categoria detalhada
          images: firstItem.image ? [`https://down-br.img.susercontent.com/${firstItem.image}`] : undefined
        };
      }
    }
    
    console.log('Nenhum resultado encontrado via API de busca');
    return null;
  } catch (error) {
    console.error('Erro ao tentar API alternativa:', error);
    return null;
  }
}

/**
 * Extrator alternativo que tenta extrair informações a partir do próprio URL do produto
 * Este método é usado como última tentativa quando tudo mais falhar
 */
async function extractFromUrl(url: string): Promise<ScrapedProduct | null> {
  try {
    console.log(`Extraindo informações da própria URL: ${url}`);
    
    // Extrair o nome do produto da última parte da URL
    const urlObj = new URL(url);
    const pathParts = urlObj.pathname.split('/');
    const lastPart = pathParts[pathParts.length - 1].split('-i.')[0];
    
    if (!lastPart || lastPart.length < 5) {
      console.log('URL não contém informações suficientes sobre o produto');
      return null;
    }
    
    // Decodificar URL para tratar caracteres especiais corretamente
    const decodedPart = decodeURIComponent(lastPart);
    
    // Substituir hífens por espaços, preservando maiúsculas existentes
    const title = decodedPart.replace(/-/g, ' ');
    
    // Fazer uma tentativa de extrair o preço via Puppeteer ou Cheerio usando um proxy
    // Para este exemplo, vamos usar um preço estimado baseado no tipo de produto
    let price = 99.90; // valor padrão
    
    // Ajustar preço com base em palavras-chave no título
    if (title.toLowerCase().includes('kit')) {
      if (title.match(/kit\s+(\d+)/i)) {
        const quantity = parseInt(title.match(/kit\s+(\d+)/i)![1]);
        price = quantity * 9.99; // R$ 9,99 por unidade em kits
      } else {
        price = 39.99; // Kit genérico
      }
    }
    if (title.toLowerCase().includes('atacado')) {
      price *= 0.7; // 30% de desconto para atacado
    }
    
    // Criar uma descrição mais detalhada com base no título
    const titleWords = title.toLowerCase().split(' ');
    let description = `${title}. `;
    
    // Adicionar detalhes relevantes baseados em palavras-chave do título
    if (titleWords.includes('sem') && titleWords.includes('costura')) {
      description += "Produto sem costura para maior conforto e discrição sob as roupas. ";
    }
    if (titleWords.includes('microfibra')) {
      description += "Feito em microfibra de alta qualidade, macio e confortável para uso diário. ";
    }
    if (titleWords.includes('tanga') || titleWords.includes('tanga')) {
      description += "Modelo tanga, design moderno e confortável. ";
    }
    if (titleWords.includes('corte') && titleWords.includes('laser')) {
      description += "Corte a laser que não marca sob as roupas, garantindo discrição e conforto. ";
    }
    if (titleWords.includes('atacado')) {
      description += "Ideal para revendedores. Embalagem discreta. ";
    }
    
    description += "Disponível na Shopee com garantia de qualidade e entrega para todo o Brasil.";
    
    // Determinar categoria com mais precisão
    let category = "Moda íntima";
    const categoryKeywords = {
      'eletrônicos': ['celular', 'smartphone', 'fone', 'headset', 'headphone', 'notebook', 'tablet', 'camera'],
      'roupas': ['camiseta', 'calça', 'vestido', 'jaqueta', 'casaco', 'sapato', 'tênis'],
      'casa e decoração': ['mesa', 'cadeira', 'sofá', 'cama', 'armário', 'luminária'],
      'beleza': ['perfume', 'maquiagem', 'batom', 'shampoo', 'creme']
    };
    
    const lowercaseTitle = title.toLowerCase();
    for (const [cat, keywords] of Object.entries(categoryKeywords)) {
      if (keywords.some(keyword => lowercaseTitle.includes(keyword))) {
        category = cat;
        break;
      }
    }
    
    return {
      title,
      description,
      price,
      category,
      shopeeUrl: url
    };
  } catch (error) {
    console.error('Erro ao extrair informações da URL:', error);
    return null;
  }
}

/**
 * Função principal que tenta vários métodos de scraping com retry e relatório detalhado
 */
export async function getProductData(url: string): Promise<ScrapedProduct> {
  console.log(`=== Iniciando extração de dados do produto: ${url} ===`);
  
  // Verificar se a URL parece ser da Shopee
  if (!url.includes('shopee')) {
    console.log('AVISO: URL não parece ser da Shopee, mas tentaremos mesmo assim');
  }
  
  // Valor padrão caso ocorra algum erro
  const defaultProduct: ScrapedProduct = {
    title: 'Produto da Shopee',
    description: 'Este é um produto vendido na plataforma Shopee.',
    price: 99.99,
    shopeeUrl: url
  };
  
  /**
   * Função auxiliar que tenta acessar a API interna da Shopee para obter dados
   * Isso é mais direto e contorna muitas proteções anti-bot
   */
  async function tryShopeeApi(itemId: string, shopId: string): Promise<ScrapedProduct | null> {
    try {
      console.log(`Tentando API interna da Shopee para shopId=${shopId}, itemId=${itemId}`);
      // URL da API interna da Shopee para detalhes do produto
      const apiUrl = `https://shopee.com.br/api/v4/item/get?itemid=${itemId}&shopid=${shopId}`;
      
      // Headers específicos para a API
      const headers = {
        'User-Agent': getRandomUserAgent(),
        'Accept': 'application/json',
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'Content-Type': 'application/json',
        'Referer': `https://shopee.com.br/product/${shopId}/${itemId}`,
        'Origin': 'https://shopee.com.br',
      };
      
      // Configuramos um proxy para a API também
      let axiosConfig: any = { 
        headers, 
        timeout: 15000,
      };
      
      // Usar proxy aleatório
      const proxyUrl = getRandomProxy();
      console.log(`Usando proxy para API: ${proxyUrl}`);
      const proxyAgent = new HttpsProxyAgent(proxyUrl);
      axiosConfig.httpsAgent = proxyAgent;
      axiosConfig.proxy = false;
      
      const response = await axios.get(apiUrl, axiosConfig);
      
      // Verificar se a resposta contém dados do produto
      if (response.data && response.data.data) {
        const item = response.data.data;
        
        if (!item) {
          console.warn('API Shopee retornou resposta vazia');
          return null;
        }
        
        console.log('Obteve dados via API interna da Shopee:', Object.keys(item));
        
        // Extrair informações do produto
        return {
          title: item.name || 'Produto Shopee',
          description: item.description || 'Descrição não disponível',
          price: parseFloat((item.price || 0) / 100000) || 99.90, // Preço em Shopee API vem multiplicado
          category: item.categories?.[0]?.display_name || '',
          specifications: item.attributes?.reduce((acc, attr) => {
            if (attr.name && attr.value) {
              acc[attr.name] = attr.value;
            }
            return acc;
          }, {} as Record<string, string>) || {},
          images: (item.images || []).map((img: string) => 
            `https://cf.shopee.com.br/file/${img}`
          ),
          variations: {},
          shopeeUrl: `https://shopee.com.br/product/${shopId}/${itemId}`
        };
      }
      
      console.warn('API Shopee retornou formato inesperado');
      return null;
    } catch (error: any) {
      console.error('Erro ao acessar API Shopee:', error.message);
      return null;
    }
  }

  // Estratégias de extração em ordem de preferência
  const strategies = [
    {
      name: "API oficial Shopee",
      execute: async () => {
        console.log("Estratégia 1: API oficial Shopee");
        try {
          const ids = extractShopeeProductId(url);
          if (ids) {
            const apiProduct = await tryShopeeApi(ids.itemId, ids.shopId);
            if (apiProduct) {
              console.log('Extração bem-sucedida via API oficial Shopee');
              return apiProduct;
            }
          } else {
            console.log('Não foi possível extrair IDs da URL para API oficial');
          }
        } catch (e: any) {
          console.error("Erro ao usar API oficial:", e.message || e);
        }
        return null;
      }
    },
    {
      name: "Scraping via HTML com Proxies",
      execute: async () => {
        // Tentar até 5 vezes com intervalos crescentes entre tentativas e proxies diferentes
        for (let attempt = 1; attempt <= 5; attempt++) {
          console.log(`Estratégia 2 - Tentativa ${attempt}/5: Scraping via HTML com Proxy`);
          
          // Aguardar tempo crescente entre tentativas
          if (attempt > 1) {
            const waitTime = attempt * 2000; // 2s, 4s, 6s, 8s, 10s
            console.log(`Aguardando ${waitTime}ms antes da próxima tentativa...`);
            await new Promise(resolve => setTimeout(resolve, waitTime));
          }
          
          try {
            // Configuração manual do proxy para esta tentativa
            const proxyUrl = FREE_PROXIES[(attempt - 1) % FREE_PROXIES.length]; // Usar um proxy diferente a cada tentativa
            console.log(`Usando proxy para HTML: ${proxyUrl}`);
            
            // URL com parâmetros aleatórios para evitar cache
            const urlObj = new URL(url);
            urlObj.searchParams.append('_t', Date.now().toString());
            urlObj.searchParams.append('_r', Math.random().toString().substring(2));
            
            // Forçar o domínio para shopee.com.br
            if (urlObj.hostname.includes('shopee')) {
              urlObj.hostname = 'shopee.com.br';
            }
            
            // Headers avançados para evitar detecção
            const headers = {
              'User-Agent': getRandomUserAgent(),
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
              'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
              'Cache-Control': 'no-cache',
              'Pragma': 'no-cache',
              'Sec-Ch-Ua': '"Google Chrome";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
              'Sec-Ch-Ua-Mobile': '?0',
              'Sec-Ch-Ua-Platform': '"Windows"',
              'Upgrade-Insecure-Requests': '1',
              'Referer': 'https://www.google.com/', // Simular vinda do Google
              'Origin': 'https://www.google.com'
            };
            
            // Configuração do proxy
            const proxyAgent = new HttpsProxyAgent(proxyUrl);
            const axiosConfig = {
              headers,
              timeout: 20000,
              httpsAgent: proxyAgent,
              proxy: false,
              maxRedirects: 5
            };
            
            // Fazer a requisição com proxy
            console.log(`Tentando extrair dados de: ${urlObj.toString()}`);
            const response = await axios.get(urlObj.toString(), axiosConfig);
            
            if (response.status >= 200 && response.status < 300) {
              console.log(`Resposta obtida com sucesso via proxy (status ${response.status})`);
              
              if (response.data && response.data.includes('<html')) {
                // Processar o HTML com Cheerio
                const $ = cheerio.load(response.data);
                
                // Estratégia robusta de extração de dados
                // Extrair título do produto
                let title = $('meta[property="og:title"]').attr('content') || 
                           $('title').text() || 
                           $('.pdp-mod-product-badge-title').text() ||
                           $('h1').first().text();
                
                if (!title || title.trim().length < 5) {
                  // Tentar seletores específicos da Shopee
                  const titleSelectors = [
                    '.pdp-mod-product-badge-title',
                    '.attM6y span',
                    '._44qnta',
                    'h1.product-details__name'
                  ];
                  
                  for (const selector of titleSelectors) {
                    const foundTitle = $(selector).text().trim();
                    if (foundTitle && foundTitle.length > 5) {
                      title = foundTitle;
                      break;
                    }
                  }
                }
                
                // Extrair descrição do produto
                let description = $('meta[property="og:description"]').attr('content') || '';
                
                if (!description || description.length < 20) {
                  // Tentar seletores específicos da Shopee para descrição
                  const descSelectors = [
                    '.product-detail__product-description',
                    '.U85vF1',   
                    '.product-detail',
                    '[data-testid="pdp-product-description"]',
                    '#product-detail',
                    '.product-detail-content',
                    '.product-detail-description',
                    '.detail-content',
                    '.qrm04f',
                    '.rqoNv1',
                    '.IpLrFV',
                    '.shopee-product-detail'
                  ];
                  
                  for (const selector of descSelectors) {
                    const desc = $(selector).text().trim();
                    if (desc && desc.length > 20) {
                      description = desc;
                      break;
                    }
                  }
                  
                  // Se ainda não encontrou descrição, procurar por divs grandes
                  if (!description || description.length < 20) {
                    $('div').each((_, el) => {
                      const text = $(el).text().trim();
                      if (text.length > 200 && !description) {
                        description = text;
                      }
                    });
                  }
                }
                
                // Extrair preço - primeiro tenta metadados
                let price = 0;
                const metaPrice = $('meta[property="product:price:amount"]').attr('content');
                
                if (metaPrice) {
                  price = parseFloat(metaPrice);
                } else {
                  // Tentar seletores específicos da Shopee para preço
                  const priceSelectors = [
                    '.pqTWkA',
                    '.dQA32e',
                    '.AJyN7v',
                    '.pmmxKx',
                    '.pdp-price_size_xl'
                  ];
                  
                  for (const selector of priceSelectors) {
                    const priceText = $(selector).text().trim();
                    if (priceText) {
                      // Remover símbolos de moeda e formatar
                      const priceValue = priceText.replace(/[^\d,.-]/g, '').replace(',', '.');
                      const parsedPrice = parseFloat(priceValue);
                      
                      if (!isNaN(parsedPrice) && parsedPrice > 0) {
                        price = parsedPrice;
                        break;
                      }
                    }
                  }
                }
                
                // Se todos os dados essenciais foram extraídos, retornar o produto
                if (title && description) {
                  const result: ScrapedProduct = {
                    title: title.trim() || 'Produto Shopee',
                    description: description.trim() || 'Descrição não disponível',
                    price: price > 0 ? price : 99.90,
                    shopeeUrl: url
                  };
                  
                  console.log(`Extração HTML bem-sucedida via proxy na tentativa ${attempt}:`);
                  console.log(`- Título: ${result.title.substring(0, 50)}...`);
                  console.log(`- Descrição: ${result.description.substring(0, 50)}...`);
                  console.log(`- Preço: R$${result.price}`);
                  
                  return result;
                }
              } else {
                console.warn("Resposta não contém HTML válido");
              }
            }
          } catch (e: any) {
            console.error(`Erro na tentativa ${attempt} de scraping HTML com proxy:`, e.message || e);
          }
        }
        return null;
      }
    },
    {
      name: "API não oficial usando IDs",
      execute: async () => {
        console.log("Estratégia 2: API não oficial usando IDs");
        try {
          const ids = extractShopeeProductId(url);
          if (ids) {
            const apiProduct = await fallbackToShopeeApi(ids.shopId, ids.itemId);
            if (apiProduct) {
              console.log('Extração bem-sucedida via API não oficial');
              return apiProduct;
            }
          } else {
            console.log('Não foi possível extrair IDs da URL para API não oficial');
          }
        } catch (e: any) {
          console.error("Erro ao usar API não oficial:", e.message || e);
        }
        return null;
      }
    },
    {
      name: "API de busca alternativa",
      execute: async () => {
        console.log("Estratégia 3: API de busca alternativa");
        try {
          const alternativeResult = await tryAlternativeApi(url);
          if (alternativeResult) {
            console.log('Extração bem-sucedida via API de busca alternativa');
            return alternativeResult;
          }
        } catch (e) {
          console.error("Erro na API de busca alternativa:", e.message);
        }
        return null;
      }
    },
    {
      name: "Extração de dados da URL",
      execute: async () => {
        console.log("Estratégia 4: Última tentativa - extraindo da URL");
        try {
          return await extractFromUrl(url);
        } catch (e) {
          console.error("Erro na extração da URL:", e.message);
          return null;
        }
      }
    }
  ];
  
  // Executar estratégias em ordem
  for (const strategy of strategies) {
    try {
      console.log(`Tentando estratégia: ${strategy.name}`);
      const result = await strategy.execute();
      if (result) {
        return result;
      }
    } catch (error) {
      console.error(`Erro na estratégia ${strategy.name}:`, error);
    }
  }
  
  // Se todas as estratégias falharem, usar valores padrão
  console.log('ATENÇÃO: Todas as estratégias de extração falharam.');
  console.log('Usando valores padrão para o produto.');
  
  return defaultProduct;
}