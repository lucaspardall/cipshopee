import OpenAI from "openai";
import { DEFAULT_ASSISTANT_CONFIG } from "./ai";

/**
 * Este módulo contém funções para testar a integração com o assistente especializado.
 * Pode ser usado para verificar se o assistente está respondendo corretamente em formato JSON.
 */

// Configuração segura do cliente OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  timeout: 90000, // 90 segundos para timeout de solicitações
  maxRetries: 2, // Limitar retentativas para evitar custos excessivos
});

/**
 * Envia uma solicitação de teste para o assistente e retorna a resposta como JSON
 */
export async function testAssistantResponse(productInfo: string = ""): Promise<any> {
  try {
    // Se não for fornecida informação de produto, usar um exemplo padrão
    const testProductInfo = productInfo || `
      Sutiã de Amamentação - Confortável
      
      Sutiã para amamentação feito com algodão e elastano, fecho click para facilitar a amamentação, 
      alças ajustáveis, sem bojo. Disponível nos tamanhos P, M, G e GG. 
      
      Preço atual: R$69,90
    `;
    
    const testUrl = "https://shopee.com.br/produto-exemplo";
    
    // Criar um prompt de teste seguindo o formato estabelecido
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // o modelo mais recente da OpenAI (maio/2024)
      messages: [
        {
          role: "system",
          content: "Você é um especialista em otimização de anúncios da Shopee seguindo o Método Pardal 10/10. Produza respostas estruturadas em formato JSON."
        },
        {
          role: "user",
          content: `Use o seu conhecimento do Método Pardal 10/10 para otimizar este anúncio da Shopee:
          
          URL: ${testUrl}
          
          Informações do Produto:
          ${testProductInfo}
          
          Execute a função OTIMIZADOR DE ANÚNCIOS para criar uma versão aprimorada seguindo o Método Pardal 10/10.
          
          REQUISITOS OBRIGATÓRIOS:
          1. Título [máx 120 caracteres]: Aplique a fórmula dos Dossiês Pardal
          2. Descrição: CRIE UMA DESCRIÇÃO DETALHADA E COMPLETA com pelo menos 10-15 linhas
          3. Preços: Calcule o preço sugerido e um preço com desconto
          4. Palavras-chave: Forneça 5-7 palavras-chave de alto volume
          5. Melhorias: Liste 4-6 melhorias específicas em português
          6. Plano de Boost: Crie um "Plano de Boost 7 Dias" com ações táticas específicas
          
          Responda APENAS com o JSON a seguir (sem comentários adicionais).
          Sua resposta DEVE ser um JSON válido para ser processado corretamente.`
        }
      ],
      response_format: { type: "json_object" }
    });

    // Extrair e fazer parse do JSON da resposta
    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("API returned empty content");
    }

    // Fazer parse do JSON
    return JSON.parse(content);

  } catch (error) {
    console.error("Error testing assistant response:", error);
    return {
      error: "Falha ao testar assistente",
      message: error instanceof Error ? error.message : "Erro desconhecido"
    };
  }
}

/**
 * Função auxiliar para formatar a resposta do assistente de forma legível
 */
export function formatAssistantResponse(response: any): string {
  try {
    // Verificar os campos principais esperados
    const fieldsPresent = [
      'optimizedTitle',
      'optimizedDescription',
      'suggestedPrice',
      'discountPrice',
      'keywords',
      'generalImprovements',
      'boostPlan'
    ];
    
    const missingFields = fieldsPresent.filter(field => !response[field]);
    
    let result = "## Resultado do Teste de Integração com Assistente\n\n";
    
    // Adicionar status
    if (missingFields.length === 0) {
      result += "✅ **Status**: Integração funcionando corretamente\n\n";
    } else {
      result += `⚠️ **Status**: Integração parcial - ${missingFields.length} campos ausentes: ${missingFields.join(', ')}\n\n`;
    }
    
    // Adicionar campos principais formatados
    if (response.optimizedTitle) {
      result += `### Título Otimizado:\n${response.optimizedTitle}\n\n`;
    }
    
    if (response.suggestedPrice && response.discountPrice) {
      result += `### Preços:\n- Sugerido: R$${response.suggestedPrice.toFixed(2)}\n- Com desconto: R$${response.discountPrice.toFixed(2)}\n\n`;
    }
    
    if (response.keywords && Array.isArray(response.keywords)) {
      result += `### Palavras-chave (${response.keywords.length}):\n${response.keywords.map((k: string) => `- ${k}`).join('\n')}\n\n`;
    }
    
    if (response.boostPlan && Array.isArray(response.boostPlan)) {
      result += `### Plano de Boost 7 Dias:\n${response.boostPlan.map((day: string) => `- ${day}`).join('\n')}\n\n`;
    }
    
    // Mostrar apenas parte da descrição para legibilidade
    if (response.optimizedDescription) {
      const previewLength = 250;
      const description = response.optimizedDescription;
      result += `### Descrição (prévia):\n${description.length > previewLength ? description.substring(0, previewLength) + '...' : description}\n\n`;
    }
    
    // Adicionar JSON completo para referência
    result += "### JSON Completo:\n```json\n" + JSON.stringify(response, null, 2) + "\n```";
    
    return result;
  } catch (error) {
    console.error("Error formatting assistant response:", error);
    return `Error formatting response: ${error instanceof Error ? error.message : "Unknown error"}`;
  }
}