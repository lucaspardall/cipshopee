import axios from 'axios';
import { z } from 'zod';

// Configuração para conexão com o n8n
const N8N_URL = process.env.N8N_URL;
const N8N_API_KEY = process.env.N8N_API_KEY;
const APP_URL = process.env.APP_URL || process.env.REPLIT_DOMAINS?.split(',')[0] ? `https://${process.env.REPLIT_DOMAINS?.split(',')[0]}` : 'https://cip-shopee.replit.app';

// Validação para os parâmetros do agente
export const agentConfigSchema = z.object({
  userId: z.number(),
  storeUrl: z.string().url(),
  scanFrequency: z.enum(['daily', 'weekly', 'monthly']),
  notificationEnabled: z.boolean().default(true),
  optimizationTargets: z.array(z.enum(['title', 'description', 'keywords', 'price'])),
  openaiAssistantId: z.string().optional(),
  useCustomAssistant: z.boolean().default(false),
});

export type AgentConfig = z.infer<typeof agentConfigSchema>;

// Status do agente
export enum AgentStatus {
  ACTIVE = 'active',
  PAUSED = 'paused',
  ERROR = 'error',
  CONFIGURING = 'configuring',
}

// Interface para o cliente n8n
export interface N8nAgent {
  id: string;
  name: string;
  status: AgentStatus;
  userId: number;
  lastRun: Date | null;
  nextScheduledRun: Date | null;
  config: AgentConfig;
}

/**
 * Cliente para comunicação com n8n
 */
class N8nClient {
  private baseUrl: string;
  private apiKey: string | undefined;

  constructor() {
    this.baseUrl = N8N_URL;
    this.apiKey = N8N_API_KEY;
  }

  /**
   * Verifica se o cliente n8n está corretamente configurado
   * @param forceApiCheck Se verdadeiro, verifica se a API está configurada (caso contrário, aceita webhook)
   */
  isConfigured(forceApiCheck: boolean = false): boolean {
    // Se apenas webhook for necessário e temos uma URL de app válida
    if (!forceApiCheck && APP_URL) {
      console.log("Usando modo webhook para n8n (sem necessidade de API Key)");
      return true;
    }

    // Se a API for necessária, verificamos a API Key
    return !!this.apiKey;
  }

  /**
   * Verifica se o cliente está configurado para operações de webhook
   * @returns true se as configurações básicas para webhooks estiverem presentes
   */
  isWebhookConfigured(): boolean {
    // Sempre retornar true pois agora temos um webhook fixo configurado
    return true;
  }

  getWebhookUrl(): string {
    return "https://lucaspardal.app.n8n.cloud/webhook/da2b7cb7-418d-490f-8076-b5be40e31b7b";
  }

  /**
   * Cria um novo agente para o usuário
   */
  async createAgent(config: AgentConfig): Promise<N8nAgent | null> {
    if (!this.isConfigured(true)) {
      console.error('N8N API não configurada: API Key ausente');
      return null;
    }

    try {
      const response = await axios.post(`${this.baseUrl}/api/v1/workflows`, {
        name: `CIP Shopee Agent - User ${config.userId}`,
        active: true,
        nodes: this.generateWorkflowNodes(config),
        connections: this.generateWorkflowConnections(config),
      }, {
        headers: {
          'X-N8N-API-KEY': this.apiKey,
          'Content-Type': 'application/json'
        }
      });

      if (response.status === 200) {
        return {
          id: response.data.id,
          name: response.data.name,
          status: AgentStatus.ACTIVE,
          userId: config.userId,
          lastRun: null,
          nextScheduledRun: this.calculateNextRun(config.scanFrequency),
          config
        };
      }

      return null;
    } catch (error) {
      console.error('Erro ao criar agente no n8n:', error);
      return null;
    }
  }

  /**
   * Atualiza a configuração de um agente existente
   */
  async updateAgent(agentId: string, config: AgentConfig): Promise<boolean> {
    if (!this.isConfigured(true)) {
      console.error('N8N API não configurada: API Key ausente para atualizar agente');
      return false;
    }

    try {
      const response = await axios.put(`${this.baseUrl}/api/v1/workflows/${agentId}`, {
        active: true,
        nodes: this.generateWorkflowNodes(config),
        connections: this.generateWorkflowConnections(config),
      }, {
        headers: {
          'X-N8N-API-KEY': this.apiKey,
          'Content-Type': 'application/json'
        }
      });

      return response.status === 200;
    } catch (error) {
      console.error('Erro ao atualizar agente no n8n:', error);
      return false;
    }
  }

  /**
   * Pausa um agente
   */
  async pauseAgent(agentId: string): Promise<boolean> {
    if (!this.isConfigured(true)) {
      console.error('N8N API não configurada: API Key ausente para pausar agente');
      return false;
    }

    try {
      const response = await axios.put(`${this.baseUrl}/api/v1/workflows/${agentId}/activate`, {
        active: false
      }, {
        headers: {
          'X-N8N-API-KEY': this.apiKey,
          'Content-Type': 'application/json'
        }
      });

      return response.status === 200;
    } catch (error) {
      console.error('Erro ao pausar agente no n8n:', error);
      return false;
    }
  }

  /**
   * Reativa um agente pausado
   */
  async resumeAgent(agentId: string): Promise<boolean> {
    if (!this.isConfigured(true)) {
      console.error('N8N API não configurada: API Key ausente para reativar agente');
      return false;
    }

    try {
      const response = await axios.put(`${this.baseUrl}/api/v1/workflows/${agentId}/activate`, {
        active: true
      }, {
        headers: {
          'X-N8N-API-KEY': this.apiKey,
          'Content-Type': 'application/json'
        }
      });

      return response.status === 200;
    } catch (error) {
      console.error('Erro ao reativar agente no n8n:', error);
      return false;
    }
  }

  /**
   * Exclui um agente
   */
  async deleteAgent(agentId: string): Promise<boolean> {
    if (!this.isConfigured(true)) {
      console.error('N8N API não configurada: API Key ausente para excluir agente');
      return false;
    }

    try {
      const response = await axios.delete(`${this.baseUrl}/api/v1/workflows/${agentId}`, {
        headers: {
          'X-N8N-API-KEY': this.apiKey
        }
      });

      return response.status === 200;
    } catch (error) {
      console.error('Erro ao excluir agente no n8n:', error);
      return false;
    }
  }

  /**
   * Executa um agente manualmente
   */
  async executeAgent(agentId: string): Promise<boolean> {
    if (!this.isConfigured(true)) {
      console.error('N8N API não configurada: API Key ausente para executar agente');
      return false;
    }

    try {
      const response = await axios.post(`${this.baseUrl}/api/v1/workflows/${agentId}/execute`, {}, {
        headers: {
          'X-N8N-API-KEY': this.apiKey,
          'Content-Type': 'application/json'
        }
      });

      return response.status === 200;
    } catch (error) {
      console.error('Erro ao executar agente no n8n:', error);
      return false;
    }
  }

  /**
   * Calcula a próxima execução com base na frequência
   */
  private calculateNextRun(frequency: string): Date {
    const now = new Date();

    switch (frequency) {
      case 'daily':
        return new Date(now.setDate(now.getDate() + 1));
      case 'weekly':
        return new Date(now.setDate(now.getDate() + 7));
      case 'monthly':
        return new Date(now.setMonth(now.getMonth() + 1));
      default:
        return new Date(now.setDate(now.getDate() + 1));
    }
  }

  /**
   * Gera a configuração de nós para o workflow
   */
  private generateWorkflowNodes(config: AgentConfig) {
    // Verifica se devemos usar o assistente personalizado
    if (config.useCustomAssistant && config.openaiAssistantId) {
      return this.generateAssistantWorkflowNodes(config);
    } else {
      // Workflow padrão sem assistente personalizado
      return [
        {
          id: 'n1',
          name: 'Schedule Trigger',
          type: 'n8n-nodes-base.scheduleTrigger',
          parameters: {
            interval: this.getScheduleInterval(config.scanFrequency)
          },
          typeVersion: 1,
          position: [250, 300]
        },
        {
          id: 'n2',
          name: 'HTTP Request',
          type: 'n8n-nodes-base.httpRequest',
          parameters: {
            url: `${config.storeUrl}`,
            method: 'GET'
          },
          typeVersion: 1,
          position: [500, 300]
        },
        {
          id: 'n3',
          name: 'Function',
          type: 'n8n-nodes-base.function',
          parameters: {
            functionCode: `
              // Código para processar os dados da loja
              return {
                json: {
                  userId: ${config.userId},
                  storeData: $input.all()[0].json,
                  timestamp: new Date().toISOString(),
                  recommendations: [
                    "Otimizar títulos dos produtos",
                    "Melhorar descrições com palavras-chave relevantes",
                    "Verificar preços para maior competitividade"
                  ]
                }
              };
            `
          },
          typeVersion: 1,
          position: [750, 300]
        },
        {
          id: 'n4',
          name: 'HTTP Request',
          type: 'n8n-nodes-base.httpRequest',
          parameters: {
            url: this.getWebhookUrl(),
            method: 'POST',
            body: '={{$node["Function"].json}}',
            headerParameters: {
              parameters: [
                {
                  name: 'Content-Type',
                  value: 'application/json'
                },
                {
                  name: 'X-Webhook-Source',
                  value: 'n8n'
                }
              ]
            }
          },
          typeVersion: 1,
          position: [1000, 300]
        }
      ];
    }
  }

  /**
   * Gera um workflow que utiliza um assistente da OpenAI
   */
  private generateAssistantWorkflowNodes(config: AgentConfig) {
    return [
      {
        id: 'n1',
        name: 'Schedule Trigger',
        type: 'n8n-nodes-base.scheduleTrigger',
        parameters: {
          interval: this.getScheduleInterval(config.scanFrequency)
        },
        typeVersion: 1,
        position: [250, 300]
      },
      {
        id: 'n2',
        name: 'HTTP Request - Store Data',
        type: 'n8n-nodes-base.httpRequest',
        parameters: {
          url: `${config.storeUrl}`,
          method: 'GET'
        },
        typeVersion: 1,
        position: [450, 300]
      },
      {
        id: 'n3',
        name: 'OpenAI - Create Thread',
        type: 'n8n-nodes-base.openAi',
        parameters: {
          authentication: 'apiKey',
          apiKey: process.env.OPENAI_API_KEY,
          resource: 'thread',
          operation: 'create'
        },
        typeVersion: 1,
        position: [650, 200]
      },
      {
        id: 'n4',
        name: 'OpenAI - Create Message',
        type: 'n8n-nodes-base.openAi',
        parameters: {
          authentication: 'apiKey',
          apiKey: process.env.OPENAI_API_KEY,
          resource: 'message',
          operation: 'create',
          threadId: '={{$node["OpenAI - Create Thread"].json.id}}',
          role: 'user',
          content: '={{`Analise os dados desta loja e forneça recomendações de otimização. Dados: ${JSON.stringify($node["HTTP Request - Store Data"].json)}`}}'
        },
        typeVersion: 1,
        position: [850, 200]
      },
      {
        id: 'n5',
        name: 'OpenAI - Run Assistant',
        type: 'n8n-nodes-base.openAi',
        parameters: {
          authentication: 'apiKey',
          apiKey: process.env.OPENAI_API_KEY,
          resource: 'run',
          operation: 'create',
          threadId: '={{$node["OpenAI - Create Thread"].json.id}}',
          assistantId: config.openaiAssistantId
        },
        typeVersion: 1,
        position: [1050, 200]
      },
      {
        id: 'n6',
        name: 'OpenAI - Wait for Run',
        type: 'n8n-nodes-base.openAi',
        parameters: {
          authentication: 'apiKey',
          apiKey: process.env.OPENAI_API_KEY,
          resource: 'run',
          operation: 'get',
          threadId: '={{$node["OpenAI - Create Thread"].json.id}}',
          runId: '={{$node["OpenAI - Run Assistant"].json.id}}'
        },
        typeVersion: 1,
        position: [1250, 200]
      },
      {
        id: 'n7',
        name: 'OpenAI - Get Messages',
        type: 'n8n-nodes-base.openAi',
        parameters: {
          authentication: 'apiKey',
          apiKey: process.env.OPENAI_API_KEY,
          resource: 'message',
          operation: 'getAll',
          threadId: '={{$node["OpenAI - Create Thread"].json.id}}'
        },
        typeVersion: 1,
        position: [1450, 200]
      },
      {
        id: 'n8',
        name: 'Process Assistant Response',
        type: 'n8n-nodes-base.function',
        parameters: {
          functionCode: `
            // Extrair a última mensagem do assistente
            const messages = $input.all()[0].json.data;
            const assistantMessages = messages.filter(msg => msg.role === 'assistant');
            const lastMessage = assistantMessages[0];

            // Processar a resposta do assistente
            let recommendations = [];
            let analysisData = {};

            if (lastMessage && lastMessage.content) {
              const content = lastMessage.content[0].text.value;

              // Tentar extrair recomendações estruturadas
              try {
                // Verificar se há JSON na resposta
                const jsonMatch = content.match(/\`\`\`json([\\s\\S]*?)\`\`\`/);
                if (jsonMatch && jsonMatch[1]) {
                  analysisData = JSON.parse(jsonMatch[1].trim());
                  if (analysisData.recommendations) {
                    recommendations = analysisData.recommendations;
                  }
                } else {
                  // Extrair recomendações do texto
                  const recLines = content.split('\\n').filter(line => 
                    line.includes('*') || line.includes('-') || /^\\d+\\./.test(line)
                  );
                  recommendations = recLines.map(line => line.replace(/^[\\*\\-\\d\\.\\s]+/, '').trim());
                }
              } catch (error) {
                // Fallback: usar apenas algumas linhas do texto
                recommendations = [
                  "Recomendação extraída do assistente",
                  "Verifique a análise completa para mais detalhes"
                ];
              }
            }

            return {
              json: {
                userId: ${config.userId},
                timestamp: new Date().toISOString(),
                recommendations: recommendations,
                fullAnalysis: lastMessage ? lastMessage.content[0].text.value : "Nenhuma análise disponível",
                data: analysisData
              }
            };
          `
        },
        typeVersion: 1,
        position: [1650, 200]
      },
      {
        id: 'n9',
        name: 'HTTP Request - Callback',
        type: 'n8n-nodes-base.httpRequest',
        parameters: {
          url: this.getWebhookUrl(),
          method: 'POST',
          body: '={{$node["Process Assistant Response"].json}}',
          headerParameters: {
            parameters: [
              {
                name: 'Content-Type',
                value: 'application/json'
              },
              {
                name: 'X-Webhook-Source',
                value: 'n8n'
              },
              {
                name: 'X-Assistant-Enabled',
                value: 'true'
              }
            ]
          }
        },
        typeVersion: 1,
        position: [1850, 200]
      }
    ];
  }

  /**
   * Gera as conexões entre nós do workflow
   */
  private generateWorkflowConnections(config: AgentConfig): any {
    if (config.useCustomAssistant && config.openaiAssistantId) {
      return {
        'Schedule Trigger': {
          main: [
            [
              {
                node: 'HTTP Request - Store Data',
                type: 'main',
                index: 0
              }
            ]
          ]
        },
        'HTTP Request - Store Data': {
          main: [
            [
              {
                node: 'OpenAI - Create Thread',
                type: 'main',
                index: 0
              }
            ]
          ]
        },
        'OpenAI - Create Thread': {
          main: [
            [
              {
                node: 'OpenAI - Create Message',
                type: 'main',
                index: 0
              }
            ]
          ]
        },
        'OpenAI - Create Message': {
          main: [
            [
              {
                node: 'OpenAI - Run Assistant',
                type: 'main',
                index: 0
              }
            ]
          ]
        },
        'OpenAI - Run Assistant': {
          main: [
            [
              {
                node: 'OpenAI - Wait for Run',
                type: 'main',
                index: 0
              }
            ]
          ]
        },
        'OpenAI - Wait for Run': {
          main: [
            [
              {
                node: 'OpenAI - Get Messages',
                type: 'main',
                index: 0
              }
            ]
          ]
        },
        'OpenAI - Get Messages': {
          main: [
            [
              {
                node: 'Process Assistant Response',
                type: 'main',
                index: 0
              }
            ]
          ]
        },
        'Process Assistant Response': {
          main: [
            [
              {
                node: 'HTTP Request - Callback',
                type: 'main',
                index: 0
              }
            ]
          ]
        }
      };
    } else {
      return {
        'Schedule Trigger': {
          main: [
            [
              {
                node: 'HTTP Request',
                type: 'main',
                index: 0
              }
            ]
          ]
        },
        'HTTP Request': {
          main: [
            [
              {
                node: 'Function',
                type: 'main',
                index: 0
              }
            ]
          ]
        },
        'Function': {
          main: [
            [
              {
                node: 'HTTP Request1',
                type: 'main',
                index: 0
              }
            ]
          ]
        }
      };
    }
  }

  /**
   * Converte a frequência para o formato de intervalo do n8n
   */
  private getScheduleInterval(frequency: string): any {
    switch (frequency) {
      case 'daily':
        return { unit: 'days', value: 1 };
      case 'weekly':
        return { unit: 'weeks', value: 1 };
      case 'monthly':
        return { unit: 'months', value: 1 };
      default:
        return { unit: 'days', value: 1 };
    }
  }
}

// Singleton para uso em toda a aplicação
export const n8nClient = new N8nClient();