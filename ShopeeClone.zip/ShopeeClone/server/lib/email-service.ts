import { MailService } from '@sendgrid/mail';

// Verificar se a chave de API está configurada
const apiKey = process.env.SENDGRID_API_KEY;
let mailService: MailService | null = null;

if (apiKey) {
  mailService = new MailService();
  mailService.setApiKey(apiKey);
  console.log('SendGrid configurado e pronto para enviar e-mails');
} else {
  console.warn('SENDGRID_API_KEY não configurada. O envio de e-mails não estará disponível.');
}

interface EmailParams {
  to: string;
  subject: string;
  text?: string;
  html?: string;
  from?: string; // Opcional, usará o padrão se não fornecido
}

// Interface que corresponde ao que o SendGrid espera
interface SendGridMailData {
  to: string;
  from: string;
  subject: string;
  text: string;
  html: string;
}

/**
 * Envia um email usando o serviço SendGrid
 * @param params Parâmetros do email (destinatário, assunto, conteúdo)
 * @returns true se o email foi enviado com sucesso, false caso contrário
 */
export async function sendEmail(params: EmailParams): Promise<boolean> {
  if (!mailService) {
    console.error('Tentativa de enviar e-mail sem configuração do SendGrid');
    return false;
  }

  const defaultSender = 'noreply@cip-shopee.com.br';
  
  try {
    const mailData: SendGridMailData = {
      to: params.to,
      from: params.from || defaultSender,
      subject: params.subject,
      text: params.text || '',
      html: params.html || '',
    };
    
    await mailService.send(mailData);
    
    console.log(`E-mail enviado com sucesso para ${params.to}`);
    return true;
  } catch (error) {
    console.error('Erro ao enviar e-mail:', error);
    return false;
  }
}

/**
 * Envia um e-mail de otimização para o usuário
 * @param email Email do destinatário
 * @param productTitle Título do produto otimizado
 * @param optimizationUrl URL para visualizar a otimização
 * @returns true se o email foi enviado com sucesso, false caso contrário
 */
export async function sendOptimizationEmail(
  email: string,
  productTitle: string,
  optimizationUrl: string
): Promise<boolean> {
  const subject = `Otimização concluída: ${productTitle}`;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="background-color: #4f46e5; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0;">
        <h1 style="margin: 0;">Otimização Concluída!</h1>
      </div>
      
      <div style="border: 1px solid #e5e7eb; border-top: none; padding: 20px; border-radius: 0 0 5px 5px;">
        <p>Olá,</p>
        
        <p>Boas notícias! A otimização do seu produto <strong>"${productTitle}"</strong> foi concluída com sucesso.</p>
        
        <p>Nossa IA especializada analisou seu produto seguindo o Método Pardal 10/10 e gerou recomendações para melhorar seu desempenho na Shopee.</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${optimizationUrl}" style="background-color: #4f46e5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold;">
            Ver Otimização
          </a>
        </div>
        
        <p>Estas melhorias podem ajudar a aumentar a visibilidade, taxa de cliques e conversões do seu produto.</p>
        
        <p>Se tiver dúvidas, responda a este e-mail ou entre em contato com nosso suporte.</p>
        
        <p>Atenciosamente,<br>Equipe CIP Shopee</p>
      </div>
      
      <div style="text-align: center; padding: 20px; color: #6b7280; font-size: 12px;">
        <p>© 2025 CIP Shopee. Todos os direitos reservados.</p>
        <p>
          Para cancelar o recebimento de e-mails, <a href="{unsubscribe_url}" style="color: #4f46e5;">clique aqui</a>.
        </p>
      </div>
    </div>
  `;
  
  return sendEmail({
    to: email,
    subject,
    html
  });
}

/**
 * Envia um e-mail de boas-vindas para um novo usuário
 * @param email Email do destinatário
 * @param name Nome do usuário
 * @returns true se o email foi enviado com sucesso, false caso contrário
 */
export async function sendWelcomeEmail(
  email: string,
  name: string
): Promise<boolean> {
  const subject = 'Bem-vindo ao CIP Shopee!';
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="background-color: #4f46e5; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0;">
        <h1 style="margin: 0;">Bem-vindo ao CIP Shopee!</h1>
      </div>
      
      <div style="border: 1px solid #e5e7eb; border-top: none; padding: 20px; border-radius: 0 0 5px 5px;">
        <p>Olá ${name || 'Vendedor'},</p>
        
        <p>Estamos felizes em tê-lo como parte da comunidade CIP Shopee! Você agora tem acesso a ferramentas avançadas de otimização para melhorar seu desempenho na Shopee.</p>
        
        <p>Comece agora mesmo a otimizar seus produtos:</p>
        
        <ol>
          <li>Acesse sua conta no CIP Shopee</li>
          <li>Adicione os URLs dos seus produtos da Shopee</li>
          <li>Receba otimizações baseadas no Método Pardal 10/10</li>
          <li>Implemente as sugestões e veja seus resultados melhorarem!</li>
        </ol>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="https://cip-shopee.replit.app/" style="background-color: #4f46e5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold;">
            Acessar Minha Conta
          </a>
        </div>
        
        <p>Se tiver dúvidas, responda a este e-mail ou entre em contato com nosso suporte.</p>
        
        <p>Atenciosamente,<br>Equipe CIP Shopee</p>
      </div>
      
      <div style="text-align: center; padding: 20px; color: #6b7280; font-size: 12px;">
        <p>© 2025 CIP Shopee. Todos os direitos reservados.</p>
        <p>
          Para cancelar o recebimento de e-mails, <a href="{unsubscribe_url}" style="color: #4f46e5;">clique aqui</a>.
        </p>
      </div>
    </div>
  `;
  
  return sendEmail({
    to: email,
    subject,
    html
  });
}