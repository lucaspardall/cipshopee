import * as cheerio from "cheerio";

/**
 * Extrai a URL da imagem principal de um produto da Shopee
 * @param shopeeUrl URL da página do produto na Shopee
 * @returns URL da imagem do produto ou null se não encontrada
 */
export async function extractShopeeProductImage(shopeeUrl: string): Promise<string | null> {
  if (!shopeeUrl || !shopeeUrl.includes("shopee")) {
    return null;
  }

  try {
    // Faz uma requisição para a página do produto
    const response = await fetch(shopeeUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
      }
    });

    if (!response.ok) {
      console.error(`Erro ao acessar URL do produto: ${response.status}`);
      return null;
    }

    const html = await response.text();
    const $ = cheerio.load(html);
    
    // Seletores comuns para imagens de produtos na Shopee
    const imgSelectors = [
      "meta[property='og:image']",
      ".product-carousel img",
      ".shopee-image-manager__content img",
      ".XHtM65 img" // Um seletor específico da Shopee
    ];
    
    // Tenta encontrar uma imagem usando os seletores
    for (const selector of imgSelectors) {
      const imgElement = $(selector).first();
      
      // Verifica o atributo content (para meta tags) ou src
      const imgUrl = imgElement.attr("content") || imgElement.attr("src");
      
      if (imgUrl) {
        return imgUrl.startsWith("http") ? imgUrl : `https:${imgUrl}`;
      }
    }
    
    // Tenta encontrar URLs de imagem no texto da página
    const scriptTags = $("script").toArray();
    for (const script of scriptTags) {
      const scriptContent = $(script).html() || "";
      const imageRegex = /"image":"(https?:\/\/[^"]+\.(?:png|jpg|jpeg|webp))"/g;
      const match = imageRegex.exec(scriptContent);
      
      if (match && match[1]) {
        return match[1];
      }
    }

    return null;
  } catch (error) {
    console.error("Erro ao extrair imagem do produto:", error);
    return null;
  }
}

/**
 * Extrai múltiplas imagens de um produto da Shopee
 * @param shopeeUrl URL da página do produto na Shopee
 * @returns Array de URLs de imagens do produto ou array vazio se não encontradas
 */
export async function extractShopeeProductImages(shopeeUrl: string): Promise<string[]> {
  if (!shopeeUrl || !shopeeUrl.includes("shopee")) {
    return [];
  }

  try {
    const response = await fetch(shopeeUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
      }
    });

    if (!response.ok) {
      console.error(`Erro ao acessar URL do produto: ${response.status}`);
      return [];
    }

    const html = await response.text();
    const $ = cheerio.load(html);
    const images: string[] = [];
    
    // Procura por imagens nas galerias
    $(".product-carousel img, .shopee-image-manager__content img, .XHtM65 img").each((_, element) => {
      const imgUrl = $(element).attr("src");
      if (imgUrl) {
        const fullUrl = imgUrl.startsWith("http") ? imgUrl : `https:${imgUrl}`;
        if (!images.includes(fullUrl)) {
          images.push(fullUrl);
        }
      }
    });
    
    // Tenta encontrar URLs de imagem nos scripts
    const scriptTags = $("script").toArray();
    for (const script of scriptTags) {
      const scriptContent = $(script).html() || "";
      const imageRegex = /"image":"(https?:\/\/[^"]+\.(?:png|jpg|jpeg|webp))"/g;
      let match;
      
      while ((match = imageRegex.exec(scriptContent)) !== null) {
        if (match[1] && !images.includes(match[1])) {
          images.push(match[1]);
        }
      }
    }

    return images;
  } catch (error) {
    console.error("Erro ao extrair imagens do produto:", error);
    return [];
  }
}