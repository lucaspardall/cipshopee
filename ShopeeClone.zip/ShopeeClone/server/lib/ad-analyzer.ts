import OpenAI from "openai";

// Initialize OpenAI client with API key
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Interface para anúncios da Shopee
export interface ShopeeAd {
  adId: string;
  title: string;
  budget: number;
  spend: number;
  impressions: number;
  clicks: number;
  orders: number;
  revenue: number;
  ctr: number;
  cvr: number;
  cpc: number;
  roas: number;
  status: string;
  startDate?: string;
  endDate?: string;
}

// Interface para análise de anúncios
export interface AdAnalysis {
  adId: string;
  score: number;
  performance: 'good' | 'average' | 'poor';
  issues: string[];
  suggestions: string[];
  optimizedTitle?: string;
  optimizedBid?: number;
  optimizedBudget?: number;
  estimatedImprovement?: {
    clicks?: number;
    ctr?: number;
    cvr?: number;
    roas?: number;
  };
}

// Interface para estatísticas gerais
export interface OverviewStats {
  totalAds: number;
  activeAds: number;
  totalSpend: number;
  totalRevenue: number;
  averageRoas: number;
  highPerformingAds: number;
  poorPerformingAds: number;
  topIssues: string[];
}

/**
 * Analisa uma lista de anúncios da Shopee usando IA e retorna recomendações
 * @param ads Array de anúncios da Shopee para analisar
 * @returns Análises detalhadas e estatísticas gerais
 */
export async function analyzeShopeeAds(ads: ShopeeAd[]): Promise<{
  analyses: AdAnalysis[];
  overviewStats: OverviewStats;
}> {
  console.log(`Analisando ${ads.length} anúncios Shopee com IA`);
  
  try {
    // Preparar um conjunto simplificado de dados para o modelo não exceder tokens
    const simplifiedAds = ads.map(ad => ({
      adId: ad.adId,
      title: ad.title,
      budget: ad.budget,
      spend: ad.spend,
      impressions: ad.impressions,
      clicks: ad.clicks,
      orders: ad.orders,
      revenue: ad.revenue,
      ctr: ad.ctr,
      cvr: ad.cvr,
      cpc: ad.cpc,
      roas: ad.roas,
      status: ad.status
    }));
    
    const prompt = `Você é um especialista em marketing digital e otimização de anúncios para e-commerce na Shopee.
    Analise os seguintes dados de anúncios e forneça recomendações detalhadas para otimizá-los:
    
    ${JSON.stringify(simplifiedAds)}
    
    Para cada anúncio, forneça:
    1. Uma pontuação de 0-100 baseada no desempenho geral
    2. Classificação de desempenho: "good", "average" ou "poor"
    3. Lista de problemas identificados
    4. Sugestões específicas para melhorar o desempenho
    5. Título otimizado (apenas se o CTR for baixo)
    6. Lance otimizado (CPC recomendado)
    7. Orçamento otimizado
    8. Melhoria estimada em métricas-chave
    
    Além disso, forneça estatísticas gerais:
    1. Número de anúncios com alto desempenho
    2. Número de anúncios com baixo desempenho
    3. Top 3 problemas mais comuns
    
    Responda em formato JSON com a seguinte estrutura:
    
    {
      "analyses": [
        {
          "adId": "id-do-anuncio",
          "score": 75,
          "performance": "good|average|poor",
          "issues": ["problema1", "problema2"],
          "suggestions": ["sugestão1", "sugestão2"],
          "optimizedTitle": "Novo título otimizado",
          "optimizedBid": 1.25,
          "optimizedBudget": 50.00,
          "estimatedImprovement": {
            "clicks": 120,
            "ctr": 0.024,
            "cvr": 0.038,
            "roas": 3.5
          }
        }
      ],
      "overviewStats": {
        "highPerformingAds": 3,
        "poorPerformingAds": 2,
        "topIssues": ["CTR baixo", "ROAS inadequado", "Orçamento mal distribuído"]
      }
    }`;
    
    const chatCompletion = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
      response_format: { type: "json_object" },
      max_tokens: 4000
    });
    
    const responseText = chatCompletion.choices[0].message.content || '';
    
    try {
      // Parse da resposta JSON
      const parsedResponse = JSON.parse(responseText);
      
      // Validação e garantia de estrutura correta
      const analyses: AdAnalysis[] = Array.isArray(parsedResponse.analyses) 
        ? parsedResponse.analyses.map((analysis: any) => ({
            adId: analysis.adId || '',
            score: typeof analysis.score === 'number' ? analysis.score : 50,
            performance: ['good', 'average', 'poor'].includes(analysis.performance) 
              ? analysis.performance as 'good' | 'average' | 'poor'
              : 'average',
            issues: Array.isArray(analysis.issues) ? analysis.issues : [],
            suggestions: Array.isArray(analysis.suggestions) ? analysis.suggestions : [],
            optimizedTitle: analysis.optimizedTitle,
            optimizedBid: typeof analysis.optimizedBid === 'number' ? analysis.optimizedBid : undefined,
            optimizedBudget: typeof analysis.optimizedBudget === 'number' ? analysis.optimizedBudget : undefined,
            estimatedImprovement: analysis.estimatedImprovement || {}
          }))
        : [];
      
      // Calculando estatísticas gerais extras
      const activeAds = ads.filter(ad => ad.status.toLowerCase() === 'active').length;
      const totalSpend = ads.reduce((sum, ad) => sum + ad.spend, 0);
      const totalRevenue = ads.reduce((sum, ad) => sum + ad.revenue, 0);
      const averageRoas = ads.reduce((sum, ad) => sum + ad.roas, 0) / ads.length;
      
      // Estatísticas da visão geral
      const highPerformingAds = parsedResponse.overviewStats?.highPerformingAds || 
        analyses.filter(a => a.performance === 'good').length;
      
      const poorPerformingAds = parsedResponse.overviewStats?.poorPerformingAds || 
        analyses.filter(a => a.performance === 'poor').length;
        
      const topIssues = parsedResponse.overviewStats?.topIssues || [];
      
      const overviewStats: OverviewStats = {
        totalAds: ads.length,
        activeAds,
        totalSpend,
        totalRevenue,
        averageRoas,
        highPerformingAds,
        poorPerformingAds,
        topIssues
      };
      
      return {
        analyses,
        overviewStats
      };
    } catch (parseError) {
      console.error('Erro ao analisar a resposta JSON:', parseError);
      throw new Error('A resposta da IA não estava no formato esperado');
    }
  } catch (error: any) {
    console.error('Erro ao analisar anúncios:', error);
    throw new Error('Falha ao analisar os anúncios: ' + (error.message || 'Erro desconhecido'));
  }
}