import passport from 'passport';
import { Strategy as GoogleStrategy, StrategyOptions, StrategyOptionsWithRequest } from 'passport-google-oauth20';
import { storage } from './storage';
import { DataSourceType } from '@shared/schema';
import { Request, Response, NextFunction } from 'express';

interface GoogleProfile {
  id: string;
  displayName: string;
  name: { 
    familyName?: string;
    givenName?: string;
  };
  emails?: { value: string; verified: boolean }[];
  photos?: { value: string }[];
}

// Tipos de callback para a estratégia do Google
type VerifyCallback = (error: any, user?: any, info?: any) => void;
type VerifyFunction = (accessToken: string, refreshToken: string, profile: GoogleProfile, done: VerifyCallback) => void;

// Função para configurar a autenticação Google
export function setupGoogleAuth() {
  /**
   * IMPORTANTE: Para ativar o login Google, você precisará:
   * 1. Configurar um projeto no Google Cloud Platform
   * 2. Criar credenciais OAuth2 para Web application
   * 3. Definir as variáveis de ambiente GOOGLE_CLIENT_ID e GOOGLE_CLIENT_SECRET
   * 4. Adicionar a URL de callback autorizada no console do Google
   *    - Para ambiente de desenvolvimento: http://localhost:3000/api/auth/google/callback
   *    - Para produção: https://seu-dominio.replit.app/api/auth/google/callback
   */
  
  // Verificar se as credenciais do Google foram configuradas
  const googleClientId = process.env.GOOGLE_CLIENT_ID;
  const googleClientSecret = process.env.GOOGLE_CLIENT_SECRET;
  
  // Se as credenciais não estiverem configuradas, retornar sem configurar o login Google
  if (!googleClientId || !googleClientSecret) {
    console.warn('Credenciais do Google não configuradas. O login Google não estará disponível.');
    return false;
  }
  
  // Construir a URL de callback com base no domínio atual
  const domain = process.env.REPLIT_DOMAINS ? process.env.REPLIT_DOMAINS.split(',')[0] : '';
  const callbackURL = domain 
    ? `https://${domain}/api/auth/google/callback` 
    : '/api/auth/google/callback';
    
  console.log(`Configurando Google Auth com callback URL: ${callbackURL}`);
    
  // Configuração completa e correta do Google OAuth para evitar erros de tipo
  
  // Primeiro, definimos nossa função de verificação que será usada pela estratégia
  const verifyFunction: VerifyFunction = async (accessToken, refreshToken, profile, done) => {
    try {
      console.log("Perfil Google recebido:", {
        id: profile.id,
        displayName: profile.displayName,
        emails: profile.emails?.map(e => e.value)
      });
      
      // Verificar se o usuário já existe pelo email
      const primaryEmail = profile.emails?.[0]?.value;
      
      if (!primaryEmail) {
        console.error("Não foi possível obter o email do perfil Google");
        return done(new Error('Não foi possível obter o email do perfil Google.'));
      }
      
      // Buscar usuário pelo email
      let user = await storage.getUserByEmail(primaryEmail);
      
      if (!user) {
        // Se não existir, criar um novo usuário
        const newUser = {
          username: primaryEmail.split('@')[0],
          email: primaryEmail,
          password: '', // Senha vazia para usuários Google
          name: profile.displayName || primaryEmail.split('@')[0],
          preferredDataSource: DataSourceType.SCRAPING,
          shopeeApiEnabled: false
        };
        
        console.log("Criando novo usuário:", newUser.email);
        user = await storage.createUser(newUser);
        console.log(`Novo usuário Google criado: ${user.email} com ID ${user.id}`);
      } else {
        console.log(`Usuário Google existente encontrado: ${user.email} com ID ${user.id}`);
      }
      
      return done(null, user);
    } catch (error) {
      console.error('Erro na autenticação Google:', error);
      return done(error);
    }
  };
  
  // @ts-ignore - Ignorando erros de tipo para resolver o problema com a estratégia do Google
  passport.use(new GoogleStrategy(
    {
      clientID: googleClientId,
      clientSecret: googleClientSecret,
      callbackURL: callbackURL,
      scope: ['profile', 'email'],
    }, 
    verifyFunction
  ));
  
  // Configuração de serialização e deserialização de usuário
  passport.serializeUser((user: any, done) => {
    try {
      console.log("Serializando usuário:", user.id);
      // Garantir que estamos salvando o ID como string para evitar problemas de tipo
      done(null, String(user.id));
    } catch (error) {
      console.error("Erro ao serializar usuário:", error);
      done(error, null);
    }
  });
  
  passport.deserializeUser(async (id: string, done) => {
    try {
      console.log("Deserializando usuário de ID:", id);
      // Converter o ID de string para número
      const userId = parseInt(id, 10);
      if (isNaN(userId)) {
        throw new Error(`ID de usuário inválido: ${id}`);
      }
      
      // Buscar o usuário no banco
      const user = await storage.getUser(userId);
      if (!user) {
        console.log(`Usuário de ID ${userId} não encontrado`);
        return done(null, false);
      }
      
      console.log(`Usuário encontrado:`, { 
        id: user.id, 
        username: user.username, 
        email: user.email 
      });
      done(null, user);
    } catch (error) {
      console.error("Erro ao deserializar usuário:", error);
      done(error, false);
    }
  });
  
  return true;
}

export function googleAuthMiddleware(req: Request, res: Response, next: NextFunction) {
  console.log("Iniciando autenticação com Google - configurações:");
  console.log(`- Domínio: ${process.env.REPLIT_DOMAINS?.split(',')[0]}`);
  console.log(`- Client ID: ${process.env.GOOGLE_CLIENT_ID?.substring(0, 10)}...`);
  console.log(`- Callback URL: https://${process.env.REPLIT_DOMAINS?.split(',')[0]}/api/auth/google/callback`);
  
  // Usando as opções compatíveis com a interface AuthenticateOptions
  passport.authenticate('google', { 
    scope: ['profile', 'email'],
    accessType: 'offline',
    prompt: 'consent'
  })(req, res, next);
}

export function googleAuthCallbackMiddleware(req: Request, res: Response, next: NextFunction) {
  console.log("Callback do Google Auth recebido");
  
  passport.authenticate('google', {
    // Define-se aqui, mas na verdade estamos tratando manualmente abaixo
    successRedirect: '/dashboard',
    failureRedirect: '/login',
    failureMessage: true,
    scope: ['profile', 'email'] // Garantir que o escopo seja passado também no callback
  }, (err: any, user: any, info: any) => {
    if (err) {
      console.error("Erro na autenticação Google:", err);
      return res.redirect('/login?error=google_auth_failed');
    }
    
    if (!user) {
      console.error("Autenticação falhou:", info);
      return res.redirect('/login?error=no_user');
    }
    
    req.login(user, (loginErr) => {
      if (loginErr) {
        console.error("Erro no login:", loginErr);
        return res.redirect('/login?error=login_failed');
      }
      
      // Salvar ID do usuário na sessão explicitamente e fazer com que a sessão seja salva imediatamente
      if (req.session) {
        req.session.userId = user.id;
        console.log("ID do usuário salvo na sessão:", user.id);
        
        // Força o salvamento da sessão antes do redirecionamento
        req.session.save((saveErr) => {
          if (saveErr) {
            console.error("Erro ao salvar sessão:", saveErr);
            return res.redirect('/login?error=session_save_failed');
          }
          
          console.log("Login com Google realizado com sucesso para o usuário:", user.email);
          console.log("Sessão salva, redirecionando para o callback de autenticação");
          // Redirecionar para o callback de autenticação que irá verificar o estado da autenticação
          // e depois redirecionar para o dashboard
          return res.redirect('/auth-callback?success=true');
        });
      } else {
        console.error("Objeto de sessão não está disponível");
        return res.redirect('/login?error=no_session');
      }
    });
  })(req, res, next);
}