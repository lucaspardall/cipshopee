import { 
  users, User, InsertUser, 
  products, Product, InsertProduct,
  optimizations, Optimization, InsertOptimization,
  storeAnalytics, StoreAnalytics, InsertStoreAnalytics,
  events, Event, InsertEvent,
  news, News, InsertNews,
  agentConfigs, AgentConfig, InsertAgentConfig,
  DataSourceType
} from "@shared/schema";
import { db } from "./db";
import { eq, gt, desc, asc } from "drizzle-orm";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;
  
  // Product operations
  getProducts(userId: number): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductByUrl(url: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, data: Partial<Product>): Promise<Product | undefined>;
  
  // Optimization operations
  getOptimizations(userId: number): Promise<Optimization[]>;
  getOptimization(id: number): Promise<Optimization | undefined>;
  getOptimizationsByProduct(productId: number): Promise<Optimization[]>;
  createOptimization(optimization: InsertOptimization): Promise<Optimization>;
  
  // Store Analytics operations
  getStoreAnalytics(userId: number): Promise<StoreAnalytics | undefined>;
  createStoreAnalytics(analytics: InsertStoreAnalytics): Promise<StoreAnalytics>;
  updateStoreAnalytics(id: number, data: Partial<StoreAnalytics>): Promise<StoreAnalytics | undefined>;
  
  // Events operations
  getEvents(): Promise<Event[]>;
  getUpcomingEvents(): Promise<Event[]>;
  createEvent(event: InsertEvent): Promise<Event>;
  
  // News operations
  getNews(): Promise<News[]>;
  getLatestNews(limit?: number): Promise<News[]>;
  createNews(newsItem: InsertNews): Promise<News>;
  
  // Agent operations
  getAgentConfig(id: number): Promise<AgentConfig | undefined>;
  getAgentConfigByUserId(userId: number): Promise<AgentConfig | undefined>;
  createAgentConfig(config: InsertAgentConfig): Promise<AgentConfig>;
  updateAgentConfig(id: number, data: Partial<AgentConfig>): Promise<AgentConfig | undefined>;
  deleteAgentConfig(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private usersMap: Map<number, User>;
  private productsMap: Map<number, Product>;
  private optimizationsMap: Map<number, Optimization>;
  private storeAnalyticsMap: Map<number, StoreAnalytics>;
  private eventsMap: Map<number, Event>;
  private newsMap: Map<number, News>;
  private agentConfigsMap: Map<number, AgentConfig>;
  
  private userIdCounter: number;
  private productIdCounter: number;
  private optimizationIdCounter: number;
  private storeAnalyticsIdCounter: number;
  private eventIdCounter: number;
  private newsIdCounter: number;
  private agentConfigIdCounter: number;

  constructor() {
    this.usersMap = new Map();
    this.productsMap = new Map();
    this.optimizationsMap = new Map();
    this.storeAnalyticsMap = new Map();
    this.eventsMap = new Map();
    this.newsMap = new Map();
    this.agentConfigsMap = new Map();
    
    this.userIdCounter = 1;
    this.productIdCounter = 1;
    this.optimizationIdCounter = 1;
    this.storeAnalyticsIdCounter = 1;
    this.eventIdCounter = 1;
    this.newsIdCounter = 1;
    this.agentConfigIdCounter = 1;
    
    // Create demo events
    this.createEvent({
      title: "Mega Ofertas Shopee",
      description: "Grande evento de descontos com alta visibilidade.",
      startDate: new Date("2023-03-15"),
      endDate: new Date("2023-03-17"),
      priority: "HIGH",
      category: "SALE"
    });
    
    this.createEvent({
      title: "Frete Grátis",
      description: "Campanha semanal de frete grátis para todo o site.",
      startDate: new Date("2023-03-22"),
      endDate: new Date("2023-03-24"),
      priority: "MEDIUM",
      category: "SHIPPING"
    });
    
    this.createEvent({
      title: "Aniversário Shopee",
      description: "Evento de aniversário com promoções especiais.",
      startDate: new Date("2023-04-10"),
      endDate: new Date("2023-04-17"),
      priority: "HIGH",
      category: "SALE"
    });
    
    // Create demo news
    this.createNews({
      title: "Prepare-se para o Mega Ofertas: Dicas para Maximizar Suas Vendas",
      content: "Confira as estratégias para se destacar no próximo grande evento da Shopee.",
      category: "EVENTS",
      imageUrl: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da",
      url: "/news/1"
    });
    
    this.createNews({
      title: "Shopee Anuncia Mudanças no Algoritmo de Busca: O Que Você Precisa Saber",
      content: "Novas atualizações impactarão o ranqueamento de produtos. Entenda o que mudou.",
      category: "PLATFORM",
      imageUrl: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3",
      url: "/news/2"
    });
    
    this.createNews({
      title: "Novas Políticas de Frete: Como Ajustar sua Estratégia de Envio",
      content: "Shopee implementa mudanças nas regras de frete grátis e taxas para vendedores.",
      category: "POLICY",
      imageUrl: "https://images.unsplash.com/photo-1505236858219-8359eb29e329",
      url: "/news/3"
    });
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.usersMap.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of this.usersMap.values()) {
      if (user.username === username) {
        return user;
      }
    }
    return undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: now,
      storeScore: Math.floor(Math.random() * 40) + 60, // Random score between 60-100
      preferredDataSource: DataSourceType.SCRAPING,
      shopeeApiEnabled: false
    };
    this.usersMap.set(id, user);
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const users = Array.from(this.usersMap.values());
    return users.find(user => user.email?.toLowerCase() === email.toLowerCase());
  }
  
  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data };
    this.usersMap.set(id, updatedUser);
    return updatedUser;
  }
  
  // Product operations
  async getProducts(userId: number): Promise<Product[]> {
    const userProducts: Product[] = [];
    for (const product of this.productsMap.values()) {
      if (product.userId === userId) {
        userProducts.push(product);
      }
    }
    return userProducts;
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    return this.productsMap.get(id);
  }
  
  async getProductByUrl(url: string): Promise<Product | undefined> {
    for (const product of this.productsMap.values()) {
      if (product.shopeeUrl === url) {
        return product;
      }
    }
    return undefined;
  }
  
  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.productIdCounter++;
    const now = new Date();
    const product: Product = {
      ...insertProduct,
      id,
      createdAt: now,
      updatedAt: now,
      views: Math.floor(Math.random() * 200) + 50,
      sales: Math.floor(Math.random() * 50),
      searchRanking: Math.floor(Math.random() * 30) + 1,
      performanceScore: Math.floor(Math.random() * 40) + 60
    };
    
    if (product.views && product.sales) {
      product.conversionRate = product.sales / product.views;
    }
    
    this.productsMap.set(id, product);
    return product;
  }
  
  async updateProduct(id: number, data: Partial<Product>): Promise<Product | undefined> {
    const product = await this.getProduct(id);
    if (!product) return undefined;
    
    const updatedProduct = { 
      ...product, 
      ...data, 
      updatedAt: new Date() 
    };
    this.productsMap.set(id, updatedProduct);
    return updatedProduct;
  }
  
  // Optimization operations
  async getOptimizations(userId: number): Promise<Optimization[]> {
    const userOptimizations: Optimization[] = [];
    for (const optimization of this.optimizationsMap.values()) {
      if (optimization.userId === userId) {
        userOptimizations.push(optimization);
      }
    }
    return userOptimizations;
  }
  
  async getOptimization(id: number): Promise<Optimization | undefined> {
    return this.optimizationsMap.get(id);
  }
  
  async getOptimizationsByProduct(productId: number): Promise<Optimization[]> {
    const productOptimizations: Optimization[] = [];
    for (const optimization of this.optimizationsMap.values()) {
      if (optimization.productId === productId) {
        productOptimizations.push(optimization);
      }
    }
    return productOptimizations;
  }
  
  async createOptimization(insertOptimization: InsertOptimization): Promise<Optimization> {
    const id = this.optimizationIdCounter++;
    const now = new Date();
    const optimization: Optimization = {
      ...insertOptimization,
      id,
      createdAt: now,
      estimatedImprovement: Math.floor(Math.random() * 30) + 10
    };
    this.optimizationsMap.set(id, optimization);
    return optimization;
  }
  
  // Store Analytics operations
  async getStoreAnalytics(userId: number): Promise<StoreAnalytics | undefined> {
    for (const analytics of this.storeAnalyticsMap.values()) {
      if (analytics.userId === userId) {
        return analytics;
      }
    }
    return undefined;
  }
  
  async createStoreAnalytics(insertAnalytics: InsertStoreAnalytics): Promise<StoreAnalytics> {
    const id = this.storeAnalyticsIdCounter++;
    const analytics: StoreAnalytics = {
      ...insertAnalytics,
      id,
      date: new Date()
    };
    this.storeAnalyticsMap.set(id, analytics);
    return analytics;
  }
  
  async updateStoreAnalytics(id: number, data: Partial<StoreAnalytics>): Promise<StoreAnalytics | undefined> {
    const existingAnalytics = this.storeAnalyticsMap.get(id);
    
    if (!existingAnalytics) {
      return undefined;
    }
    
    const updatedAnalytics: StoreAnalytics = {
      ...existingAnalytics,
      ...data,
      lastUpdated: new Date()
    };
    
    this.storeAnalyticsMap.set(id, updatedAnalytics);
    return updatedAnalytics;
  }
  
  // Events operations
  async getEvents(): Promise<Event[]> {
    return Array.from(this.eventsMap.values());
  }
  
  async getUpcomingEvents(): Promise<Event[]> {
    const now = new Date();
    const upcomingEvents: Event[] = [];
    
    for (const event of this.eventsMap.values()) {
      if (new Date(event.startDate) > now) {
        upcomingEvents.push(event);
      }
    }
    
    // Sort by date
    upcomingEvents.sort((a, b) => {
      return new Date(a.startDate).getTime() - new Date(b.startDate).getTime();
    });
    
    return upcomingEvents;
  }
  
  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const id = this.eventIdCounter++;
    const event: Event = {
      ...insertEvent,
      id
    };
    this.eventsMap.set(id, event);
    return event;
  }
  
  // News operations
  async getNews(): Promise<News[]> {
    return Array.from(this.newsMap.values());
  }
  
  async getLatestNews(limit: number = 3): Promise<News[]> {
    const allNews = Array.from(this.newsMap.values());
    
    // Sort by publish date
    allNews.sort((a, b) => {
      return new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime();
    });
    
    return allNews.slice(0, limit);
  }
  
  async createNews(insertNews: InsertNews): Promise<News> {
    const id = this.newsIdCounter++;
    const news: News = {
      ...insertNews,
      id,
      publishDate: new Date()
    };
    this.newsMap.set(id, news);
    return news;
  }
  
  // Agent operations
  async getAgentConfig(id: number): Promise<AgentConfig | undefined> {
    return this.agentConfigsMap.get(id);
  }
  
  async getAgentConfigByUserId(userId: number): Promise<AgentConfig | undefined> {
    for (const config of this.agentConfigsMap.values()) {
      if (config.userId === userId) {
        return config;
      }
    }
    return undefined;
  }
  
  async createAgentConfig(insertConfig: InsertAgentConfig): Promise<AgentConfig> {
    const id = this.agentConfigIdCounter++;
    
    const config: AgentConfig = {
      id,
      ...insertConfig,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    this.agentConfigsMap.set(id, config);
    return config;
  }
  
  async updateAgentConfig(id: number, data: Partial<AgentConfig>): Promise<AgentConfig | undefined> {
    const config = this.agentConfigsMap.get(id);
    
    if (!config) {
      return undefined;
    }
    
    const updatedConfig: AgentConfig = {
      ...config,
      ...data,
      updatedAt: new Date(),
    };
    
    this.agentConfigsMap.set(id, updatedConfig);
    return updatedConfig;
  }
  
  async deleteAgentConfig(id: number): Promise<boolean> {
    return this.agentConfigsMap.delete(id);
  }
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, id));
      return user;
    } catch (error) {
      console.error("Database error in getUser:", error);
      return undefined;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      // We'll do a manual case-insensitive check in JavaScript for simplicity
      console.log("Searching for username:", username);
      const allUsers = await db.select().from(users);
      console.log("All users:", allUsers.map(u => ({ id: u.id, username: u.username })));
      
      const matchingUser = allUsers.find(
        user => user.username.toLowerCase() === username.toLowerCase()
      );
      
      console.log("Matching user found:", matchingUser ? matchingUser.id : 'none');
      return matchingUser;
    } catch (error) {
      console.error("Database error in getUserByUsername:", error);
      return undefined;
    }
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    try {
      // Consulta direta pelo email (que deve ser único)
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.email, email));
      
      return user;
    } catch (error) {
      console.error("Database error in getUserByEmail:", error);
      return undefined;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      const [user] = await db
        .insert(users)
        .values(insertUser)
        .returning();
      return user;
    } catch (error) {
      console.error("Database error in createUser:", error);
      throw error;
    }
  }
  
  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    try {
      const [updatedUser] = await db
        .update(users)
        .set(data)
        .where(eq(users.id, id))
        .returning();
      return updatedUser;
    } catch (error) {
      console.error("Database error in updateUser:", error);
      return undefined;
    }
  }
  
  // Product operations
  async getProducts(userId: number): Promise<Product[]> {
    try {
      return await db
        .select()
        .from(products)
        .where(eq(products.userId, userId));
    } catch (error) {
      console.error("Database error in getProducts:", error);
      return [];
    }
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    try {
      const [product] = await db
        .select()
        .from(products)
        .where(eq(products.id, id));
      return product;
    } catch (error) {
      console.error("Database error in getProduct:", error);
      return undefined;
    }
  }
  
  async getProductByUrl(url: string): Promise<Product | undefined> {
    try {
      const [product] = await db
        .select()
        .from(products)
        .where(eq(products.shopeeUrl, url));
      return product;
    } catch (error) {
      console.error("Database error in getProductByUrl:", error);
      return undefined;
    }
  }
  
  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    try {
      const [product] = await db
        .insert(products)
        .values(insertProduct)
        .returning();
      return product;
    } catch (error) {
      console.error("Database error in createProduct:", error);
      throw error;
    }
  }
  
  async updateProduct(id: number, data: Partial<Product>): Promise<Product | undefined> {
    try {
      const [updatedProduct] = await db
        .update(products)
        .set({
          ...data,
          updatedAt: new Date()
        })
        .where(eq(products.id, id))
        .returning();
      return updatedProduct;
    } catch (error) {
      console.error("Database error in updateProduct:", error);
      return undefined;
    }
  }
  
  // Optimization operations
  async getOptimizations(userId: number): Promise<Optimization[]> {
    try {
      return await db
        .select()
        .from(optimizations)
        .where(eq(optimizations.userId, userId));
    } catch (error) {
      console.error("Database error in getOptimizations:", error);
      return [];
    }
  }
  
  async getOptimization(id: number): Promise<Optimization | undefined> {
    try {
      const [optimization] = await db
        .select()
        .from(optimizations)
        .where(eq(optimizations.id, id));
      return optimization;
    } catch (error) {
      console.error("Database error in getOptimization:", error);
      return undefined;
    }
  }
  
  async getOptimizationsByProduct(productId: number): Promise<Optimization[]> {
    try {
      return await db
        .select()
        .from(optimizations)
        .where(eq(optimizations.productId, productId));
    } catch (error) {
      console.error("Database error in getOptimizationsByProduct:", error);
      return [];
    }
  }
  
  async createOptimization(insertOptimization: InsertOptimization): Promise<Optimization> {
    try {
      const [optimization] = await db
        .insert(optimizations)
        .values(insertOptimization)
        .returning();
      return optimization;
    } catch (error) {
      console.error("Database error in createOptimization:", error);
      throw error;
    }
  }
  
  // Store Analytics operations
  async getStoreAnalytics(userId: number): Promise<StoreAnalytics | undefined> {
    try {
      const [analytics] = await db
        .select()
        .from(storeAnalytics)
        .where(eq(storeAnalytics.userId, userId))
        .orderBy(desc(storeAnalytics.date))
        .limit(1);
      return analytics;
    } catch (error) {
      console.error("Database error in getStoreAnalytics:", error);
      return undefined;
    }
  }
  
  async createStoreAnalytics(insertAnalytics: InsertStoreAnalytics): Promise<StoreAnalytics> {
    try {
      const [analytics] = await db
        .insert(storeAnalytics)
        .values(insertAnalytics)
        .returning();
      return analytics;
    } catch (error) {
      console.error("Database error in createStoreAnalytics:", error);
      throw error;
    }
  }
  
  async updateStoreAnalytics(id: number, data: Partial<StoreAnalytics>): Promise<StoreAnalytics | undefined> {
    try {
      const [updatedAnalytics] = await db
        .update(storeAnalytics)
        .set({
          ...data
        })
        .where(eq(storeAnalytics.id, id))
        .returning();
      return updatedAnalytics;
    } catch (error) {
      console.error("Database error in updateStoreAnalytics:", error);
      return undefined;
    }
  }
  
  // Events operations
  async getEvents(): Promise<Event[]> {
    try {
      return await db
        .select()
        .from(events);
    } catch (error) {
      console.error("Database error in getEvents:", error);
      return [];
    }
  }
  
  async getUpcomingEvents(): Promise<Event[]> {
    try {
      const now = new Date();
      return await db
        .select()
        .from(events)
        .where(gt(events.startDate, now))
        .orderBy(asc(events.startDate));
    } catch (error) {
      console.error("Database error in getUpcomingEvents:", error);
      return [];
    }
  }
  
  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    try {
      const [event] = await db
        .insert(events)
        .values(insertEvent)
        .returning();
      return event;
    } catch (error) {
      console.error("Database error in createEvent:", error);
      throw error;
    }
  }
  
  // News operations
  async getNews(): Promise<News[]> {
    try {
      return await db
        .select()
        .from(news);
    } catch (error) {
      console.error("Database error in getNews:", error);
      return [];
    }
  }
  
  async getLatestNews(limit: number = 3): Promise<News[]> {
    try {
      return await db
        .select()
        .from(news)
        .orderBy(desc(news.publishDate))
        .limit(limit);
    } catch (error) {
      console.error("Database error in getLatestNews:", error);
      return [];
    }
  }
  
  async createNews(insertNews: InsertNews): Promise<News> {
    try {
      const [newsItem] = await db
        .insert(news)
        .values(insertNews)
        .returning();
      return newsItem;
    } catch (error) {
      console.error("Database error in createNews:", error);
      throw error;
    }
  }
  
  // Agent operations
  async getAgentConfig(id: number): Promise<AgentConfig | undefined> {
    try {
      const [config] = await db.select().from(agentConfigs).where(eq(agentConfigs.id, id));
      return config;
    } catch (error) {
      console.error("Database error in getAgentConfig:", error);
      return undefined;
    }
  }
  
  async getAgentConfigByUserId(userId: number): Promise<AgentConfig | undefined> {
    try {
      const [config] = await db.select().from(agentConfigs).where(eq(agentConfigs.userId, userId));
      return config;
    } catch (error) {
      console.error("Database error in getAgentConfigByUserId:", error);
      return undefined;
    }
  }
  
  async createAgentConfig(insertConfig: InsertAgentConfig): Promise<AgentConfig> {
    try {
      const [config] = await db
        .insert(agentConfigs)
        .values(insertConfig)
        .returning();
      return config;
    } catch (error) {
      console.error("Database error in createAgentConfig:", error);
      throw error;
    }
  }
  
  async updateAgentConfig(id: number, data: Partial<AgentConfig>): Promise<AgentConfig | undefined> {
    try {
      const [updatedConfig] = await db
        .update(agentConfigs)
        .set({
          ...data,
          updatedAt: new Date()
        })
        .where(eq(agentConfigs.id, id))
        .returning();
      return updatedConfig;
    } catch (error) {
      console.error("Database error in updateAgentConfig:", error);
      return undefined;
    }
  }
  
  async deleteAgentConfig(id: number): Promise<boolean> {
    try {
      await db.delete(agentConfigs).where(eq(agentConfigs.id, id));
      return true;
    } catch (error) {
      console.error("Database error in deleteAgentConfig:", error);
      return false;
    }
  }
}

// Initialize storage with database implementation
export const storage = new DatabaseStorage();
