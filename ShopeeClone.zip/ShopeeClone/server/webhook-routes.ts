// Rotas de webhook para CIP Shopee
import type { Express, Request, Response, NextFunction } from "express";
import { sendToWebhook } from "./lib/ai";
import { analyzeShopeeAds, ShopeeAd } from "./lib/ad-analyzer";
import { storage } from "./storage";

// Middleware de autenticação
function isAuthenticated(req: any, res: Response, next: NextFunction) {
  if (!req.session.userId && !req.user?.claims?.sub) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  next();
}

/**
 * Registra rotas de webhook para integrações com o n8n
 * @param app Express app
 */
export function registerWebhookRoutes(app: Express) {
  // Endpoint para analisar anúncios da Shopee via webhook para n8n
  app.post('/api/analyze-ads-webhook', isAuthenticated, async (req, res) => {
    try {
      const { ads, source, requestType, userId } = req.body;
      
      if (!ads || !Array.isArray(ads) || ads.length === 0) {
        return res.status(400).json({ 
          message: "Dados de anúncios inválidos ou não fornecidos"
        });
      }
      
      const sessionUserId = req.session.userId;
      
      if (sessionUserId && userId && sessionUserId !== userId) {
        return res.status(403).json({ 
          message: "Usuário não autorizado para esta operação"
        });
      }
      
      console.log(`Recebida solicitação webhook para analisar ${ads.length} anúncios`);
      
      // Validar estrutura mínima dos anúncios
      const validAds = ads.map((ad: any) => ({
        adId: ad.adId || ad.id || `ad-${Math.random().toString(36).substring(2, 10)}`,
        title: ad.title || "Anúncio sem título",
        budget: parseFloat(ad.budget || "0"),
        spend: parseFloat(ad.spend || "0"),
        impressions: parseInt(ad.impressions || "0"),
        clicks: parseInt(ad.clicks || "0"),
        orders: parseInt(ad.orders || "0"),
        revenue: parseFloat(ad.revenue || "0"),
        ctr: parseFloat(ad.ctr || "0") || (parseInt(ad.clicks || "0") / Math.max(1, parseInt(ad.impressions || "1"))),
        cvr: parseFloat(ad.cvr || "0") || (parseInt(ad.orders || "0") / Math.max(1, parseInt(ad.clicks || "1"))),
        cpc: parseFloat(ad.cpc || "0") || (parseFloat(ad.spend || "0") / Math.max(1, parseInt(ad.clicks || "1"))),
        roas: parseFloat(ad.roas || "0") || (parseFloat(ad.revenue || "0") / Math.max(0.01, parseFloat(ad.spend || "1"))),
        status: ad.status || "active",
        startDate: ad.startDate || ad.start_date,
        endDate: ad.endDate || ad.end_date
      }));
      
      // Preparar dados para enviar ao webhook do n8n
      const webhookData = {
        event: "analyze_ads_request",
        source: source || "cip-shopee-app",
        requestType: requestType || "ad-analysis",
        timestamp: new Date().toISOString(),
        userId: sessionUserId || userId || 0,
        data: {
          adsCount: validAds.length,
          ads: validAds
        },
        callbackUrl: `${process.env.APP_URL || `https://${process.env.REPLIT_DOMAINS?.split(',')[0]}`}/api/analyze-ads-callback`
      };
      
      // Enviar para o webhook do n8n via função auxiliar do AI
      const webhookSuccess = await sendToWebhook(webhookData, 'ad-analyzer');
      
      if (webhookSuccess) {
        res.json({
          success: true,
          message: "Solicitação de análise enviada com sucesso para processamento via n8n",
          requestId: `req-${Date.now()}-${Math.random().toString(36).substring(2, 10)}`,
          processingStatus: "pending",
          adsCount: validAds.length
        });
      } else {
        // Fallback: analisar diretamente se o webhook falhar
        console.log("Webhook falhou, executando análise direta");
        
        // Realizar análise dos anúncios com IA diretamente
        const { analyses, overviewStats } = await analyzeShopeeAds(validAds);
        
        res.json({
          success: true,
          message: `Webhook indisponível. Análise de ${ads.length} anúncios concluída diretamente`,
          analyses,
          overviewStats,
          processingMethod: "direct"
        });
      }
    } catch (error: any) {
      console.error("Erro ao processar solicitação de análise via webhook:", error);
      res.status(500).json({ 
        message: "Erro ao processar solicitação", 
        error: error.message 
      });
    }
  });
  
  // Endpoint para receber callback de análise de anúncios do n8n
  app.post('/api/analyze-ads-callback', async (req, res) => {
    try {
      const { data, requestId, source, signature } = req.body;
      
      // Validar origem (opcional)
      if (source !== 'n8n' && req.headers['x-webhook-source'] !== 'n8n') {
        console.warn("Callback recebido de fonte não reconhecida:", source || req.headers['x-webhook-source']);
      }
      
      console.log(`Recebido callback de análise de anúncios. Request ID: ${requestId}`);
      
      // Validar dados recebidos
      if (!data || !data.analyses || !data.overviewStats) {
        return res.status(400).json({ 
          message: "Dados de análise inválidos ou incompletos no callback"
        });
      }
      
      // Aqui você pode armazenar os resultados no banco de dados
      // E/ou notificar o frontend via websocket
      
      // Temporariamente, apenas confirmar recebimento
      res.json({
        success: true,
        message: "Callback de análise processado com sucesso",
        requestId: requestId || "unknown",
        timestamp: new Date().toISOString()
      });
    } catch (error: any) {
      console.error("Erro ao processar callback de análise:", error);
      res.status(500).json({ 
        message: "Erro ao processar callback", 
        error: error.message 
      });
    }
  });

  // Webhook para exportação de produtos
  app.post('/api/export-products-webhook', isAuthenticated, async (req, res) => {
    try {
      const { products, source, destination, exportConfig } = req.body;
      const userId = req.session.userId;
      
      if (!products || !Array.isArray(products) || products.length === 0) {
        return res.status(400).json({
          message: "Dados de produtos inválidos ou não fornecidos"
        });
      }
      
      // Preparar dados para webhook
      const webhookData = {
        event: "export_products_request",
        source: source || "cip-shopee-app",
        timestamp: new Date().toISOString(),
        userId: userId,
        data: {
          productCount: products.length,
          products: products,
          destination: destination || "shopee",
          config: exportConfig || {}
        },
        callbackUrl: `${process.env.APP_URL || `https://${process.env.REPLIT_DOMAINS?.split(',')[0]}`}/api/export-callback`
      };
      
      // Enviar para webhook
      const webhookSuccess = await sendToWebhook(webhookData, "export-products");
      
      if (webhookSuccess) {
        res.json({
          success: true,
          message: "Solicitação de exportação enviada com sucesso",
          requestId: `exp-${Date.now()}-${Math.random().toString(36).substring(2, 10)}`,
          processingStatus: "pending",
          productCount: products.length
        });
      } else {
        res.status(500).json({
          message: "Não foi possível enviar a solicitação para o webhook",
          alternateAction: "Tente novamente mais tarde ou utilize a exportação manual"
        });
      }
    } catch (error: any) {
      console.error("Erro ao processar solicitação de exportação:", error);
      res.status(500).json({
        message: "Erro ao processar solicitação de exportação",
        error: error.message
      });
    }
  });
  
  // Endpoint de callback para exportação
  app.post('/api/export-callback', async (req, res) => {
    try {
      const { data, requestId, source } = req.body;
      
      console.log(`Recebido callback de exportação. Request ID: ${requestId}`);
      
      // Validar dados
      if (!data || !data.results) {
        return res.status(400).json({
          message: "Dados de exportação inválidos ou incompletos"
        });
      }
      
      // Confirmar recebimento
      res.json({
        success: true,
        message: "Callback de exportação processado com sucesso",
        requestId: requestId || "unknown",
        timestamp: new Date().toISOString()
      });
    } catch (error: any) {
      console.error("Erro ao processar callback de exportação:", error);
      res.status(500).json({
        message: "Erro ao processar callback",
        error: error.message
      });
    }
  });

  // Webhook para otimização de listings
  app.post('/api/optimize-listing-webhook', isAuthenticated, async (req, res) => {
    try {
      const { productUrl, product, optimizationOptions } = req.body;
      const userId = req.session.userId;
      
      if (!productUrl && !product) {
        return res.status(400).json({
          message: "É necessário fornecer um URL de produto ou dados do produto"
        });
      }
      
      // Preparar dados
      const webhookData = {
        event: "optimize_listing_request",
        source: "cip-shopee-app",
        timestamp: new Date().toISOString(),
        userId: userId,
        data: {
          productUrl: productUrl,
          product: product,
          options: optimizationOptions || {
            optimizeTitle: true,
            optimizeDescription: true,
            optimizeKeywords: true,
            suggestPrice: true
          }
        },
        callbackUrl: `${process.env.APP_URL || `https://${process.env.REPLIT_DOMAINS?.split(',')[0]}`}/api/optimization-callback`
      };
      
      // Enviar para webhook
      const webhookSuccess = await sendToWebhook(webhookData, "optimize-listing");
      
      if (webhookSuccess) {
        res.json({
          success: true,
          message: "Solicitação de otimização enviada com sucesso",
          requestId: `opt-${Date.now()}-${Math.random().toString(36).substring(2, 10)}`,
          processingStatus: "pending",
          productUrl: productUrl || "URL não fornecido"
        });
      } else {
        res.status(500).json({
          message: "Não foi possível enviar a solicitação para o webhook",
          alternateAction: "Tente novamente mais tarde ou utilize a otimização direta"
        });
      }
    } catch (error: any) {
      console.error("Erro ao processar solicitação de otimização:", error);
      res.status(500).json({
        message: "Erro ao processar solicitação",
        error: error.message
      });
    }
  });
  
  // Callback de otimização
  app.post('/api/optimization-callback', async (req, res) => {
    try {
      const { data, requestId, source, userId } = req.body;
      
      console.log(`Recebido callback de otimização. Request ID: ${requestId}`);
      
      // Validar dados
      if (!data || !data.optimization) {
        return res.status(400).json({
          message: "Dados de otimização inválidos ou incompletos"
        });
      }

      // Extrair dados
      const { productUrl, optimization, scrapedData } = data;
      
      if (!productUrl) {
        return res.status(400).json({
          message: "URL do produto não fornecido no callback"
        });
      }

      // Verificar e buscar produtos existentes
      const product = await storage.getProductByUrl(productUrl);
      
      if (!product) {
        console.error(`Produto não encontrado para URL: ${productUrl}`);
        return res.status(404).json({
          message: "Produto não encontrado para a URL fornecida",
          productUrl
        });
      }
      
      // Atualizar o produto com dados obtidos pelo scraping (se disponíveis)
      if (scrapedData) {
        await storage.updateProduct(product.id, {
          title: scrapedData.title || product.title,
          description: scrapedData.description || product.description,
          price: scrapedData.price || product.price,
          originalTitle: scrapedData.title || product.originalTitle,
          originalDescription: scrapedData.description || product.originalDescription,
          keywords: scrapedData.keywords || product.keywords,
          dataSource: "SCRAPING",
          updatedAt: new Date()
        });
      }
      
      // Criar otimização com os dados retornados pelo assistente
      const newOptimization = await storage.createOptimization({
        userId: product.userId,
        productId: product.id,
        optimizedTitle: optimization.title || null,
        optimizedDescription: optimization.description || null,
        suggestedPrice: optimization.price || null,
        optimizedKeywords: Array.isArray(optimization.keywords) ? optimization.keywords : null,
        generalImprovements: Array.isArray(optimization.improvements) ? optimization.improvements : null,
        // Plano de boost de 7 dias
        boostPlan: Array.isArray(optimization.boostPlan) ? optimization.boostPlan : null,
        // Campos de justificativa
        titleJustification: optimization.titleJustification || null,
        descriptionJustification: optimization.descriptionJustification || null,
        priceJustification: optimization.priceJustification || null,
        keywordsJustification: optimization.keywordsJustification || null,
        improvementsJustification: optimization.improvementsJustification || null,
        // Justificativa geral (mantida para compatibilidade)
        justification: optimization.justification || null,
        dataSource: "ASSISTANT",
        estimatedImprovement: optimization.estimatedImprovement || 15
      });
      
      console.log(`Otimização criada com sucesso: ID ${newOptimization.id} para produto ID ${product.id}`);
      
      // Confirmar recebimento
      res.json({
        success: true,
        message: "Callback de otimização processado com sucesso",
        requestId: requestId || "unknown",
        timestamp: new Date().toISOString(),
        optimizationId: newOptimization.id
      });
    } catch (error: any) {
      console.error("Erro ao processar callback de otimização:", error);
      res.status(500).json({
        message: "Erro ao processar callback",
        error: error.message
      });
    }
  });

  // Webhook para análise da loja
  app.post('/api/analyze-store-webhook', isAuthenticated, async (req, res) => {
    try {
      const { storeUrl, storeData, analysisOptions } = req.body;
      const userId = req.session.userId;
      
      if (!storeUrl && !storeData) {
        return res.status(400).json({
          message: "É necessário fornecer uma URL da loja ou dados da loja"
        });
      }
      
      // Preparar dados
      const webhookData = {
        event: "analyze_store_request",
        source: "cip-shopee-app",
        timestamp: new Date().toISOString(),
        userId: userId,
        data: {
          storeUrl: storeUrl,
          storeData: storeData,
          options: analysisOptions || {
            analyzeProducts: true,
            analyzeCompetitors: true,
            analyzePerformance: true,
            suggestImprovements: true
          }
        },
        callbackUrl: `${process.env.APP_URL || `https://${process.env.REPLIT_DOMAINS?.split(',')[0]}`}/api/store-analysis-callback`
      };
      
      // Enviar para webhook
      const webhookSuccess = await sendToWebhook(webhookData, 'analyze-store');
      
      if (webhookSuccess) {
        res.json({
          success: true,
          message: "Solicitação de análise da loja enviada com sucesso",
          requestId: `sto-${Date.now()}-${Math.random().toString(36).substring(2, 10)}`,
          processingStatus: "pending",
          storeUrl: storeUrl || "URL não fornecido"
        });
      } else {
        res.status(500).json({
          message: "Não foi possível enviar a solicitação para o webhook",
          alternateAction: "Tente novamente mais tarde ou entre em contato com o suporte"
        });
      }
    } catch (error: any) {
      console.error("Erro ao processar solicitação de análise da loja:", error);
      res.status(500).json({
        message: "Erro ao processar solicitação",
        error: error.message
      });
    }
  });
  
  // Callback de análise da loja
  app.post('/api/store-analysis-callback', async (req, res) => {
    try {
      const { data, requestId, source } = req.body;
      
      console.log(`Recebido callback de análise da loja. Request ID: ${requestId}`);
      
      // Validar dados
      if (!data || !data.analysis) {
        return res.status(400).json({
          message: "Dados de análise inválidos ou incompletos"
        });
      }
      
      // Confirmar recebimento
      res.json({
        success: true,
        message: "Callback de análise da loja processado com sucesso",
        requestId: requestId || "unknown",
        timestamp: new Date().toISOString()
      });
    } catch (error: any) {
      console.error("Erro ao processar callback de análise da loja:", error);
      res.status(500).json({
        message: "Erro ao processar callback",
        error: error.message
      });
    }
  });
  
  // Webhook para criação de novos anúncios
  app.post('/api/create-listing-webhook', isAuthenticated, async (req, res) => {
    try {
      const { productInfo, productUrl, creationOptions } = req.body;
      const userId = req.session.userId;
      
      if (!productInfo && !productUrl) {
        return res.status(400).json({
          message: "É necessário fornecer informações do produto ou URL de referência"
        });
      }
      
      // Preparar dados
      const webhookData = {
        event: "create_listing_request",
        source: "cip-shopee-app",
        timestamp: new Date().toISOString(),
        userId: userId,
        data: {
          productInfo: productInfo,
          productUrl: productUrl,
          options: creationOptions || {
            optimizeForSEO: true,
            suggestPricing: true,
            generateVariations: true
          }
        },
        callbackUrl: `${process.env.APP_URL || `https://${process.env.REPLIT_DOMAINS?.split(',')[0]}`}/api/creation-callback`
      };
      
      // Enviar para webhook
      const webhookSuccess = await sendToWebhook(webhookData, 'create-listing');
      
      if (webhookSuccess) {
        res.json({
          success: true,
          message: "Solicitação de criação de anúncio enviada com sucesso",
          requestId: `crt-${Date.now()}-${Math.random().toString(36).substring(2, 10)}`,
          processingStatus: "pending"
        });
      } else {
        res.status(500).json({
          message: "Não foi possível enviar a solicitação para o webhook",
          alternateAction: "Tente novamente mais tarde ou use a criação direta"
        });
      }
    } catch (error: any) {
      console.error("Erro ao processar solicitação de criação:", error);
      res.status(500).json({
        message: "Erro ao processar solicitação",
        error: error.message
      });
    }
  });
  
  // Callback de criação de anúncio
  app.post('/api/creation-callback', async (req, res) => {
    try {
      const { data, requestId, source } = req.body;
      
      console.log(`Recebido callback de criação de anúncio. Request ID: ${requestId}`);
      
      // Validar dados
      if (!data || !data.listing) {
        return res.status(400).json({
          message: "Dados de criação inválidos ou incompletos"
        });
      }
      
      // Confirmar recebimento
      res.json({
        success: true,
        message: "Callback de criação processado com sucesso",
        requestId: requestId || "unknown",
        timestamp: new Date().toISOString()
      });
    } catch (error: any) {
      console.error("Erro ao processar callback de criação:", error);
      res.status(500).json({
        message: "Erro ao processar callback",
        error: error.message
      });
    }
  });
}