import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateOptimizedListing, generateNewListing, sendToWebhook, analyzeShopeeStore } from "./lib/ai";
import { n8nClient } from "./lib/n8n";
import { analyzeShopeeAds, ShopeeAd } from "./lib/ad-analyzer";
import { registerWebhookRoutes } from "./webhook-routes";
import { registerShopeeRoutes } from "./shopee-routes";
import bcrypt from "bcryptjs";
import { insertUserSchema, insertAgentConfigSchema } from "@shared/schema";
import { setupGoogleAuth, googleAuthMiddleware, googleAuthCallbackMiddleware } from "./auth-google";
import { testAssistantResponse, formatAssistantResponse } from "./lib/test-assistant";
import OpenAI from "openai";
import axios from "axios";
import 'express-session';

// Estender o tipo Session para incluir nossas propriedades personalizadas
declare module 'express-session' {
  interface SessionData {
    userId?: number | undefined;
    authenticated?: boolean;
    authMethod?: string;
    userName?: string;
    userEmail?: string;
    lastLogin?: string;
  }
}

// Interface para a resposta formatada do assistente
interface FormattedAssistantResponse {
  optimizedTitle?: string;
  optimizedDescription?: string;
  suggestedPrice?: number;
  discountPrice?: number;
  keywords?: string[];
  improvements?: string[];
  boostPlan?: string[];
  titleJustification?: string;
  descriptionJustification?: string;
  priceJustification?: string;
  keywordsJustification?: string;
  improvementsJustification?: string;
  justification?: string;
  [key: string]: any;
}

// Função auxiliar para processar resposta do assistente
async function processAssistantResponse(
  content: string, 
  originalTitle?: string,
  originalDescription?: string,
  originalPrice?: number
): Promise<FormattedAssistantResponse> {
  try {
    return await formatAssistantResponse(content);
  } catch (error) {
    console.error("Erro ao processar resposta do assistente:", error);
    return {
      optimizedTitle: originalTitle || "Erro ao processar título",
      optimizedDescription: originalDescription || "Erro ao processar descrição",
      suggestedPrice: originalPrice || 0,
      improvements: ["Erro ao processar melhorias"],
      justification: "Ocorreu um erro ao processar a resposta do assistente. Por favor, tente novamente."
    };
  }
}

// Middleware para verificar autenticação
function isAuthenticated(req: any, res: Response, next: NextFunction) {
  if (req.session.userId) {
    return next();
  }
  return res.status(401).json({ message: "Não autorizado" });
}

// Middleware de proteção CSRF
function csrfProtection(req: Request, res: Response, next: NextFunction) {
  // Verificar se o cabeçalho de origem está presente
  const origin = req.headers.origin;
  
  // Se não houver origem (ex: requisição não-navegador), permitir
  if (!origin) {
    return next();
  }
  
  // Lista de domínios permitidos
  const allowedOrigins = [
    'https://cip-shopee.replit.app',
    'https://cip-shopee.vercel.app',
  ];
  
  // Em desenvolvimento, permitir localhost
  if (process.env.NODE_ENV === 'development') {
    allowedOrigins.push('http://localhost:3000');
    allowedOrigins.push('http://localhost:5000');
  }
  
  // Verificar se a origem está na lista de permitidos
  if (allowedOrigins.includes(origin)) {
    return next();
  }
  
  // Origem não permitida
  return res.status(403).json({ message: "Origem não autorizada" });
}

// Limitador de taxa simples
const requestCounts = new Map<string, { count: number, resetTime: number }>();

function rateLimiter(req: Request, res: Response, next: NextFunction) {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const windowMs = 60 * 1000; // 1 minuto
  const maxRequests = 60; // 60 requisições por minuto
  
  if (!requestCounts.has(ip)) {
    requestCounts.set(ip, { count: 1, resetTime: now + windowMs });
    return next();
  }
  
  const requestData = requestCounts.get(ip)!;
  
  if (now > requestData.resetTime) {
    requestData.count = 1;
    requestData.resetTime = now + windowMs;
    return next();
  }
  
  if (requestData.count < maxRequests) {
    requestData.count++;
    return next();
  }
  
  return res.status(429).json({
    message: "Muitas requisições, tente novamente mais tarde."
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Aplicar middlewares gerais
  app.use(csrfProtection);
  app.use(rateLimiter);
  
  // Rota de verificação de saúde do sistema
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok' });
  });

  // API básica de autenticação
  app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ message: "Nome de usuário e senha são obrigatórios" });
    }
    
    try {
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(401).json({ message: "Credenciais inválidas" });
      }
      
      const isPasswordValid = await bcrypt.compare(password, user.passwordHash || '');
      
      if (!isPasswordValid) {
        return res.status(401).json({ message: "Credenciais inválidas" });
      }
      
      // Configurar a sessão
      req.session.userId = user.id;
      req.session.authenticated = true;
      req.session.authMethod = 'local';
      req.session.userName = user.username;
      req.session.userEmail = user.email;
      req.session.lastLogin = new Date().toISOString();
      
      return res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        name: user.name,
        role: user.role
      });
    } catch (error) {
      console.error("Erro ao realizar login:", error);
      return res.status(500).json({ message: "Erro interno do servidor" });
    }
  });
  
  // Autenticação com Google
  app.get('/api/auth/google', googleAuthMiddleware);
  app.get('/api/auth/google/callback', googleAuthCallbackMiddleware);

  app.post('/api/logout', (req, res) => {
    req.session.destroy(err => {
      if (err) {
        return res.status(500).json({ message: "Erro ao encerrar sessão" });
      }
      res.json({ message: "Logout realizado com sucesso" });
    });
  });

  app.get('/api/session', (req, res) => {
    if (req.session.userId) {
      res.json({
        authenticated: true,
        userId: req.session.userId,
        username: req.session.userName,
        email: req.session.userEmail,
        authMethod: req.session.authMethod
      });
    } else {
      res.json({
        authenticated: false
      });
    }
  });

  // Configuração da API REST - OTIMIZAÇÃO DE PRODUTOS

  // Rota para otimização direta com entrada manual
  app.post('/api/optimize-direct', isAuthenticated, async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      // Obter dados diretamente do corpo da requisição
      const { 
        productUrl, 
        productTitle, 
        productDescription, 
        productPrice,
      } = req.body;

      // Validações básicas
      if (!productTitle || !productDescription) {
        return res.status(400).json({ 
          message: "Título e descrição do produto são obrigatórios" 
        });
      }

      const priceNumber = parseFloat(productPrice);
      if (isNaN(priceNumber) || priceNumber <= 0) {
        return res.status(400).json({ message: "Preço do produto inválido" });
      }

      // Gerar otimização usando o assistente da OpenAI
      console.log("Gerando listagem otimizada com IA...");
      const optimizedListing = await generateOptimizedListing(
        productTitle,
        productDescription,
        priceNumber
      );

      // Verificar se o produto já existe
      let product = await storage.getProductByUrl(productUrl);
      
      if (!product) {
        // Criar o produto se não existir
        product = await storage.createProduct({
          userId: req.session.userId,
          title: productTitle,
          description: productDescription,
          price: priceNumber,
          shopeeUrl: productUrl,
          dataSource: "MANUAL",
          originalTitle: productTitle,
          originalDescription: productDescription,
          keywords: optimizedListing.keywords
        });
      }

      // Criar uma nova otimização
      const optimization = await storage.createOptimization({
        userId: req.session.userId,
        productId: product.id,
        optimizedTitle: optimizedListing.optimizedTitle,
        optimizedDescription: optimizedListing.optimizedDescription,
        suggestedPrice: optimizedListing.suggestedPrice,
        optimizedKeywords: optimizedListing.keywords,
        generalImprovements: optimizedListing.generalImprovements,
        // Plano de boost de 7 dias
        boostPlan: optimizedListing.boostPlan,
        // Campos de justificativa individual
        titleJustification: optimizedListing.titleJustification,
        descriptionJustification: optimizedListing.descriptionJustification,
        priceJustification: optimizedListing.priceJustification,
        keywordsJustification: optimizedListing.keywordsJustification,
        improvementsJustification: optimizedListing.improvementsJustification,
        // Campo de justificativa geral (mantido para compatibilidade)
        justification: optimizedListing.justification,
        dataSource: "MANUAL"
      });

      res.status(200).json({
        success: true,
        product,
        optimization,
        method: "manual"
      });
    } catch (error) {
      console.error("Error optimizing:", error);
      res.status(500).json({ message: "Server error during optimization" });
    }
  });

  // Rota de otimização legada - agora redirecionada para entrada manual
  app.post('/api/optimize', async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    // A função de scraping foi removida conforme solicitado
    // Agora redireciona para usar a entrada manual
    return res.status(400).json({ 
      message: "Este método não está mais disponível. Use a entrada manual de dados.",
      redirectToManual: true
    });
  });

  // Rota para criar uma nova listagem do zero
  app.post('/api/create-listing', isAuthenticated, async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const { productInfo } = req.body;

      if (!productInfo) {
        return res.status(400).json({ message: "Informações do produto são obrigatórias" });
      }

      // Verificar se temos todas as informações necessárias
      const { 
        category, 
        targetAudience, 
        productFeatures, 
        priceRange, 
        competitors 
      } = productInfo;

      if (!category || !targetAudience || !productFeatures || !priceRange) {
        return res.status(400).json({ 
          message: "Informações incompletas. Categoria, público-alvo, características e faixa de preço são obrigatórios"
        });
      }

      // Chamar o assistente para gerar a listagem
      const newListing = await generateNewListing(
        category,
        targetAudience,
        productFeatures,
        priceRange,
        competitors || []
      );

      // Retornar a listagem gerada
      res.status(200).json({
        success: true,
        listing: newListing
      });
    } catch (error) {
      console.error("Erro ao criar listagem:", error);
      res.status(500).json({ message: "Erro ao criar listagem" });
    }
  });

  // Registrar outras rotas específicas
  registerWebhookRoutes(app);
  registerShopeeRoutes(app);
  
  // API de produtos
  app.get('/api/products', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.userId;
      const products = await storage.getProducts(userId);
      res.json(products);
    } catch (error) {
      console.error("Erro ao buscar produtos:", error);
      res.status(500).json({ message: "Erro ao buscar produtos" });
    }
  });

  app.get('/api/products/:id', isAuthenticated, async (req: any, res) => {
    try {
      const productId = parseInt(req.params.id);
      const product = await storage.getProduct(productId);
      
      if (!product) {
        return res.status(404).json({ message: "Produto não encontrado" });
      }
      
      if (product.userId !== req.session.userId) {
        return res.status(403).json({ message: "Acesso negado" });
      }
      
      res.json(product);
    } catch (error) {
      console.error("Erro ao buscar produto:", error);
      res.status(500).json({ message: "Erro ao buscar produto" });
    }
  });

  // API de otimizações
  app.get('/api/optimizations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.userId;
      const optimizations = await storage.getOptimizations(userId);
      res.json(optimizations);
    } catch (error) {
      console.error("Erro ao buscar otimizações:", error);
      res.status(500).json({ message: "Erro ao buscar otimizações" });
    }
  });

  app.get('/api/optimizations/:id', isAuthenticated, async (req: any, res) => {
    try {
      const optimizationId = parseInt(req.params.id);
      const optimization = await storage.getOptimization(optimizationId);
      
      if (!optimization) {
        return res.status(404).json({ message: "Otimização não encontrada" });
      }
      
      if (optimization.userId !== req.session.userId) {
        return res.status(403).json({ message: "Acesso negado" });
      }
      
      res.json(optimization);
    } catch (error) {
      console.error("Erro ao buscar otimização:", error);
      res.status(500).json({ message: "Erro ao buscar otimização" });
    }
  });

  app.get('/api/products/:id/optimizations', isAuthenticated, async (req: any, res) => {
    try {
      const productId = parseInt(req.params.id);
      const product = await storage.getProduct(productId);
      
      if (!product) {
        return res.status(404).json({ message: "Produto não encontrado" });
      }
      
      if (product.userId !== req.session.userId) {
        return res.status(403).json({ message: "Acesso negado" });
      }
      
      const optimizations = await storage.getOptimizationsByProduct(productId);
      res.json(optimizations);
    } catch (error) {
      console.error("Erro ao buscar otimizações do produto:", error);
      res.status(500).json({ message: "Erro ao buscar otimizações do produto" });
    }
  });

  // API de eventos e notícias (públicas)
  app.get('/api/events', async (_req, res) => {
    try {
      const events = await storage.getEvents();
      res.json(events);
    } catch (error) {
      console.error("Erro ao buscar eventos:", error);
      res.status(500).json({ message: "Erro ao buscar eventos" });
    }
  });

  app.get('/api/events/upcoming', async (_req, res) => {
    try {
      const events = await storage.getUpcomingEvents();
      res.json(events);
    } catch (error) {
      console.error("Erro ao buscar próximos eventos:", error);
      res.status(500).json({ message: "Erro ao buscar próximos eventos" });
    }
  });

  app.get('/api/news', async (_req, res) => {
    try {
      const news = await storage.getNews();
      res.json(news);
    } catch (error) {
      console.error("Erro ao buscar notícias:", error);
      res.status(500).json({ message: "Erro ao buscar notícias" });
    }
  });

  app.get('/api/news/latest', async (_req, res) => {
    try {
      const limit = 3;
      const news = await storage.getLatestNews(limit);
      res.json(news);
    } catch (error) {
      console.error("Erro ao buscar últimas notícias:", error);
      res.status(500).json({ message: "Erro ao buscar últimas notícias" });
    }
  });

  // Configuração do servidor HTTP
  const httpServer = createServer(app);
  return httpServer;
}

