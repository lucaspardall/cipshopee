/**
 * Rotas para integração com a API da Shopee
 */

import { Express, Request, Response } from 'express';
import { storage } from './storage';
import { 
  generateAuthorizationUrl, 
  exchangeCodeForToken, 
  ensureValidToken,
  disconnectShopee
} from './shopee-oauth';

// Middleware para verificar se o usuário está autenticado
function isAuthenticated(req: any, res: Response, next: Function) {
  // Verifica se o usuário está logado
  if (req.isAuthenticated && req.isAuthenticated()) {
    return next();
  }
  
  // Verifica se o usuário tem ID na sessão (método alternativo)
  if (req.session && req.session.userId) {
    return next();
  }
  
  return res.status(401).json({ message: "Não autorizado" });
}

/**
 * Registra as rotas da Shopee no app Express
 */
export function registerShopeeRoutes(app: Express) {
  // Rota para iniciar o processo de autorização
  app.get('/api/shopee/authorize', isAuthenticated, (req: any, res: Response) => {
    try {
      // Gera URL de autorização
      const authorizationUrl = generateAuthorizationUrl();
      
      // Retorna a URL para o cliente redirecionar
      res.json({ 
        success: true, 
        authorizationUrl 
      });
    } catch (error: any) {
      console.error("Erro ao gerar URL de autorização:", error);
      res.status(500).json({ 
        success: false, 
        message: "Erro ao gerar URL de autorização", 
        error: error.message 
      });
    }
  });

  // Rota para callback de autorização
  app.get('/api/shopee/callback', async (req: Request, res: Response) => {
    try {
      const { code, shop_id } = req.query;
      
      if (!code || !shop_id) {
        return res.status(400).send(`
          <html>
            <head>
              <title>Erro na Conexão Shopee</title>
              <style>
                body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
                .error { color: #e53935; }
                .container { max-width: 600px; margin: 0 auto; }
              </style>
            </head>
            <body>
              <div class="container">
                <h1 class="error">Erro na Conexão</h1>
                <p>Parâmetros inválidos no callback. Faltam o código ou ID da loja.</p>
                <p>Por favor, tente novamente ou contate o suporte.</p>
                <a href="/">Voltar ao Dashboard</a>
              </div>
            </body>
          </html>
        `);
      }
      
      // Verifica se o usuário está autenticado
      const userId = req.session && (req.session as any).userId;
      
      if (!userId) {
        // Se não estiver autenticado, redireciona para login com parâmetros para retomar depois
        return res.redirect(`/login?redirect=/connect-shopee&code=${code}&shop_id=${shop_id}`);
      }
      
      // Obtém tokens a partir do código
      console.log(`Trocando código por token para loja ID: ${shop_id}`);
      const tokenResponse = await exchangeCodeForToken(code as string, shop_id as string);
      
      if (tokenResponse.error) {
        console.error("Erro na resposta da Shopee:", tokenResponse.error, tokenResponse.message);
        return res.status(400).send(`
          <html>
            <head>
              <title>Erro na Conexão Shopee</title>
              <style>
                body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
                .error { color: #e53935; }
                .container { max-width: 600px; margin: 0 auto; }
              </style>
            </head>
            <body>
              <div class="container">
                <h1 class="error">Erro na Conexão</h1>
                <p>A Shopee retornou um erro: ${tokenResponse.message || tokenResponse.error}</p>
                <p>Por favor, tente novamente ou contate o suporte.</p>
                <a href="/">Voltar ao Dashboard</a>
              </div>
            </body>
          </html>
        `);
      }
      
      // Calcula data de expiração
      const expiresAt = new Date();
      expiresAt.setSeconds(expiresAt.getSeconds() + (tokenResponse.expire_in || 14400));
      
      // Atualiza o usuário com os tokens da Shopee
      await storage.updateUser(userId, {
        shopeeApiEnabled: true,
        shopeeShopId: shop_id as string,
        shopeeAccessToken: tokenResponse.access_token,
        shopeeRefreshToken: tokenResponse.refresh_token,
        shopeeTokenExpiresAt: expiresAt,
        shopeePartnerShopId: tokenResponse.shop_id ? String(tokenResponse.shop_id) : undefined,
        shopeeConnectedAt: new Date(),
      });
      
      // Página de sucesso com redirecionamento automático
      return res.send(`
        <html>
          <head>
            <title>Shopee Conectada com Sucesso</title>
            <style>
              body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
              .success { color: #43a047; }
              .container { max-width: 600px; margin: 0 auto; }
            </style>
            <meta http-equiv="refresh" content="3;url=/" />
          </head>
          <body>
            <div class="container">
              <h1 class="success">Loja Shopee Conectada!</h1>
              <p>Sua loja Shopee foi conectada com sucesso.</p>
              <p>Você será redirecionado em 3 segundos...</p>
              <p><a href="/">Voltar ao Dashboard agora</a></p>
            </div>
          </body>
        </html>
      `);
    } catch (error: any) {
      console.error("Erro no callback da Shopee:", error);
      return res.status(500).send(`
        <html>
          <head>
            <title>Erro na Conexão Shopee</title>
            <style>
              body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
              .error { color: #e53935; }
              .container { max-width: 600px; margin: 0 auto; }
            </style>
          </head>
          <body>
            <div class="container">
              <h1 class="error">Erro na Conexão</h1>
              <p>Ocorreu um erro ao conectar sua loja Shopee:</p>
              <p>${error.message}</p>
              <a href="/">Voltar ao Dashboard</a>
            </div>
          </body>
        </html>
      `);
    }
  });

  // Rota para verificar status da conexão com a Shopee
  app.get('/api/shopee/status', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user?.id || req.session.userId;
      
      if (!userId) {
        return res.status(401).json({ 
          connected: false, 
          message: "Usuário não autenticado" 
        });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ 
          connected: false, 
          message: "Usuário não encontrado" 
        });
      }
      
      // Verifica se o usuário está conectado à Shopee
      const isConnected = user.shopeeApiEnabled && 
                          user.shopeeAccessToken && 
                          user.shopeeShopId;
                          
      // Se estiver conectado, verifica se o token é válido
      let hasValidToken = false;
      if (isConnected) {
        const token = await ensureValidToken(userId);
        hasValidToken = !!token;
      }
      
      res.json({
        connected: isConnected,
        hasValidToken,
        shopId: user.shopeeShopId,
        connectedAt: user.shopeeConnectedAt,
        // A URL da loja é diferente do ID da loja
        shopUrl: user.shopeeStoreUrl || undefined
      });
    } catch (error: any) {
      console.error("Erro ao verificar status da Shopee:", error);
      res.status(500).json({ 
        connected: false, 
        message: "Erro ao verificar status da conexão", 
        error: error.message 
      });
    }
  });

  // Rota para desconectar da Shopee
  app.post('/api/shopee/disconnect', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user?.id || req.session.userId;
      
      if (!userId) {
        return res.status(401).json({ 
          success: false, 
          message: "Usuário não autenticado" 
        });
      }
      
      const result = await disconnectShopee(userId);
      
      if (result) {
        res.json({ 
          success: true, 
          message: "Desconectado da Shopee com sucesso" 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: "Erro ao desconectar da Shopee" 
        });
      }
    } catch (error: any) {
      console.error("Erro ao desconectar da Shopee:", error);
      res.status(500).json({ 
        success: false, 
        message: "Erro ao desconectar da Shopee", 
        error: error.message 
      });
    }
  });
}