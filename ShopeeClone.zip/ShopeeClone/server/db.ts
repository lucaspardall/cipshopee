import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Configurações de segurança para o pool do banco de dados
export const pool = new Pool({ 
  connectionString: process.env.DATABASE_URL,
  // Limites de segurança para prevenir sobrecarga do banco
  max: 20, // máximo de conexões simultâneas
  idleTimeoutMillis: 30000, // tempo limite para conexões ociosas
  connectionTimeoutMillis: 5000, // tempo limite para tentativas de conexão
  // Limitar número de tentativas para prevenir ataques de força bruta
  statement_timeout: 10000, // limite de tempo para execução de consultas (ms)
  query_timeout: 10000 // limite de tempo para consultas (ms)
});

// Configuração do Drizzle com logging de consultas apenas em desenvolvimento
export const db = drizzle({ 
  client: pool, 
  schema,
  // Configurações adicionais de segurança 
  logger: process.env.NODE_ENV === 'development' ? {
    logQuery: (query, params) => {
      console.log('Consulta SQL executada:');
      console.log('- Query:', query);
      console.log('- Params:', params);
    }
  } : undefined
});
