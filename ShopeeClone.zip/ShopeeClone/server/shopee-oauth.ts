/**
 * Integração OAuth2 com a API da Shopee
 * 
 * Este módulo gerencia o fluxo de autenticação OAuth2 para a Shopee:
 * 1. Gera links de autorização para o vendedor
 * 2. Processa callbacks de autorização
 * 3. Gerencia tokens (obtenção, atualização)
 */

import axios from 'axios';
import { storage } from './storage';

// Tipos das respostas da API da Shopee
interface ShopeeTokenResponse {
  access_token: string;
  refresh_token: string;
  expire_in: number;
  request_id: string;
  error?: string;
  message?: string;
  shop_id?: number;
}

// Definir tipos para ambientes
export type ShopeeEnvironment = 'SANDBOX' | 'LIVE';

/**
 * Configurações do OAuth da Shopee
 */
export const shopeeOAuthConfig = {
  // Ambientes disponíveis
  environments: {
    SANDBOX: {
      baseUrl: 'https://sandbox.partner.shopeemobile.com',
      apiUrl: 'https://sandbox.partner.shopeemobile.com/api/v2',
    },
    LIVE: {
      baseUrl: 'https://partner.shopeemobile.com',
      apiUrl: 'https://partner.shopeemobile.com/api/v2',
    }
  },
  
  // Ambiente atual (substituir conforme necessário)
  currentEnvironment: (process.env.SHOPEE_ENVIRONMENT === 'LIVE' ? 'LIVE' : 'SANDBOX') as ShopeeEnvironment,
  
  // Credenciais (serão preenchidas quando disponíveis)
  credentials: {
    partnerId: process.env.SHOPEE_PARTNER_ID || '',
    partnerKey: process.env.SHOPEE_PARTNER_KEY || '',
  },
  
  // Configurações do callback
  callback: {
    path: '/api/shopee/callback',
    getUrl: () => {
      // Pegar a URL base dinamicamente do ambiente
      const host = process.env.HOST_URL || 'https://cipshopee.replit.app';
      return `${host}/api/shopee/callback`;
    }
  }
};

/**
 * Gera um link de autorização para o vendedor
 */
export function generateAuthorizationUrl(): string {
  const env = shopeeOAuthConfig.currentEnvironment;
  const { baseUrl } = shopeeOAuthConfig.environments[env];
  const { partnerId } = shopeeOAuthConfig.credentials;
  const redirectUrl = shopeeOAuthConfig.callback.getUrl();
  
  // Se as credenciais ainda não estiverem configuradas, retorna link de exemplo
  if (!partnerId) {
    return `${baseUrl}/api/v2/shop/auth_partner?partner_id=PARTNER_ID&redirect=${encodeURIComponent(redirectUrl)}`;
  }
  
  return `${baseUrl}/api/v2/shop/auth_partner?partner_id=${partnerId}&redirect=${encodeURIComponent(redirectUrl)}`;
}

/**
 * Troca o código de autorização por um token de acesso
 */
export async function exchangeCodeForToken(code: string, shopId: string): Promise<ShopeeTokenResponse> {
  const env = shopeeOAuthConfig.currentEnvironment;
  const { apiUrl } = shopeeOAuthConfig.environments[env];
  const { partnerId, partnerKey } = shopeeOAuthConfig.credentials;
  
  // Se as credenciais ainda não estiverem configuradas, retorna resposta simulada
  if (!partnerId || !partnerKey) {
    console.log("⚠️ Credenciais da Shopee não configuradas. Usando fluxo de simulação.");
    return {
      access_token: "EXAMPLE_ACCESS_TOKEN",
      refresh_token: "EXAMPLE_REFRESH_TOKEN",
      expire_in: 14400, // 4 horas em segundos
      request_id: "EXAMPLE_REQUEST_ID",
      message: "Shopee API credentials not configured yet"
    };
  }
  
  try {
    const response = await axios.post(`${apiUrl}/auth/token/get`, {
      partner_id: parseInt(partnerId),
      shop_id: parseInt(shopId),
      code
    });
    
    return response.data;
  } catch (error) {
    console.error("Erro ao trocar código por token:", error);
    throw error;
  }
}

/**
 * Atualiza um token expirado usando refresh token
 */
export async function refreshToken(userId: number, refreshToken: string): Promise<ShopeeTokenResponse> {
  const env = shopeeOAuthConfig.currentEnvironment;
  const { apiUrl } = shopeeOAuthConfig.environments[env];
  const { partnerId, partnerKey } = shopeeOAuthConfig.credentials;
  
  // Se as credenciais ainda não estiverem configuradas, retorna resposta simulada
  if (!partnerId || !partnerKey) {
    console.log("⚠️ Credenciais da Shopee não configuradas. Usando fluxo de simulação.");
    return {
      access_token: "EXAMPLE_REFRESHED_ACCESS_TOKEN",
      refresh_token: "EXAMPLE_REFRESHED_REFRESH_TOKEN",
      expire_in: 14400,
      request_id: "EXAMPLE_REQUEST_ID_REFRESH",
      message: "Shopee API credentials not configured yet"
    };
  }
  
  try {
    const user = await storage.getUser(userId);
    
    if (!user || !user.shopeeShopId) {
      throw new Error("Usuário não encontrado ou sem shopeeShopId");
    }
    
    const response = await axios.post(`${apiUrl}/auth/access_token/get`, {
      partner_id: parseInt(partnerId),
      shop_id: parseInt(user.shopeeShopId),
      refresh_token: refreshToken
    });
    
    return response.data;
  } catch (error) {
    console.error("Erro ao atualizar token:", error);
    throw error;
  }
}

/**
 * Verifica se o token atual precisa ser atualizado
 * @param expiresAt Data de expiração do token (timestamp)
 * @returns true se o token expirou ou expirará em breve (30 minutos)
 */
export function isTokenExpiredOrExpiring(expiresAt: Date | null): boolean {
  if (!expiresAt) return true;
  
  const now = new Date();
  const expirationTime = new Date(expiresAt);
  
  // Considera que o token precisa ser renovado se expirar em menos de 30 minutos
  const timeUntilExpiration = expirationTime.getTime() - now.getTime();
  const thirtyMinutesInMs = 30 * 60 * 1000;
  
  return timeUntilExpiration <= thirtyMinutesInMs;
}

/**
 * Verifica e atualiza o token se necessário
 */
export async function ensureValidToken(userId: number): Promise<string | null> {
  try {
    const user = await storage.getUser(userId);
    
    if (!user) {
      console.error("Usuário não encontrado");
      return null;
    }
    
    if (!user.shopeeApiEnabled || !user.shopeeRefreshToken) {
      console.log("Usuário não está conectado à Shopee");
      return null;
    }
    
    // Verifica se o token atual expirou ou expirará em breve
    if (isTokenExpiredOrExpiring(user.shopeeTokenExpiresAt)) {
      console.log("Token Shopee expirado ou próximo de expirar, atualizando...");
      
      const tokenResponse = await refreshToken(userId, user.shopeeRefreshToken);
      
      // Calcula a data de expiração
      const expiresAt = new Date();
      expiresAt.setSeconds(expiresAt.getSeconds() + tokenResponse.expire_in);
      
      // Atualiza o usuário com os novos tokens
      await storage.updateUser(userId, {
        shopeeAccessToken: tokenResponse.access_token,
        shopeeRefreshToken: tokenResponse.refresh_token,
        shopeeTokenExpiresAt: expiresAt
      });
      
      return tokenResponse.access_token;
    }
    
    return user.shopeeAccessToken || null;
  } catch (error) {
    console.error("Erro ao verificar/atualizar token:", error);
    return null;
  }
}

/**
 * Desconecta um usuário da Shopee
 */
export async function disconnectShopee(userId: number): Promise<boolean> {
  try {
    await storage.updateUser(userId, {
      shopeeApiEnabled: false,
      shopeeAccessToken: undefined,
      shopeeRefreshToken: undefined,
      shopeeTokenExpiresAt: undefined
    });
    
    return true;
  } catch (error) {
    console.error("Erro ao desconectar usuário da Shopee:", error);
    return false;
  }
}