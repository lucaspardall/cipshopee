import express, { type Request, Response, NextFunction } from "express";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import passport from "passport";
import { EventEmitter } from "events";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { pool } from "./db";
import { storage } from "./storage";
import { debugSession, simulateLogin } from "./session-debug";

// Aumentar o limite de listeners para evitar o warning do MaxListeners
EventEmitter.defaultMaxListeners = 20;

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Health check endpoint agora está definido antes do middleware de sessão

// Configure CORS to allow localhost and Replit domains
app.use((req, res, next) => {
  const allowedOrigins = [
    'http://localhost:3000',
    'http://localhost:5000',
    'https://' + req.headers.host
  ];
  
  const origin = req.headers.origin as string;
  if (allowedOrigins.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
  }
  
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  
  next();
});

// Configure PostgreSQL session store
const PgSession = connectPgSimple(session);
const sessionStore = new PgSession({
  pool,
  tableName: 'sessions',
  createTableIfMissing: true
});

// Rotas de health check para o Replit Autoscale
// Endpoint mais robusto que verifica o banco de dados
app.get('/health', async (req, res) => {
  try {
    // Verificar conexão com o banco de dados
    await pool.query('SELECT 1');
    res.status(200).json({ status: 'ok', database: 'connected' });
  } catch (error) {
    console.error('Health check falhou:', error);
    res.status(500).json({ status: 'error', database: 'disconnected' });
  }
});

// Health check simplificado para compatibilidade
app.get('/_health', (req, res) => {
  res.status(200).send('OK');
});

// Health check endpoint na raiz para Replit Autoscale
app.head('/', (req, res) => {
  res.status(200).send('OK');
});

// Para requisições GET na raiz que incluam o cabeçalho "Health-Check"
app.get('/', (req, res, next) => {
  // Se for uma requisição de health check do Replit, responder com OK
  if (req.headers['health-check'] === 'true' || req.query.health === 'check') {
    return res.status(200).send('OK');
  }
  
  // Caso contrário, passar para o próximo middleware (que servirá o frontend React)
  next();
});

// Configurar o middleware de sessão para todas as outras rotas
const sessionMiddleware = session({
  store: sessionStore,
  secret: process.env.SESSION_SECRET || "cip-shopee-secret",
  resave: true, // Garantir que a sessão seja sempre salva novamente
  saveUninitialized: true, // Salva sessões não inicializadas
  rolling: true, // Renova o cookie a cada requisição
  name: 'cip-shopee.sid', // Nome personalizado para o cookie (evita conflitos)
  cookie: {
    secure: false, // Desabilitando para funcionar em todos os ambientes (local e prod)
    sameSite: 'lax', 
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 dias (aumentando para maior persistência)
    httpOnly: true,
    path: '/'
  },
});

// Aplicar o middleware de sessão a todas as rotas (exceto as de health check)
app.use((req, res, next) => {
  // Pular a sessão para requisições de health check
  if (req.path === '/health' || 
      (req.path === '/' && (req.headers['health-check'] === 'true' || req.query.health === 'check')) ||
      req.method === 'HEAD') {
    return next();
  }
  
  // Aplicar o middleware de sessão para todas as outras requisições
  sessionMiddleware(req, res, next);
});

// Inicializar Passport para autenticação
app.use(passport.initialize());
app.use(passport.session());

// Middlewares de depuração e teste (apenas em desenvolvimento)
if (app.get("env") === "development") {
  console.log('Ambiente de desenvolvimento: habilitando middlewares de depuração');
  app.use(debugSession);
  app.use(simulateLogin);
}

// Middleware para garantir que a sessão seja salva após cada requisição
// Isso ajuda a evitar problemas de persistência de sessão
app.use((req, res, next) => {
  // Pular para requisições de health check
  if (req.path === '/health' || 
      (req.path === '/' && (req.headers['health-check'] === 'true' || req.query.health === 'check')) ||
      req.method === 'HEAD') {
    return next();
  }
  
  // Guardar o método original de end do res
  const originalEnd = res.end;
  const originalJson = res.json;
  const originalRedirect = res.redirect;
  
  // Sobrescrever o método end
  res.end = function(this: any, chunk?: any, encoding?: BufferEncoding, callback?: () => void): any {
    if (req.session && req.session.save) {
      req.session.save((err) => {
        if (err) {
          console.error('Erro ao salvar sessão em res.end:', err);
        }
        // Chamar o método original após salvar a sessão
        if (chunk !== undefined) {
          originalEnd.call(this, chunk, encoding as BufferEncoding, callback);
        } else {
          originalEnd.call(this);
        }
      });
    } else {
      // Se não tiver sessão, apenas chamar o método original
      if (chunk !== undefined) {
        originalEnd.call(this, chunk, encoding as BufferEncoding, callback);
      } else {
        originalEnd.call(this);
      }
    }
  };
  
  // Sobrescrever o método json
  res.json = function(this: any, body: any): any {
    if (req.session && req.session.save) {
      req.session.save((err) => {
        if (err) {
          console.error('Erro ao salvar sessão em res.json:', err);
        }
        // Chamar o método original após salvar a sessão
        originalJson.call(this, body);
      });
      return this;
    } else {
      // Se não tiver sessão, apenas chamar o método original
      return originalJson.call(this, body);
    }
  };
  
  // Sobrescrever o método redirect
  res.redirect = function(this: any, url: string, status?: number): any {
    if (req.session && req.session.save) {
      req.session.save((err) => {
        if (err) {
          console.error('Erro ao salvar sessão em res.redirect:', err);
        }
        // Chamar o método original após salvar a sessão
        if (status !== undefined) {
          originalRedirect.call(this, url, status);
        } else {
          originalRedirect.call(this, url);
        }
      });
    } else {
      // Se não tiver sessão, apenas chamar o método original
      if (status !== undefined) {
        originalRedirect.call(this, url, status);
      } else {
        originalRedirect.call(this, url);
      }
    }
    return this;
  };
  
  next();
});

// Configuração de serialização de usuário para o Passport
passport.serializeUser((user: any, done) => {
  if (!user || typeof user.id === 'undefined') {
    console.error('Erro na serialização: objeto de usuário inválido', user);
    return done(null, null);
  }
  
  if (app.get("env") === "development") {
    console.log('Serializando usuário:', user.id);
  }
  
  done(null, user.id);
});

passport.deserializeUser(async (id: number, done) => {
  try {
    if (!id) {
      if (app.get("env") === "development") {
        console.error('ID de usuário inválido na desserialização:', id);
      }
      return done(null, false);
    }
    
    if (app.get("env") === "development") {
      console.log('Desserializando usuário com ID:', id);
    }
    
    const user = await storage.getUser(id);
    if (!user) {
      if (app.get("env") === "development") {
        console.error('Usuário não encontrado na desserialização:', id);
      }
      return done(null, false);
    }
    
    if (app.get("env") === "development") {
      console.log('Usuário desserializado com sucesso:', user.email);
    }
    
    done(null, user);
  } catch (error) {
    console.error('Erro ao desserializar usuário:', error);
    // Returnar false em vez de propagar o erro
    done(null, false);
  }
});

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    console.error('Erro na aplicação:', err);
    res.status(status).json({ message });
    
    // Não lançar o erro novamente para evitar que o servidor caia
    // Em vez disso, apenas registrar o erro
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
