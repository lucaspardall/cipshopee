// Este arquivo pode ser usado para depurar problemas relacionados à sessão

import { Request, Response, NextFunction } from 'express';
import { storage } from './storage';

// Middleware para depuração de sessão - exibe informações detalhadas sobre a sessão
export function debugSession(req: Request, res: Response, next: NextFunction) {
  
  console.log('=== DEPURAÇÃO DE SESSÃO ===');
  console.log(`Rota: ${req.method} ${req.path}`);
  console.log(`req.session: ${req.session ? 'existe' : 'não existe'}`);
  
  if (req.session) {
    console.log('Session ID:', req.sessionID);
    console.log('Conteúdo da sessão:', req.session);
    console.log('Cookies:', req.headers.cookie);
  }
  
  console.log(`req.user: ${req.user ? 'existe' : 'não existe'}`);
  if (req.user) {
    console.log('User:', req.user);
  }
  
  console.log(`req.isAuthenticated: ${typeof req.isAuthenticated === 'function' ? 'é função' : 'não é função'}`);
  if (typeof req.isAuthenticated === 'function') {
    console.log(`req.isAuthenticated(): ${req.isAuthenticated()}`);
  }
  
  console.log('========================');
  next();
}

// Middleware para testar login
export async function simulateLogin(req: any, res: Response, next: NextFunction) {
  // Verificar se o usuário já está autenticado
  if (req.isAuthenticated && req.isAuthenticated()) {
    console.log('Usuário já está autenticado:', req.user);
    return next();
  }
  
  // Verificar se é uma solicitação de teste de login
  if (req.query.test_login === 'true' && req.query.userId) {
    const userId = Number(req.query.userId);
    console.log('Simulando login para usuário ID:', userId);
    
    try {
      // Buscar o usuário no banco de dados
      const user = await storage.getUser(userId);
      
      if (user) {
        // Simular login definindo req.user e salvando o ID na sessão
        req.user = user;
        req.session.userId = userId;
        
        // Salvar a sessão explicitamente
        req.session.save((err) => {
          if (err) {
            console.error('Erro ao salvar sessão durante simulação de login:', err);
            return res.status(500).json({ error: 'Erro ao salvar sessão' });
          }
          
          console.log('Login simulado com sucesso. ID do usuário na sessão:', userId);
          console.log('Redirecionando para o callback de autenticação...');
          res.redirect('/auth-callback?success=true&source=test');
        });
      } else {
        console.error('Usuário não encontrado:', userId);
        return res.status(404).json({ error: 'Usuário não encontrado' });
      }
    } catch (error) {
      console.error('Erro durante simulação de login:', error);
      return res.status(500).json({ error: 'Erro interno durante login simulado' });
    }
  } else {
    // Continuar para o próximo middleware se não for uma simulação de login
    next();
  }
}