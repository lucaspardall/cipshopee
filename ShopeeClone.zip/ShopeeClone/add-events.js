import pg from 'pg';

const { Pool } = pg;

const pool = new Pool({
  connectionString: 'postgresql://neondb_owner:npg_WmDhf5UX1Mop@ep-shy-flower-a40lz6lh.us-east-1.aws.neon.tech/neondb?sslmode=require'
});

async function addEvents() {
  try {
    // Verifica se já existem eventos
    const checkResult = await pool.query('SELECT COUNT(*) FROM events');
    const count = parseInt(checkResult.rows[0].count);
    
    if (count > 0) {
      console.log(`Já existem ${count} eventos no banco de dados. Nada foi adicionado.`);
      return;
    }

    // Datas futuras para os eventos
    const now = new Date();
    const oneDay = 24 * 60 * 60 * 1000;
    
    // Adiciona eventos
    const events = [
      {
        title: 'Shopee Super Sale 6.6',
        description: 'Mega promoção com descontos de até 80% em todas as categorias.',
        category: 'SALES',
        startDate: new Date(now.getTime() + 20 * oneDay), // 20 dias no futuro
        endDate: new Date(now.getTime() + 21 * oneDay),   // 21 dias no futuro
        priority: 'HIGH',
        imageUrl: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?auto=format&fit=crop'
      },
      {
        title: 'Flash Sale: Eletrônicos',
        description: 'Flash sale exclusiva para produtos eletrônicos com descontos incríveis.',
        category: 'FLASH_SALE',
        startDate: new Date(now.getTime() + 5 * oneDay), // 5 dias no futuro
        endDate: new Date(now.getTime() + 5 * oneDay + 6 * 60 * 60 * 1000), // 5 dias + 6 horas
        priority: 'MEDIUM',
        imageUrl: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop'
      },
      {
        title: 'Webinar: Como Aumentar Vendas na Shopee',
        description: 'Aprenda estratégias exclusivas para aumentar suas vendas com especialistas da plataforma.',
        category: 'EDUCATION',
        startDate: new Date(now.getTime() + 7 * oneDay), // 7 dias no futuro
        endDate: new Date(now.getTime() + 7 * oneDay + 2 * 60 * 60 * 1000), // 7 dias + 2 horas
        priority: 'MEDIUM',
        imageUrl: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop'
      },
      {
        title: 'Programa Vendedor Destaque - Inscrições',
        description: 'Inscrições para o programa que premia vendedores com melhor performance no mês.',
        category: 'PROGRAM',
        startDate: new Date(now.getTime() + 2 * oneDay), // 2 dias no futuro
        endDate: new Date(now.getTime() + 12 * oneDay), // 12 dias no futuro
        priority: 'LOW',
        imageUrl: 'https://images.unsplash.com/photo-1533750516457-a7f992034fec?auto=format&fit=crop'
      },
      {
        title: 'Mudanças nas Regras de Avaliação de Produtos',
        description: 'Webinar sobre as novas regras de avaliação de produtos que entrarão em vigor no próximo mês.',
        category: 'POLICY',
        startDate: new Date(now.getTime() + 3 * oneDay), // 3 dias no futuro
        endDate: new Date(now.getTime() + 3 * oneDay + 1.5 * 60 * 60 * 1000), // 3 dias + 1.5 horas
        priority: 'HIGH',
        imageUrl: 'https://images.unsplash.com/photo-1521791136064-7986c2920216?auto=format&fit=crop'
      }
    ];

    // Insere os eventos
    for (const item of events) {
      await pool.query(
        'INSERT INTO events (title, description, category, start_date, end_date, priority, image_url) VALUES ($1, $2, $3, $4, $5, $6, $7)',
        [item.title, item.description, item.category, item.startDate, item.endDate, item.priority, item.imageUrl]
      );
    }

    console.log(`${events.length} eventos adicionados com sucesso!`);
  } catch (error) {
    console.error('Erro ao adicionar eventos:', error);
  } finally {
    await pool.end();
  }
}

addEvents();