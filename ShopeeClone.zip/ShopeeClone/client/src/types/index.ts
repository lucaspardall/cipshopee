import { DataSourceType } from "@shared/schema";

export { DataSourceType };

export interface User {
  id: number;
  username: string;
  email?: string;
  name?: string;
  profileImageUrl?: string;
  createdAt?: Date;
  shopeeStoreUrl?: string;
  storeScore?: number;
  preferredDataSource?: DataSourceType;
  shopeeApiEnabled: boolean;
  emailNotificationsEnabled?: boolean;
}

export interface Product {
  id: number;
  userId: number;
  title: string;
  description: string;
  category?: string;
  price?: number;
  shopeeUrl?: string;
  shopeeProductId?: string;
  createdAt?: Date;
  updatedAt?: Date;
  dataSource?: DataSourceType;
  views?: number;
  sales?: number;
  conversionRate?: number;
  searchRanking?: number;
  performanceScore?: number;
  originalTitle?: string;
  originalDescription?: string;
  variations?: any;
  specifications?: any;
  keywords?: string[];
  imageUrl?: string;
  images?: string[];
}

export interface Optimization {
  id: number;
  userId: number;
  productId: number;
  optimizedTitle?: string;
  optimizedDescription?: string;
  suggestedPrice?: number;
  discountPrice?: number;
  optimizedKeywords?: string[];
  generalImprovements?: any;
  boostPlan?: string[];
  titleJustification?: string;
  descriptionJustification?: string;
  priceJustification?: string;
  keywordsJustification?: string;
  improvementsJustification?: string;
  justification?: string;
  createdAt?: Date;
  dataSource?: DataSourceType;
  estimatedImprovement?: number;
}

export interface StoreAnalytics {
  id: number;
  userId: number;
  date?: Date;
  overallScore: number;
  listingQualityScore?: number;
  priceCompetitivenessScore?: number;
  marketingEffectivenessScore?: number;
  customerSatisfactionScore?: number;
  visibilityScore?: number;
  dataSource?: DataSourceType;
  metricsData?: any;
  priorityActions?: any;
}

export interface Event {
  id: number;
  title: string;
  description?: string;
  startDate: Date;
  endDate?: Date;
  priority?: string;
  category?: string;
  imageUrl?: string;
}

export interface News {
  id: number;
  title: string;
  content: string;
  publishDate?: Date;
  category?: string;
  imageUrl?: string;
  url?: string;
}

export interface OptimizationResult {
  product: Product;
  optimization: Optimization;
}

export interface ListingGenerationResult {
  product: Product;
  generatedListing: {
    title: string;
    description: string;
    category: string;
    variations: any;
    specifications: any;
    keywords: string[];
    suggestedPrice: number;
  };
}

export interface StoreAnalyticsResult {
  storeScore: number;
  analytics: StoreAnalytics;
}

export interface MetricItem {
  label: string;
  value: string | number;
  change?: number;
  direction?: 'up' | 'down' | 'neutral';
}

export interface ActionItem {
  icon: string;
  text: string;
  actionLink: string;
  actionText: string;
}

export interface ProductItem {
  id: number;
  title: string;
  image: string;
  price: number;
  views: number;
  sales: number;
  rating: number;
}

export interface Alert {
  type: 'error' | 'warning' | 'info' | 'success';
  title: string;
  description: string;
  action?: string;
  actionLink?: string;
}

export interface UpcomingEvent {
  id: number;
  month: string;
  day: string;
  title: string;
  description: string;
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
  actionLink: string;
}

export interface OptimizationTool {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  link: string;
  buttonText: string;
}

export interface NewsItem {
  id: number;
  title: string;
  description: string;
  date: string;
  imageUrl: string;
  link: string;
}
