export const themeConfig = {
  colors: {
    primary: {
      50: '#e6eaf4',
      100: '#c2cce4',
      200: '#99aad3',
      300: '#7188c2',
      400: '#4e6db5',
      500: '#1a3a8f', // Primary color
      600: '#173481',
      700: '#132c6d',
      800: '#0f2559',
      900: '#0a1a3f',
    },
    secondary: {
      50: '#fff0eb',
      100: '#ffd6c7',
      200: '#ffbba0',
      300: '#ffa078',
      400: '#ff855c',
      500: '#ff6b35', // Secondary color
      600: '#e66130',
      700: '#cc5628',
      800: '#b34b24',
      900: '#993f1e',
    },
    success: {
      500: '#00c9a7',
    },
    purple: {
      500: '#6247aa',
    },
    danger: {
      500: '#ff595e',
    },
    dark: {
      900: '#121212',
      800: '#1e1e1e',
      700: '#2d2d2d',
      600: '#3d3d3d',
      500: '#5a5a5a',
      400: '#818181',
      300: '#a3a3a3',
      200: '#c4c4c4',
      100: '#e5e5e5',
      50: '#f7f7f7',
    },
  },
  dataSourceStyles: {
    api: {
      backgroundColor: 'rgba(26, 58, 143, 0.2)',
      textColor: '#1a3a8f',
      label: 'API'
    },
    scraping: {
      backgroundColor: 'rgba(255, 107, 53, 0.2)',
      textColor: '#ff6b35',
      label: 'Shopee'
    }
  }
};

export type ThemeConfig = typeof themeConfig;
