export const siteConfig = {
  name: "CIP Shopee",
  description: "Centro de Inteligência Pardal - Plataforma completa para vendedores Shopee",
  mainNav: [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: "chart-line"
    },
    {
      title: "Otimizador de Anúncio",
      href: "/optimize-listing",
      icon: "magic"
    },
    {
      title: "Criador de Anúncio",
      href: "/create-listing",
      icon: "plus-circle"
    },
    {
      title: "Gerenciador de Anúncios",
      href: "/manage-listings",
      icon: "tags"
    },
    {
      title: "Analisador da Loja",
      href: "/analyze-store",
      icon: "search-dollar"
    },
    {
      title: "Shopee ADS",
      href: "/analyze-ads",
      icon: "chart-bar"
    },
    {
      title: "Centro de Notícias",
      href: "/news",
      icon: "newspaper"
    },
    {
      title: "Integração Shopee",
      href: "/integrations/shopee",
      icon: "plug"
    },
    {
      title: "Planos e Configurações",
      href: "/account",
      icon: "user-cog"
    }
  ],
  links: {
    github: "https://github.com",
    twitter: "https://twitter.com",
    docs: "/docs",
    help: "/help"
  },
};

export type SiteConfig = typeof siteConfig;
