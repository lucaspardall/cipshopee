import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { apiRequest } from '@/lib/queryClient';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, CheckCircle, AlertTriangle } from "lucide-react";
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

/**
 * Componente para testar a integração com o assistente especializado
 */
const AssistantTester: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [productInfo, setProductInfo] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [testResults, setTestResults] = useState<any>(null);

  // Função para testar a integração com o assistente
  const handleTestIntegration = async () => {
    if (!productInfo.trim()) {
      toast({
        title: 'Informações necessárias',
        description: 'Por favor, insira informações do produto para testar',
        variant: 'destructive'
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await apiRequest('POST', '/api/test-ai-integration', { productInfo });
      const responseData = await response.json();

      setTestResults(responseData);
      
      toast({
        title: 'Teste concluído',
        description: 'A integração com o assistente foi testada com sucesso!',
        variant: 'default'
      });
    } catch (error) {
      console.error('Erro ao testar integração:', error);
      toast({
        title: 'Erro no teste',
        description: error instanceof Error ? error.message : 'Erro desconhecido ao testar integração',
        variant: 'destructive'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="container mx-auto p-4">
        <Card>
          <CardHeader>
            <CardTitle>Acesso Restrito</CardTitle>
            <CardDescription>
              Você precisa estar logado para acessar esta página.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4">
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Testador de Integração com Assistente</CardTitle>
          <CardDescription>
            Use esta ferramenta para testar como o assistente especializado do Método Pardal 10/10 responde às solicitações em formato JSON.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="productInfo">Informações do Produto</Label>
              <Textarea
                id="productInfo"
                placeholder="Insira informações sobre um produto para otimização (título, descrição, preço, etc.)"
                value={productInfo}
                onChange={(e) => setProductInfo(e.target.value)}
                rows={8}
                className="font-mono"
              />
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button 
            variant="secondary" 
            onClick={() => setProductInfo('')}
            disabled={isSubmitting}
          >
            Limpar
          </Button>
          <Button 
            onClick={handleTestIntegration}
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Testando...
              </>
            ) : (
              'Testar Integração'
            )}
          </Button>
        </CardFooter>
      </Card>

      {testResults && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              {testResults.success ? (
                <>
                  <CheckCircle className="mr-2 h-5 w-5 text-green-500" />
                  Teste Concluído com Sucesso
                </>
              ) : (
                <>
                  <AlertTriangle className="mr-2 h-5 w-5 text-yellow-500" />
                  Teste com Problemas
                </>
              )}
            </CardTitle>
            <CardDescription>
              Resultado da integração com o assistente especializado
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="formatted">
              <TabsList className="mb-4">
                <TabsTrigger value="formatted">Formatado</TabsTrigger>
                <TabsTrigger value="raw">Resposta Bruta</TabsTrigger>
              </TabsList>
              
              <TabsContent value="formatted">
                <div className="prose prose-sm max-w-none dark:prose-invert">
                  <div dangerouslySetInnerHTML={{ __html: testResults.formatted ? testResults.formatted.replace(/\n/g, '<br/>') : 'Sem dados formatados' }} />
                </div>
              </TabsContent>
              
              <TabsContent value="raw">
                <pre className="bg-muted p-4 rounded-md overflow-auto text-xs max-h-[500px]">
                  {JSON.stringify(testResults.response, null, 2)}
                </pre>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default AssistantTester;