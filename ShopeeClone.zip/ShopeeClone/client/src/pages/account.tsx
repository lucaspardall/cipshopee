import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User, Mail, Camera, Upload } from "lucide-react";
import { queryClient } from "@/lib/queryClient";

const plans = [
  {
    id: "essencial",
    name: "Essencial",
    price: "Grátis",
    features: [
      "Web scraping ilimitado",
      "Criação básica de anúncios",
      "Otimização de listagens existentes",
      "Suporte por e-mail"
    ]
  },
  {
    id: "pro",
    name: "Pro",
    price: "R$ 49,90/mês",
    features: [
      "Todas as funções do plano Essencial",
      "Acesso à API Shopee (direto)",
      "Agentes automatizados (3 máximo)",
      "Análise de concorrentes",
      "Recomendações personalizadas",
      "Suporte via chat"
    ]
  },
  {
    id: "master",
    name: "Master",
    price: "R$ 99,90/mês",
    features: [
      "Todas as funções do plano Pro",
      "Agentes automatizados ilimitados",
      "Análise avançada de mercado",
      "Precificação dinâmica",
      "Relatórios detalhados",
      "Suporte prioritário"
    ]
  }
];

export default function AccountPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [currentPlan, setCurrentPlan] = useState("essencial");
  const [notificationsEnabled, setNotificationsEnabled] = useState(user?.emailNotificationsEnabled !== false);
  const [profileImage, setProfileImage] = useState<string | null>(user?.profileImageUrl || null);
  const [isUploading, setIsUploading] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    shopeeUrl: user?.shopeeStoreUrl || ""
  });
  const [currentTab, setCurrentTab] = useState(() => {
    // Pegar o tab da URL (se existir)
    const params = new URLSearchParams(window.location.search);
    const tabParam = params.get('tab');
    return tabParam === 'plans' || tabParam === 'settings' ? tabParam : 'profile';
  });
  
  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || "",
        email: user.email || "",
        shopeeUrl: user.shopeeStoreUrl || ""
      });
      setProfileImage(user.profileImageUrl || null);
      setNotificationsEnabled(user.emailNotificationsEnabled !== false);
    }
  }, [user]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id === 'shopee_url' ? 'shopeeUrl' : id === 'name' ? 'name' : 'email']: value
    }));
  };
  
  const handleSaveProfile = async () => {
    try {
      const response = await fetch('/api/user/update-profile', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          shopeeStoreUrl: formData.shopeeUrl,
          profileImageUrl: profileImage,
          emailNotificationsEnabled: notificationsEnabled
        })
      });
      
      if (!response.ok) {
        throw new Error('Falha ao atualizar perfil');
      }
      
      // Revalidar os dados do usuário
      queryClient.invalidateQueries({ queryKey: ['/api/auth/user'] });
      
      toast({
        title: "Perfil atualizado",
        description: "Suas informações foram salvas com sucesso.",
        variant: "default",
      });
    } catch (error) {
      console.error('Erro ao atualizar perfil:', error);
      toast({
        title: "Erro ao atualizar perfil",
        description: "Ocorreu um problema ao salvar suas informações. Tente novamente.",
        variant: "destructive",
      });
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Arquivo muito grande",
        description: "Por favor, selecione uma imagem com menos de 5MB.",
        variant: "destructive",
      });
      return;
    }
    
    setIsUploading(true);
    
    const reader = new FileReader();
    reader.onload = (event) => {
      const base64String = event.target?.result as string;
      setProfileImage(base64String);
      setIsUploading(false);
    };
    
    reader.onerror = () => {
      toast({
        title: "Erro ao ler arquivo",
        description: "Não foi possível processar a imagem. Tente outra imagem.",
        variant: "destructive",
      });
      setIsUploading(false);
    };
    
    reader.readAsDataURL(file);
  };
  
  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };
  
  const handleChangePlan = (planId: string) => {
    if (planId !== "essencial") {
      toast({
        title: "Recurso em desenvolvimento",
        description: "A atualização de planos estará disponível em breve.",
        variant: "default",
      });
    } else {
      setCurrentPlan(planId);
    }
  };
  
  const handleToggleNotifications = async () => {
    const newState = !notificationsEnabled;
    setNotificationsEnabled(newState);
    
    try {
      const response = await fetch('/api/user/update-notification-settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          emailNotificationsEnabled: newState
        })
      });
      
      if (!response.ok) {
        throw new Error('Falha ao atualizar configurações de notificação');
      }
      
      // Revalidar os dados do usuário
      queryClient.invalidateQueries({ queryKey: ['/api/auth/user'] });
      
      toast({
        title: newState ? "Notificações ativadas" : "Notificações desativadas",
        description: newState
          ? "Você receberá notificações por email sobre atualizações importantes."
          : "Você não receberá mais notificações por email do sistema.",
        variant: "default",
      });
    } catch (error) {
      console.error('Erro ao atualizar notificações:', error);
      // Reverter estado em caso de erro
      setNotificationsEnabled(!newState);
      toast({
        title: "Erro ao atualizar notificações",
        description: "Ocorreu um problema ao salvar suas preferências. Tente novamente.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-primary-700 dark:text-primary-300">
        Planos e Configurações
      </h1>
      
      <Tabs value={currentTab} onValueChange={setCurrentTab} className="w-full">
        <TabsList className="grid grid-cols-3 mb-8">
          <TabsTrigger value="profile">Perfil</TabsTrigger>
          <TabsTrigger value="plans">Planos</TabsTrigger>
          <TabsTrigger value="settings">Configurações</TabsTrigger>
        </TabsList>
        
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>Informações de Perfil</CardTitle>
              <CardDescription>
                Gerencie seus dados pessoais e informações da loja.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-8 mb-6">
                <div className="flex flex-col items-center gap-4">
                  <div className="relative">
                    <Avatar className="w-32 h-32 border-4 border-primary-100">
                      <AvatarImage src={profileImage || undefined} />
                      <AvatarFallback className="bg-primary-100 text-primary-800 text-xl">
                        {user?.name?.charAt(0) || user?.username?.charAt(0) || <User size={32} />}
                      </AvatarFallback>
                    </Avatar>
                    
                    <Button 
                      size="icon" 
                      className="absolute bottom-0 right-0 rounded-full bg-primary-500 hover:bg-primary-600 w-10 h-10 shadow-md"
                      onClick={triggerFileInput}
                      disabled={isUploading}
                    >
                      {isUploading ? (
                        <div className="animate-spin">
                          <Mail className="h-5 w-5" />
                        </div>
                      ) : (
                        <Camera className="h-5 w-5" />
                      )}
                    </Button>
                    
                    <input 
                      type="file" 
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      accept="image/png, image/jpeg, image/gif" 
                      className="hidden"
                    />
                  </div>
                  
                  <p className="text-sm text-gray-500 text-center max-w-[180px]">
                    Clique no ícone de câmera para alterar sua foto de perfil
                  </p>
                </div>
                
                <div className="flex-1 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Nome de Usuário</Label>
                    <Input id="username" value={user?.username || ""} disabled />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome Completo</Label>
                    <Input 
                      id="name" 
                      value={formData.name} 
                      onChange={handleInputChange} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">E-mail</Label>
                    <Input 
                      id="email" 
                      type="email" 
                      value={formData.email} 
                      onChange={handleInputChange} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="shopee_url">URL da Loja Shopee</Label>
                    <Input 
                      id="shopee_url" 
                      value={formData.shopeeUrl} 
                      onChange={handleInputChange} 
                    />
                  </div>
                  
                  <div className="flex items-center space-x-2 pt-4">
                    <Switch 
                      id="email_notifications" 
                      checked={notificationsEnabled}
                      onCheckedChange={handleToggleNotifications}
                    />
                    <Label htmlFor="email_notifications">Receber notificações por e-mail</Label>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button onClick={handleSaveProfile}>
                  Salvar Alterações
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="plans">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <Card key={plan.id} className={`overflow-hidden ${plan.id === currentPlan ? 'border-2 border-primary-500 shadow-lg' : ''}`}>
                <CardHeader className={`${plan.id === "pro" ? 'bg-primary-100 dark:bg-primary-900' : plan.id === "master" ? 'bg-primary-200 dark:bg-primary-800' : ''}`}>
                  <CardTitle>{plan.name}</CardTitle>
                  <CardDescription>
                    <span className="text-xl font-bold">{plan.price}</span>
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <ul className="space-y-2 mb-6">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center">
                        <i className="fas fa-check text-green-500 mr-2"></i>
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button 
                    variant={plan.id === currentPlan ? "outline" : "default"}
                    className="w-full"
                    onClick={() => handleChangePlan(plan.id)}
                  >
                    {plan.id === currentPlan 
                      ? "Plano Atual" 
                      : `Mudar para ${plan.name}`}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Configurações do Sistema</CardTitle>
              <CardDescription>
                Ajuste suas preferências de uso da plataforma.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-medium">Fonte de Dados Preferida</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Selecione qual fonte de dados usar por padrão
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className={user?.preferredDataSource === "SCRAPING" ? "bg-primary-100 dark:bg-primary-900" : ""}>
                    Dados Shopee
                  </Button>
                  <Button variant="outline" size="sm" className={user?.preferredDataSource === "API" ? "bg-primary-100 dark:bg-primary-900" : ""} disabled={!user?.shopeeApiEnabled}>
                    API Shopee
                  </Button>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch 
                  id="notifications" 
                  checked={notificationsEnabled}
                  onCheckedChange={handleToggleNotifications}
                />
                <div>
                  <Label htmlFor="notifications" className="flex items-center">
                    Notificações por Email
                    <span className="ml-2 bg-blue-100 text-blue-800 text-xs font-medium px-2 py-0.5 rounded dark:bg-blue-900 dark:text-blue-300">
                      Recomendado
                    </span>
                  </Label>
                  <p className="text-sm text-gray-500 mt-1">
                    Receba atualizações importantes, análises e recomendações diretamente no seu email
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch id="dark_mode" />
                <Label htmlFor="dark_mode">Modo Escuro (Automático)</Label>
              </div>
              
              <div className="border-t pt-4">
                <h3 className="text-base font-medium mb-4">Conexões de API</h3>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-medium">API Shopee</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {user?.shopeeApiEnabled 
                          ? "Conectado" 
                          : "Não conectado"}
                      </p>
                    </div>
                    <Button variant="outline" size="sm">
                      {user?.shopeeApiEnabled 
                        ? "Reconectar" 
                        : "Conectar"}
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="shopee_key">Chave de API</Label>
                      <Input id="shopee_key" type="password" placeholder="••••••••••••••••" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="shopee_secret">Segredo da API</Label>
                      <Input id="shopee_secret" type="password" placeholder="••••••••••••••••" />
                    </div>
                  </div>
                  
                  <Button variant="default" size="sm">
                    Salvar Credenciais
                  </Button>
                </div>
              </div>
              
              <div className="border-t pt-4">
                <h3 className="text-base font-medium text-red-600 dark:text-red-400 mb-2">Zona de Perigo</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                  Estas ações são permanentes e não podem ser desfeitas.
                </p>
                <Button variant="destructive" size="sm">
                  Excluir Conta
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}