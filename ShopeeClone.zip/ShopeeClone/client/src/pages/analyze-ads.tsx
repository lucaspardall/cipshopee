import { useState, useRef } from "react";
import { toast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";

// UI Components
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  AlertCircle,
  CheckCircle,
  FileSpreadsheet,
  LineChart,
  UploadCloud,
  RefreshCw,
  AlertTriangle,
  ArrowUpRight,
  BarChart3
} from "lucide-react";

// CSV Parser
import Papa from "papaparse";

// Tipos de dados
interface ShopeeAd {
  adId: string;
  title: string;
  budget: number;
  spend: number;
  impressions: number;
  clicks: number;
  orders: number;
  revenue: number;
  ctr: number;
  cvr: number;
  cpc: number;
  roas: number;
  status: string;
  startDate: string;
  endDate: string;
}

interface AdAnalysis {
  adId: string;
  score: number;
  performance: 'good' | 'average' | 'poor';
  issues: string[];
  suggestions: string[];
  optimizedTitle?: string;
  optimizedBid?: number;
  optimizedBudget?: number;
  estimatedImprovement?: {
    clicks?: number;
    ctr?: number;
    cvr?: number;
    roas?: number;
  };
}

interface OverviewStats {
  totalAds: number;
  activeAds: number;
  totalSpend: number;
  totalRevenue: number;
  averageRoas: number;
  highPerformingAds: number;
  poorPerformingAds: number;
  topIssues: string[];
}

export default function AnalyzeAdsPage() {
  const { user, isAuthenticated } = useAuth();
  const [file, setFile] = useState<File | null>(null);
  const [fileName, setFileName] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [analysisProgress, setAnalysisProgress] = useState<number>(0);
  const [adData, setAdData] = useState<ShopeeAd[]>([]);
  const [adAnalyses, setAdAnalyses] = useState<AdAnalysis[]>([]);
  const [overviewStats, setOverviewStats] = useState<OverviewStats | null>(null);
  const [activeTab, setActiveTab] = useState<string>("overview");
  const [currentAdId, setCurrentAdId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      // Verificar se é um arquivo CSV ou Excel
      if (
        selectedFile.type === "text/csv" ||
        selectedFile.type === "application/vnd.ms-excel" ||
        selectedFile.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      ) {
        setFile(selectedFile);
        setFileName(selectedFile.name);
        toast({
          title: "Arquivo selecionado",
          description: `${selectedFile.name} foi selecionado para análise`,
        });
        parseFile(selectedFile);
      } else {
        toast({
          title: "Formato de arquivo inválido",
          description: "Por favor, selecione um arquivo CSV ou Excel",
          variant: "destructive",
        });
      }
    }
  };

  const parseFile = (file: File) => {
    // Iniciar análise
    setIsLoading(true);
    setAnalysisProgress(10);

    // Parse CSV
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        setAnalysisProgress(30);
        
        // Mapear dados para o formato esperado
        try {
          const mappedData: ShopeeAd[] = results.data.map((row: any, index: number) => {
            return {
              adId: row.ad_id || row.campaign_id || row.adId || `ad-${index}`,
              title: row.title || row.ad_name || row.campaign_name || `Anúncio ${index + 1}`,
              budget: parseFloat(row.budget || row.daily_budget || "0"),
              spend: parseFloat(row.spend || row.cost || "0"),
              impressions: parseInt(row.impressions || row.views || "0"),
              clicks: parseInt(row.clicks || "0"),
              orders: parseInt(row.orders || row.conversions || "0"),
              revenue: parseFloat(row.revenue || row.sales || "0"),
              ctr: parseFloat(row.ctr || "0") || (parseInt(row.clicks || "0") / parseInt(row.impressions || "1")),
              cvr: parseFloat(row.cvr || "0") || (parseInt(row.orders || "0") / parseInt(row.clicks || "1")),
              cpc: parseFloat(row.cpc || "0") || (parseFloat(row.spend || "0") / parseInt(row.clicks || "1")),
              roas: parseFloat(row.roas || "0") || (parseFloat(row.revenue || "0") / parseFloat(row.spend || "1")),
              status: row.status || "active",
              startDate: row.start_date || row.startDate || "",
              endDate: row.end_date || row.endDate || ""
            };
          });

          setAdData(mappedData);
          setAnalysisProgress(50);
          
          // Simular análise dos anúncios
          setTimeout(() => {
            analyzeAds(mappedData);
          }, 1500);
        } catch (error) {
          setIsLoading(false);
          toast({
            title: "Erro ao processar arquivo",
            description: "Não foi possível processar os dados do arquivo. Verifique se o formato está correto.",
            variant: "destructive",
          });
        }
      },
      error: (error) => {
        setIsLoading(false);
        toast({
          title: "Erro ao processar arquivo",
          description: error.message,
          variant: "destructive",
        });
      }
    });
  };

  const analyzeAds = async (ads: ShopeeAd[]) => {
    // Enviar dados para o backend para análise com IA via webhook
    setAnalysisProgress(75);

    try {
      // Enviamos para o endpoint que irá acionar o webhook do n8n
      const response = await fetch("/api/analyze-ads-webhook", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          ads,
          source: "analyze-ads-tool",
          requestType: "ad-analysis",
          timestamp: new Date().toISOString(),
          userId: user?.id || 0
        }),
      });
      
      if (!response.ok) {
        console.warn(`API error: ${response.status} ${response.statusText}`);
        throw new Error("API error");
      }
      
      const data = await response.json();
      
      // Verificar se temos dados válidos
      if (!data.success || !data.analyses || !data.overviewStats) {
        throw new Error("Resposta da API com formato inválido");
      }
      
      // Processar resultados da API
      setAdAnalyses(data.analyses);
      setOverviewStats(data.overviewStats);
      setAnalysisProgress(100);
      
      setTimeout(() => {
        setIsLoading(false);
        toast({
          title: "Análise concluída",
          description: `Analisamos ${ads.length} anúncios com sucesso!`,
        });
      }, 500);
      
    } catch (error) {
      console.error("Erro na análise de anúncios:", error);
      
      toast({
        title: "Aviso",
        description: "Não foi possível conectar ao serviço de IA. Realizando análise simplificada localmente.",
        variant: "destructive",
      });
      
      performLocalAnalysis(ads);
    }
  };
  
  // Função auxiliar para análise local quando a API falhar
  const performLocalAnalysis = (ads: ShopeeAd[]) => {
    // Realizar análise local simples sem IA
    const localAnalyses: AdAnalysis[] = ads.map(ad => {
      const roas = ad.roas || 0;
      const ctr = ad.ctr || 0;
      
      let performance: 'good' | 'average' | 'poor' = 'average';
      let score = 50;
      let issues: string[] = [];
      let suggestions: string[] = [];
      
      // Análise baseada no ROAS
      if (roas > 4) {
        performance = 'good';
        score += 30;
      } else if (roas < 2) {
        performance = 'poor';
        score -= 20;
        issues.push("ROAS baixo");
        suggestions.push("Aumentar orçamento para anúncios com melhor desempenho");
      }
      
      // Análise baseada no CTR
      if (ctr > 0.02) {
        score += 10;
      } else if (ctr < 0.01) {
        score -= 10;
        issues.push("CTR baixo");
        suggestions.push("Melhorar título e isca de clique");
      }
      
      // Ajustar score para estar no range 0-100
      score = Math.max(0, Math.min(100, score));
      
      return {
        adId: ad.adId,
        score,
        performance,
        issues,
        suggestions,
        optimizedTitle: issues.includes("CTR baixo") 
          ? `${ad.title} ✨ PROMOÇÃO LIMITADA`
          : undefined,
        optimizedBid: issues.length > 0 
          ? (ad.cpc * 0.9) 
          : undefined,
        optimizedBudget: roas > 3 
          ? (ad.budget * 1.2) 
          : undefined,
        estimatedImprovement: {
          clicks: ad.clicks * 1.15,
          ctr: ad.ctr * 1.1,
          cvr: ad.cvr * 1.05,
          roas: ad.roas * 1.2
        }
      };
    });
    
    // Criar estatísticas de visão geral
    const goodAds = localAnalyses.filter(a => a.performance === 'good').length;
    const poorAds = localAnalyses.filter(a => a.performance === 'poor').length;
    const activeAds = ads.filter(a => a.status.toLowerCase() === 'active').length;
    
    // Agregar problemas comuns
    const allIssues = localAnalyses.flatMap(a => a.issues);
    const issueCount: Record<string, number> = {};
    allIssues.forEach(issue => {
      issueCount[issue] = (issueCount[issue] || 0) + 1;
    });
    
    // Ordenar por frequência
    const topIssues = Object.entries(issueCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([issue]) => issue);

    const stats: OverviewStats = {
      totalAds: ads.length,
      activeAds,
      totalSpend: ads.reduce((sum, ad) => sum + ad.spend, 0),
      totalRevenue: ads.reduce((sum, ad) => sum + ad.revenue, 0),
      averageRoas: ads.reduce((sum, ad) => sum + ad.roas, 0) / ads.length,
      highPerformingAds: goodAds,
      poorPerformingAds: poorAds,
      topIssues
    };
    
    setAdAnalyses(localAnalyses);
    setOverviewStats(stats);
    setAnalysisProgress(100);
    setIsLoading(false);
  };

  const resetAnalysis = () => {
    setFile(null);
    setFileName("");
    setAdData([]);
    setAdAnalyses([]);
    setOverviewStats(null);
    setAnalysisProgress(0);
    setCurrentAdId(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const getPerformanceColor = (performance: string) => {
    switch (performance) {
      case 'good':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'average':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'poor':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatPercentage = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'percent',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  const currentAdDetails = currentAdId 
    ? {
        ad: adData.find(ad => ad.adId === currentAdId),
        analysis: adAnalyses.find(analysis => analysis.adId === currentAdId)
      }
    : null;

  if (!isAuthenticated) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Acesso Restrito</CardTitle>
            <CardDescription>Você precisa estar conectado para acessar esta página.</CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/api/login">
              <Button>Fazer Login</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Shopee ADS</h1>
      
      {!overviewStats ? (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-xl">Upload da Planilha de Anúncios</CardTitle>
            <CardDescription>
              Faça upload do relatório de anúncios exportado da sua conta Shopee Ads para analisar e otimizar seu desempenho.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <div 
                className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-12 w-full max-w-md mb-6 text-center cursor-pointer hover:border-primary-500 transition-colors"
                onClick={() => fileInputRef.current?.click()}
              >
                {file ? (
                  <div className="flex flex-col items-center">
                    <FileSpreadsheet size={48} className="mb-4 text-primary-500" />
                    <p className="font-medium text-gray-700 dark:text-gray-300">{fileName}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      {(file.size / 1024).toFixed(2)} KB
                    </p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center">
                    <UploadCloud size={48} className="mb-4 text-gray-400 dark:text-gray-600" />
                    <p className="font-medium text-gray-700 dark:text-gray-300">
                      Arraste e solte seu arquivo ou clique para selecionar
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Suporta arquivos CSV ou Excel exportados da Shopee
                    </p>
                  </div>
                )}
              </div>
              
              <input 
                type="file" 
                ref={fileInputRef}
                className="hidden" 
                accept=".csv,.xls,.xlsx"
                onChange={handleFileChange}
              />
              
              {isLoading && (
                <div className="w-full max-w-md">
                  <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Analisando anúncios... {analysisProgress}%
                  </p>
                  <Progress value={analysisProgress} className="h-2" />
                </div>
              )}
              
              <div className="flex gap-4 mt-6">
                <Button 
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isLoading}
                  variant="outline"
                >
                  Selecionar Arquivo
                </Button>
                
                {file && (
                  <Button
                    onClick={resetAnalysis}
                    disabled={isLoading}
                    variant="ghost"
                  >
                    Cancelar
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        // Resultados da análise
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-medium flex items-center gap-2">
                <FileSpreadsheet size={20} className="text-primary-500" />
                {fileName}
              </h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {adData.length} anúncios analisados
              </p>
            </div>
            <div className="flex gap-3">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => fileInputRef.current?.click()}
              >
                <UploadCloud size={16} className="mr-2" />
                Novo Arquivo
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={resetAnalysis}
              >
                <RefreshCw size={16} className="mr-2" />
                Reiniciar
              </Button>
            </div>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full max-w-md grid-cols-3">
              <TabsTrigger value="overview">Visão Geral</TabsTrigger>
              <TabsTrigger value="ads">Anúncios</TabsTrigger>
              <TabsTrigger value="recommendations">Recomendações</TabsTrigger>
            </TabsList>
            
            {/* Visão Geral */}
            <TabsContent value="overview" className="space-y-6 pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">
                      Gasto Total
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {formatCurrency(overviewStats.totalSpend)}
                    </div>
                    <p className="text-sm text-gray-500">
                      em {overviewStats.activeAds} anúncios ativos
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">
                      Receita Total
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {formatCurrency(overviewStats.totalRevenue)}
                    </div>
                    <p className="text-sm text-gray-500">
                      de {adData.reduce((sum, ad) => sum + ad.orders, 0)} pedidos
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">
                      ROAS Médio
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {overviewStats.averageRoas.toFixed(2)}x
                    </div>
                    <p className="text-sm text-gray-500">
                      Retorno sobre investimento
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">
                      Eficiência dos Anúncios
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                        <span className="text-sm">{overviewStats.highPerformingAds}</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
                        <span className="text-sm">
                          {overviewStats.totalAds - overviewStats.highPerformingAds - overviewStats.poorPerformingAds}
                        </span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                        <span className="text-sm">{overviewStats.poorPerformingAds}</span>
                      </div>
                    </div>
                    <Progress 
                      value={overviewStats.highPerformingAds / overviewStats.totalAds * 100} 
                      className="h-2 mt-2" 
                    />
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="md:col-span-2">
                  <CardHeader>
                    <CardTitle>Problemas Comuns</CardTitle>
                    <CardDescription>Principais questões encontradas nos anúncios</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {overviewStats.topIssues.length > 0 ? (
                      <ul className="space-y-4">
                        {overviewStats.topIssues.map((issue, index) => (
                          <li key={index} className="flex items-start">
                            <AlertCircle size={20} className="text-amber-500 mr-2 mt-0.5" />
                            <div>
                              <p className="font-medium">{issue}</p>
                              <p className="text-sm text-gray-500">
                                Encontrado em {adAnalyses.filter(a => a.issues.includes(issue)).length} anúncios
                              </p>
                            </div>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <div className="text-center py-6">
                        <CheckCircle size={32} className="text-green-500 mx-auto mb-2" />
                        <p className="text-gray-600 dark:text-gray-400">
                          Não identificamos problemas críticos nos seus anúncios
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Oportunidades</CardTitle>
                    <CardDescription>Áreas para otimização</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Títulos</span>
                          <span className="text-sm text-gray-500">
                            {adAnalyses.filter(a => a.optimizedTitle).length} precisam melhorar
                          </span>
                        </div>
                        <Progress value={
                          (1 - adAnalyses.filter(a => a.optimizedTitle).length / adAnalyses.length) * 100
                        } className="h-2" />
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Orçamentos</span>
                          <span className="text-sm text-gray-500">
                            {adAnalyses.filter(a => a.optimizedBudget).length} podem ser otimizados
                          </span>
                        </div>
                        <Progress value={
                          (1 - adAnalyses.filter(a => a.optimizedBudget).length / adAnalyses.length) * 100
                        } className="h-2" />
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Lances</span>
                          <span className="text-sm text-gray-500">
                            {adAnalyses.filter(a => a.optimizedBid).length} podem ser ajustados
                          </span>
                        </div>
                        <Progress value={
                          (1 - adAnalyses.filter(a => a.optimizedBid).length / adAnalyses.length) * 100
                        } className="h-2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            {/* Lista de Anúncios */}
            <TabsContent value="ads" className="space-y-6 pt-4">
              <div className="overflow-x-auto">
                <Table>
                  <TableCaption>Lista de {adData.length} anúncios analisados</TableCaption>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Anúncio</TableHead>
                      <TableHead>Score</TableHead>
                      <TableHead>Impressões</TableHead>
                      <TableHead>Cliques</TableHead>
                      <TableHead>CTR</TableHead>
                      <TableHead>Gasto</TableHead>
                      <TableHead>ROAS</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {adData.map((ad, index) => {
                      const analysis = adAnalyses.find(a => a.adId === ad.adId);
                      return (
                        <TableRow key={ad.adId || index} className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800" onClick={() => setCurrentAdId(ad.adId)}>
                          <TableCell className="font-medium max-w-xs truncate">{ad.title}</TableCell>
                          <TableCell>
                            {analysis && (
                              <div className="flex items-center">
                                <div className={`h-2 w-2 rounded-full mr-2 ${analysis.performance === 'good' ? 'bg-green-500' : analysis.performance === 'average' ? 'bg-yellow-500' : 'bg-red-500'}`}></div>
                                <span>{analysis.score}</span>
                              </div>
                            )}
                          </TableCell>
                          <TableCell>{ad.impressions.toLocaleString()}</TableCell>
                          <TableCell>{ad.clicks.toLocaleString()}</TableCell>
                          <TableCell>{formatPercentage(ad.ctr)}</TableCell>
                          <TableCell>{formatCurrency(ad.spend)}</TableCell>
                          <TableCell className={`font-medium ${ad.roas >= 3 ? 'text-green-600 dark:text-green-400' : ad.roas < 1 ? 'text-red-600 dark:text-red-400' : ''}`}>
                            {ad.roas.toFixed(2)}x
                          </TableCell>
                          <TableCell>
                            <Badge variant={ad.status.toLowerCase() === 'active' ? 'default' : 'secondary'}>
                              {ad.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm" onClick={(e) => {
                              e.stopPropagation();
                              setCurrentAdId(ad.adId);
                              setActiveTab("recommendations");
                            }}>
                              <ArrowUpRight size={16} />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
              
              {currentAdId && currentAdDetails && (
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{currentAdDetails.ad?.title}</CardTitle>
                        <CardDescription>ID: {currentAdDetails.ad?.adId}</CardDescription>
                      </div>
                      <Badge className={getPerformanceColor(currentAdDetails.analysis?.performance || '')}>
                        {currentAdDetails.analysis?.performance === 'good' ? 'Bom desempenho' : 
                         currentAdDetails.analysis?.performance === 'average' ? 'Desempenho médio' : 
                         'Baixo desempenho'}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-lg font-medium mb-4">Métricas</h3>
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <p className="text-sm text-gray-500">Impressões</p>
                              <p className="font-medium">{currentAdDetails.ad?.impressions.toLocaleString()}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Cliques</p>
                              <p className="font-medium">{currentAdDetails.ad?.clicks.toLocaleString()}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">CTR</p>
                              <p className="font-medium">{formatPercentage(currentAdDetails.ad?.ctr || 0)}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">CPC</p>
                              <p className="font-medium">{formatCurrency(currentAdDetails.ad?.cpc || 0)}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Pedidos</p>
                              <p className="font-medium">{currentAdDetails.ad?.orders}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">CVR</p>
                              <p className="font-medium">{formatPercentage(currentAdDetails.ad?.cvr || 0)}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Gasto</p>
                              <p className="font-medium">{formatCurrency(currentAdDetails.ad?.spend || 0)}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Receita</p>
                              <p className="font-medium">{formatCurrency(currentAdDetails.ad?.revenue || 0)}</p>
                            </div>
                          </div>
                          
                          <div>
                            <p className="text-sm text-gray-500 mb-1">ROAS</p>
                            <div className="flex items-center">
                              <span className={`text-lg font-bold ${
                                (currentAdDetails.ad?.roas || 0) >= 3 ? 'text-green-600 dark:text-green-400' : 
                                (currentAdDetails.ad?.roas || 0) < 1 ? 'text-red-600 dark:text-red-400' : ''
                              }`}>
                                {(currentAdDetails.ad?.roas || 0).toFixed(2)}x
                              </span>
                              <div className="flex-1 ml-4">
                                <Progress 
                                  value={Math.min((currentAdDetails.ad?.roas || 0) / 5 * 100, 100)} 
                                  className="h-2" 
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="text-lg font-medium mb-4">Análise</h3>
                        {currentAdDetails.analysis?.issues.length ? (
                          <div>
                            <p className="text-sm font-medium mb-2">Problemas identificados:</p>
                            <ul className="space-y-2 mb-4">
                              {currentAdDetails.analysis?.issues.map((issue, index) => (
                                <li key={index} className="flex items-start">
                                  <AlertTriangle size={16} className="text-amber-500 mr-2 mt-0.5" />
                                  <span className="text-sm">{issue}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        ) : (
                          <div className="flex items-start mb-4">
                            <CheckCircle size={16} className="text-green-500 mr-2 mt-0.5" />
                            <span className="text-sm">Não foram identificados problemas críticos neste anúncio</span>
                          </div>
                        )}
                        
                        {currentAdDetails.analysis?.suggestions.length ? (
                          <div>
                            <p className="text-sm font-medium mb-2">Sugestões:</p>
                            <ul className="space-y-2">
                              {currentAdDetails.analysis?.suggestions.map((suggestion, index) => (
                                <li key={index} className="flex items-start">
                                  <ArrowUpRight size={16} className="text-blue-500 mr-2 mt-0.5" />
                                  <span className="text-sm">{suggestion}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        ) : null}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-end border-t pt-4">
                    <Button variant="outline" size="sm" onClick={() => setCurrentAdId(null)}>
                      Fechar
                    </Button>
                  </CardFooter>
                </Card>
              )}
            </TabsContent>
            
            {/* Recomendações */}
            <TabsContent value="recommendations" className="space-y-6 pt-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>Otimização de Anúncios</CardTitle>
                      <CardDescription>
                        Medidas recomendadas para melhorar o desempenho dos seus anúncios
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {adAnalyses.some(a => a.issues.length > 0) ? (
                        <div className="space-y-6">
                          {/* Anúncios com problema de CTR */}
                          {adAnalyses.some(a => a.issues.includes("CTR baixo")) && (
                            <div>
                              <h3 className="text-lg font-medium mb-3 flex items-center">
                                <BarChart3 size={20} className="text-blue-500 mr-2" />
                                Melhorar Taxa de Cliques (CTR)
                              </h3>
                              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                                Os seguintes anúncios têm CTR abaixo do ideal. Considere melhorar os títulos
                                e elementos de atração de cliques.
                              </p>
                              
                              <div className="space-y-4">
                                {adAnalyses
                                  .filter(a => a.issues.includes("CTR baixo"))
                                  .slice(0, 3)
                                  .map((analysis, index) => {
                                    const ad = adData.find(a => a.adId === analysis.adId);
                                    return (
                                      <div key={index} className="border rounded-lg p-4">
                                        <div className="flex justify-between items-start mb-2">
                                          <p className="font-medium">{ad?.title}</p>
                                          <Badge variant="outline">CTR: {formatPercentage(ad?.ctr || 0)}</Badge>
                                        </div>
                                        
                                        {analysis.optimizedTitle && (
                                          <div className="mt-3">
                                            <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Título sugerido:</p>
                                            <div className="bg-primary-50 dark:bg-primary-900/20 p-3 rounded text-sm">
                                              {analysis.optimizedTitle}
                                            </div>
                                          </div>
                                        )}
                                        
                                        <div className="flex items-center justify-between mt-4">
                                          <div className="text-sm text-gray-500">
                                            Melhoria estimada: <span className="text-green-600 font-medium">
                                              +{(((analysis.estimatedImprovement?.ctr || 0) / (ad?.ctr || 1) - 1) * 100).toFixed(0)}%
                                            </span>
                                          </div>
                                          <Button 
                                            variant="link" 
                                            size="sm" 
                                            className="text-primary-600"
                                            onClick={() => {
                                              setCurrentAdId(analysis.adId);
                                              setActiveTab("ads");
                                            }}
                                          >
                                            Ver detalhes
                                          </Button>
                                        </div>
                                      </div>
                                    );
                                  })}
                              </div>
                            </div>
                          )}
                          
                          {/* Anúncios com problema de ROAS */}
                          {adAnalyses.some(a => a.issues.includes("ROAS baixo")) && (
                            <div>
                              <h3 className="text-lg font-medium mb-3 flex items-center">
                                <LineChart size={20} className="text-blue-500 mr-2" />
                                Melhorar Retorno sobre Investimento (ROAS)
                              </h3>
                              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                                Os seguintes anúncios têm ROAS abaixo do ideal. Considere ajustar orçamentos
                                e segmentação.
                              </p>
                              
                              <div className="space-y-4">
                                {adAnalyses
                                  .filter(a => a.issues.includes("ROAS baixo"))
                                  .slice(0, 3)
                                  .map((analysis, index) => {
                                    const ad = adData.find(a => a.adId === analysis.adId);
                                    return (
                                      <div key={index} className="border rounded-lg p-4">
                                        <div className="flex justify-between items-start mb-2">
                                          <p className="font-medium">{ad?.title}</p>
                                          <Badge variant="outline">ROAS: {(ad?.roas || 0).toFixed(2)}x</Badge>
                                        </div>
                                        
                                        <div className="grid grid-cols-2 gap-4 mt-3">
                                          {analysis.optimizedBid && (
                                            <div>
                                              <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">CPC sugerido:</p>
                                              <div className="bg-primary-50 dark:bg-primary-900/20 p-2 rounded text-sm font-medium">
                                                {formatCurrency(analysis.optimizedBid)}
                                                <span className="text-xs text-gray-500 block">
                                                  Original: {formatCurrency(ad?.cpc || 0)}
                                                </span>
                                              </div>
                                            </div>
                                          )}
                                          
                                          {analysis.optimizedBudget && (
                                            <div>
                                              <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Orçamento sugerido:</p>
                                              <div className="bg-primary-50 dark:bg-primary-900/20 p-2 rounded text-sm font-medium">
                                                {formatCurrency(analysis.optimizedBudget)}
                                                <span className="text-xs text-gray-500 block">
                                                  Original: {formatCurrency(ad?.budget || 0)}
                                                </span>
                                              </div>
                                            </div>
                                          )}
                                        </div>
                                        
                                        <div className="flex items-center justify-between mt-4">
                                          <div className="text-sm text-gray-500">
                                            Melhoria estimada: <span className="text-green-600 font-medium">
                                              +{(((analysis.estimatedImprovement?.roas || 0) / (ad?.roas || 1) - 1) * 100).toFixed(0)}%
                                            </span>
                                          </div>
                                          <Button 
                                            variant="link" 
                                            size="sm" 
                                            className="text-primary-600"
                                            onClick={() => {
                                              setCurrentAdId(analysis.adId);
                                              setActiveTab("ads");
                                            }}
                                          >
                                            Ver detalhes
                                          </Button>
                                        </div>
                                      </div>
                                    );
                                  })}
                              </div>
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="text-center py-12">
                          <CheckCircle size={48} className="text-green-500 mx-auto mb-4" />
                          <h3 className="text-xl font-medium mb-2">Seus anúncios estão bem otimizados!</h3>
                          <p className="text-gray-600 dark:text-gray-400 max-w-md mx-auto">
                            Não identificamos problemas críticos que precisem de atenção imediata. Continue monitorando o desempenho regularmente.
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
                
                <div>
                  <Card>
                    <CardHeader>
                      <CardTitle>Próximos Passos</CardTitle>
                      <CardDescription>
                        Ações recomendadas para melhorar sua estratégia de anúncios
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-4">
                        <li className="flex items-start">
                          <div className="bg-primary-100 dark:bg-primary-900 text-primary-800 dark:text-primary-300 font-medium h-6 w-6 rounded-full flex items-center justify-center text-sm mr-3 mt-0.5">
                            1
                          </div>
                          <div>
                            <p className="font-medium">Otimize títulos dos anúncios</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                              Implemente os títulos sugeridos para anúncios com baixo CTR para aumentar a taxa de cliques.
                            </p>
                          </div>
                        </li>
                        
                        <li className="flex items-start">
                          <div className="bg-primary-100 dark:bg-primary-900 text-primary-800 dark:text-primary-300 font-medium h-6 w-6 rounded-full flex items-center justify-center text-sm mr-3 mt-0.5">
                            2
                          </div>
                          <div>
                            <p className="font-medium">Redistribua orçamentos</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                              Redirecione investimentos de anúncios com baixo desempenho para aqueles com melhor ROAS.
                            </p>
                          </div>
                        </li>
                        
                        <li className="flex items-start">
                          <div className="bg-primary-100 dark:bg-primary-900 text-primary-800 dark:text-primary-300 font-medium h-6 w-6 rounded-full flex items-center justify-center text-sm mr-3 mt-0.5">
                            3
                          </div>
                          <div>
                            <p className="font-medium">Ajuste os lances</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                              Implemente os valores de CPC recomendados para otimizar o custo por aquisição.
                            </p>
                          </div>
                        </li>
                        
                        <li className="flex items-start">
                          <div className="bg-primary-100 dark:bg-primary-900 text-primary-800 dark:text-primary-300 font-medium h-6 w-6 rounded-full flex items-center justify-center text-sm mr-3 mt-0.5">
                            4
                          </div>
                          <div>
                            <p className="font-medium">Pausar anúncios de baixo desempenho</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                              Considere pausar temporariamente anúncios com ROAS abaixo de 1 para revisão.
                            </p>
                          </div>
                        </li>
                        
                        <li className="flex items-start">
                          <div className="bg-primary-100 dark:bg-primary-900 text-primary-800 dark:text-primary-300 font-medium h-6 w-6 rounded-full flex items-center justify-center text-sm mr-3 mt-0.5">
                            5
                          </div>
                          <div>
                            <p className="font-medium">Analise resultados semanalmente</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                              Upload novos relatórios regularmente para acompanhar o progresso das otimizações.
                            </p>
                          </div>
                        </li>
                      </ul>
                      
                      <Separator className="my-6" />
                      
                      <div className="rounded-lg border bg-card p-4">
                        <h4 className="text-sm font-medium mb-3">Exportar relatório de recomendações</h4>
                        <div className="space-y-3">
                          <div className="flex items-center">
                            <Input
                              type="email"
                              placeholder="seu-email@exemplo.com"
                              className="rounded-r-none"
                            />
                            <Button className="rounded-l-none">
                              Enviar
                            </Button>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            Receba um relatório detalhado com todas as sugestões de otimização para seus anúncios.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
}