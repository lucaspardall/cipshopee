import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import PageHeader from "@/components/ui/page-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Loader2 } from "lucide-react";
import { NewsItem, Event } from "@/types";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function News() {
  // Fetch news
  const { data: newsData, isLoading: isLoadingNews } = useQuery({
    queryKey: ["/api/news"],
  });

  // Fetch events
  const { data: eventsData, isLoading: isLoadingEvents } = useQuery({
    queryKey: ["/api/events"],
  });

  const [news, setNews] = useState<NewsItem[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Process news data
  useEffect(() => {
    if (newsData) {
      const formattedNews = newsData.map((item: any) => {
        return {
          id: item.id,
          title: item.title,
          description: item.content,
          date: format(new Date(item.publishDate), "d 'de' MMMM, yyyy", { locale: ptBR }),
          imageUrl: item.imageUrl || "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=200",
          link: item.url || `/news/${item.id}`,
          category: item.category || "PLATFORM"
        };
      });
      setNews(formattedNews);
    }
  }, [newsData]);

  // Process events data
  useEffect(() => {
    if (eventsData) {
      setEvents(eventsData);
    }
  }, [eventsData]);

  // Filter news based on search and category
  const filteredNews = news.filter(item => {
    const matchesSearch = searchTerm ? 
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) 
      : true;
      
    const matchesCategory = selectedCategory ? 
      item.category === selectedCategory 
      : true;
      
    return matchesSearch && matchesCategory;
  });

  // Filter events based on search
  const filteredEvents = events.filter(item => {
    if (!searchTerm) return true;
    
    return (
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.description && item.description.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  });

  // Get unique categories
  const categories = news.reduce((acc: string[], item) => {
    if (item.category && !acc.includes(item.category)) {
      acc.push(item.category);
    }
    return acc;
  }, []);

  const isLoading = isLoadingNews || isLoadingEvents;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-12 w-12 animate-spin text-primary-500" />
        <span className="ml-2 text-xl font-medium text-primary-500">Carregando centro de notícias...</span>
      </div>
    );
  }

  return (
    <>
      <PageHeader 
        title="Centro de Notícias" 
        description="Fique por dentro das últimas novidades, eventos e atualizações da Shopee."
      />
      
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <Input 
              type="text" 
              placeholder="Pesquisar por novidades ou eventos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="md:max-w-md"
            />
            
            <div className="flex gap-2 flex-wrap">
              <button 
                className={`px-3 py-1 text-sm rounded-full ${
                  selectedCategory === null ? 'bg-primary-500 text-white' : 'bg-gray-100 text-gray-700'
                }`}
                onClick={() => setSelectedCategory(null)}
              >
                Todos
              </button>
              
              {categories.map((category) => (
                <button 
                  key={category}
                  className={`px-3 py-1 text-sm rounded-full ${
                    selectedCategory === category ? 'bg-primary-500 text-white' : 'bg-gray-100 text-gray-700'
                  }`}
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Tabs defaultValue="news" className="space-y-6">
        <TabsList className="grid grid-cols-2 w-full max-w-md mx-auto">
          <TabsTrigger value="news">Notícias</TabsTrigger>
          <TabsTrigger value="events">Eventos</TabsTrigger>
        </TabsList>
        
        <TabsContent value="news">
          {filteredNews.length === 0 ? (
            <Card>
              <CardContent className="pt-6 flex flex-col items-center justify-center min-h-[200px]">
                <p className="text-gray-500 text-lg">Nenhuma notícia encontrada.</p>
                {searchTerm && (
                  <button 
                    className="mt-4 text-primary-500 font-medium"
                    onClick={() => {
                      setSearchTerm("");
                      setSelectedCategory(null);
                    }}
                  >
                    Limpar filtros
                  </button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredNews.map((item) => (
                <Card key={item.id} className="overflow-hidden hover:shadow-md transition cursor-pointer">
                  <div className="h-48 overflow-hidden">
                    <img 
                      src={item.imageUrl} 
                      alt={item.title} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between text-xs text-gray-500 mb-2">
                      <div className="flex items-center">
                        <i className="fas fa-calendar-alt mr-1"></i> {item.date}
                      </div>
                      <div className="px-2 py-0.5 bg-primary-50 text-primary-700 rounded-full">
                        {item.category}
                      </div>
                    </div>
                    <h3 className="font-semibold text-base mb-2 line-clamp-2">{item.title}</h3>
                    <p className="text-sm text-gray-500 mb-3 line-clamp-3">{item.description}</p>
                    <a href={item.link} className="text-sm font-semibold text-primary-500">
                      Ler mais
                    </a>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="events">
          {filteredEvents.length === 0 ? (
            <Card>
              <CardContent className="pt-6 flex flex-col items-center justify-center min-h-[200px]">
                <p className="text-gray-500 text-lg">Nenhum evento encontrado.</p>
                {searchTerm && (
                  <button 
                    className="mt-4 text-primary-500 font-medium"
                    onClick={() => setSearchTerm("")}
                  >
                    Limpar filtros
                  </button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredEvents.map((event) => {
                const startDate = new Date(event.startDate);
                const endDate = event.endDate ? new Date(event.endDate) : null;
                const isPast = startDate < new Date();
                const isOngoing = startDate <= new Date() && endDate && endDate >= new Date();
                
                return (
                  <Card key={event.id} className="overflow-hidden hover:shadow-sm transition">
                    <div className="flex flex-col md:flex-row">
                      <div className="w-full md:w-48 bg-primary-50 p-4 flex flex-col items-center justify-center">
                        <div className="text-2xl font-bold text-primary-700">
                          {format(startDate, "d", { locale: ptBR })}
                        </div>
                        <div className="text-lg font-medium text-primary-600">
                          {format(startDate, "MMM", { locale: ptBR }).toUpperCase()}
                        </div>
                        <div className="text-sm text-primary-500">
                          {format(startDate, "yyyy", { locale: ptBR })}
                        </div>
                        {endDate && (
                          <div className="text-xs text-primary-400 mt-1">
                            até {format(endDate, "d 'de' MMM", { locale: ptBR })}
                          </div>
                        )}
                      </div>
                      
                      <CardContent className="p-4 flex-1">
                        <div className="flex justify-between">
                          <h3 className="font-semibold text-lg mb-1">{event.title}</h3>
                          <div className={`px-2 py-0.5 rounded-full text-xs ${
                            isPast && !isOngoing
                              ? 'bg-gray-100 text-gray-600'
                              : isOngoing
                                ? 'bg-green-50 text-green-700'
                                : event.priority === 'HIGH'
                                  ? 'bg-red-50 text-red-700'
                                  : event.priority === 'MEDIUM'
                                    ? 'bg-yellow-50 text-yellow-700'
                                    : 'bg-blue-50 text-blue-700'
                          }`}>
                            {isPast && !isOngoing
                              ? 'Encerrado'
                              : isOngoing
                                ? 'Em andamento'
                                : event.priority === 'HIGH'
                                  ? 'Alta prioridade'
                                  : event.priority === 'MEDIUM'
                                    ? 'Média prioridade'
                                    : 'Baixa prioridade'}
                          </div>
                        </div>
                        
                        <p className="text-gray-600 mb-4">
                          {event.description || "Evento promocional da Shopee. Participe para aumentar suas vendas e visibilidade."}
                        </p>
                        
                        <div className="flex items-center text-sm text-gray-500">
                          <div className="flex items-center mr-4">
                            <i className="fas fa-tag mr-1"></i>
                            <span>{event.category || "SALE"}</span>
                          </div>
                          
                          {!isPast && (
                            <a 
                              href={`/events/${event.id}`} 
                              className="text-primary-500 font-medium hover:text-primary-600"
                            >
                              {isOngoing ? 'Participar agora' : 'Ver detalhes'}
                            </a>
                          )}
                        </div>
                      </CardContent>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </>
  );
}
