import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

export default function Home() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <div className="min-h-screen flex flex-col">
      <header className="py-4 px-6 bg-white border-b border-gray-200">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <div className="w-10 h-10 flex items-center justify-center bg-primary-500 text-white rounded-lg font-bold text-lg font-poppins">
              CIP
            </div>
            <h1 className="ml-2 text-xl font-semibold text-primary-500 font-poppins">
              Centro de<br/>Inteligência
            </h1>
          </div>
          <div className="space-x-4">
            {isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin text-primary-500" />
            ) : isAuthenticated ? (
              <Button asChild>
                <Link href="/dashboard">Ir para Dashboard</Link>
              </Button>
            ) : (
              <>
                <Button variant="outline" asChild>
                  <Link href="/login">Entrar</Link>
                </Button>
                <Button asChild>
                  <Link href="/register">Cadastre-se</Link>
                </Button>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-16 md:py-24 bg-gradient-to-br from-primary-50 to-blue-50">
          <div className="container mx-auto px-6 text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-primary-800 mb-6 font-poppins">
              Centro de Inteligência Pardal para Shopee
            </h1>
            <p className="text-lg md:text-xl text-gray-700 max-w-3xl mx-auto mb-8">
              Otimize seus anúncios, analise sua loja e maximize suas oportunidades na Shopee com nossa plataforma de inteligência avançada.
            </p>
            <div className="space-x-4">
              {isAuthenticated ? (
                <Button size="lg" asChild>
                  <Link href="/dashboard">Ir para Dashboard</Link>
                </Button>
              ) : (
                <Button size="lg" asChild>
                  <Link href="/register">Comece Gratuitamente</Link>
                </Button>
              )}
              <Button size="lg" variant="outline">
                Saiba Mais
              </Button>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container mx-auto px-6">
            <h2 className="text-3xl font-bold text-center mb-12 font-poppins">
              Principais Funcionalidades
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-primary-50 rounded-xl p-6 text-center">
                <div className="w-16 h-16 bg-primary-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-magic text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold mb-3 font-poppins">Otimizador de Anúncios</h3>
                <p className="text-gray-700">
                  Melhore seus anúncios existentes com títulos e descrições otimizados prontos para copiar e colar.
                </p>
              </div>
              <div className="bg-secondary-50 rounded-xl p-6 text-center">
                <div className="w-16 h-16 bg-secondary-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-chart-line text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold mb-3 font-poppins">Dashboard Analítico</h3>
                <p className="text-gray-700">
                  Visualize todos os indicadores de saúde da sua loja com ações recomendadas para melhorar seu desempenho.
                </p>
              </div>
              <div className="bg-purple-50 rounded-xl p-6 text-center">
                <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-newspaper text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold mb-3 font-poppins">Centro de Notícias</h3>
                <p className="text-gray-700">
                  Fique por dentro de todos os eventos, promoções e atualizações da Shopee para nunca perder oportunidades.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-6 text-center">
            <h2 className="text-3xl font-bold mb-12 font-poppins">
              Planos que se adaptam a suas necessidades
            </h2>
            <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-semibold mb-2 font-poppins">Plano Gratuito</h3>
                <div className="text-3xl font-bold mb-4">R$ 0</div>
                <p className="text-gray-600 mb-6">Para começar a otimizar sua loja</p>
                <ul className="text-left space-y-2 mb-6">
                  <li className="flex items-center">
                    <i className="fas fa-check text-green-500 mr-2"></i>
                    <span>3 otimizações por mês</span>
                  </li>
                  <li className="flex items-center">
                    <i className="fas fa-check text-green-500 mr-2"></i>
                    <span>Dashboard básico</span>
                  </li>
                  <li className="flex items-center">
                    <i className="fas fa-check text-green-500 mr-2"></i>
                    <span>Centro de notícias</span>
                  </li>
                </ul>
                <Button className="w-full" variant="outline">
                  Começar Grátis
                </Button>
              </div>
              <div className="bg-primary-500 text-white rounded-xl shadow-md p-6 transform scale-105">
                <div className="bg-secondary-500 text-white text-xs rounded-full py-1 px-3 w-fit mx-auto mb-2">
                  Mais Popular
                </div>
                <h3 className="text-xl font-semibold mb-2 font-poppins">Plano Essencial</h3>
                <div className="text-3xl font-bold mb-4">R$ 97/mês</div>
                <p className="text-primary-50 mb-6">Acesso a todas ferramentas básicas</p>
                <ul className="text-left space-y-2 mb-6">
                  <li className="flex items-center">
                    <i className="fas fa-check mr-2"></i>
                    <span>Otimizações ilimitadas</span>
                  </li>
                  <li className="flex items-center">
                    <i className="fas fa-check mr-2"></i>
                    <span>Dashboard completo</span>
                  </li>
                  <li className="flex items-center">
                    <i className="fas fa-check mr-2"></i>
                    <span>Criador de anúncios</span>
                  </li>
                  <li className="flex items-center">
                    <i className="fas fa-check mr-2"></i>
                    <span>Alertas personalizados</span>
                  </li>
                </ul>
                <Button className="w-full bg-white text-primary-500 hover:bg-primary-50">
                  Escolher Plano
                </Button>
              </div>
              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-semibold mb-2 font-poppins">Plano Plus</h3>
                <div className="text-3xl font-bold mb-4">R$ 147/mês</div>
                <p className="text-gray-600 mb-6">Para vendedores avançados</p>
                <ul className="text-left space-y-2 mb-6">
                  <li className="flex items-center">
                    <i className="fas fa-check text-green-500 mr-2"></i>
                    <span>Tudo do plano Essencial</span>
                  </li>
                  <li className="flex items-center">
                    <i className="fas fa-check text-green-500 mr-2"></i>
                    <span>Análise de concorrência</span>
                  </li>
                  <li className="flex items-center">
                    <i className="fas fa-check text-green-500 mr-2"></i>
                    <span>Prioridade no suporte</span>
                  </li>
                  <li className="flex items-center">
                    <i className="fas fa-check text-green-500 mr-2"></i>
                    <span>Acesso prioritário a API</span>
                  </li>
                </ul>
                <Button className="w-full">
                  Escolher Plano
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between mb-8">
            <div className="mb-6 md:mb-0">
              <div className="flex items-center">
                <div className="w-10 h-10 flex items-center justify-center bg-white text-primary-500 rounded-lg font-bold text-lg font-poppins">
                  CIP
                </div>
                <h2 className="ml-2 text-xl font-semibold text-white font-poppins">
                  Centro de<br/>Inteligência
                </h2>
              </div>
              <p className="mt-4 max-w-xs text-gray-400">
                Plataforma completa para vendedores da Shopee otimizarem seu negócio com inteligência artificial.
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-4 font-poppins">Plataforma</h3>
                <ul className="space-y-2">
                  <li><a href="#" className="text-gray-400 hover:text-white">Funcionalidades</a></li>
                  <li><a href="#" className="text-gray-400 hover:text-white">Planos</a></li>
                  <li><a href="#" className="text-gray-400 hover:text-white">FAQ</a></li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4 font-poppins">Empresa</h3>
                <ul className="space-y-2">
                  <li><a href="#" className="text-gray-400 hover:text-white">Sobre nós</a></li>
                  <li><a href="#" className="text-gray-400 hover:text-white">Blog</a></li>
                  <li><a href="#" className="text-gray-400 hover:text-white">Contato</a></li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4 font-poppins">Legal</h3>
                <ul className="space-y-2">
                  <li><a href="#" className="text-gray-400 hover:text-white">Termos de Uso</a></li>
                  <li><a href="#" className="text-gray-400 hover:text-white">Privacidade</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 mt-8 text-center text-gray-400">
            <p>© {new Date().getFullYear()} Centro de Inteligência Pardal (CIP) - Todos os direitos reservados</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
