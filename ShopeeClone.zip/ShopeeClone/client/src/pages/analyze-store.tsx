import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import PageHeader from "@/components/ui/page-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { getStoreAnalytics } from "@/lib/ai";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadialProgress } from "@/components/common/radial-progress";
import { DataSourceWrapper } from "@/components/common/data-source-indicator";
import { DataSourceType } from "@shared/schema";
import { Loader2, ArrowUp, ArrowDown, Minus, Store, ArrowRight } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { queryClient } from "@/lib/queryClient";
import {
  BarChart,
  Bar,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Legend,
} from "recharts";

export default function AnalyzeStore() {
  const { data: analyticsData, isLoading } = useQuery({
    queryKey: ["/api/store-analytics"],
    queryFn: getStoreAnalytics,
  });

  // Estado para URL da loja e análise
  const [storeUrl, setStoreUrl] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analyzeError, setAnalyzeError] = useState("");

  // State for dimensional scores
  const [dimensionalScores, setDimensionalScores] = useState<any[]>([]);
  const [competitorData, setCompetitorData] = useState<any[]>([]);
  const [productPerformance, setProductPerformance] = useState<any[]>([]);
  const [trafficSourceData, setTrafficSourceData] = useState<any[]>([]);

  // Função para analisar loja pelo URL
  const analyzeStoreByUrl = async () => {
    if (!storeUrl) {
      setAnalyzeError("Por favor, insira o URL da sua loja na Shopee");
      return;
    }

    if (!storeUrl.includes("shopee")) {
      setAnalyzeError("Por favor, insira um URL válido da Shopee");
      return;
    }

    try {
      setIsAnalyzing(true);
      setAnalyzeError("");

      const response = await fetch("/api/analyze-store-by-url", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ storeUrl }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Erro ao analisar loja");
      }

      // Atualizar dados após análise bem-sucedida
      queryClient.invalidateQueries({ queryKey: ["/api/store-analytics"] });
      
      setStoreUrl("");
      setIsAnalyzing(false);
    } catch (err) {
      console.error("Erro ao analisar loja:", err);
      const errorMsg = err instanceof Error ? err.message : "Erro ao processar a análise da loja";
      setAnalyzeError(errorMsg);
      setIsAnalyzing(false);
    }
  };

  // Generate additional analysis data
  useEffect(() => {
    if (analyticsData) {
      // Set dimensional scores
      setDimensionalScores([
        { name: "Listings", value: analyticsData.analytics.listingQualityScore, fill: "#1a3a8f" },
        { name: "Preços", value: analyticsData.analytics.priceCompetitivenessScore, fill: "#ff6b35" },
        { name: "Marketing", value: analyticsData.analytics.marketingEffectivenessScore, fill: "#00c9a7" },
        { name: "Satisfação", value: analyticsData.analytics.customerSatisfactionScore, fill: "#6247aa" },
        { name: "Visibilidade", value: analyticsData.analytics.visibilityScore, fill: "#ff595e" },
      ]);

      // Set competitor data
      setCompetitorData([
        { name: "Você", score: analyticsData.analytics.overallScore, fill: "#1a3a8f" },
        { name: "Concorrente A", score: Math.floor(Math.random() * 10) + 70, fill: "#cccccc" },
        { name: "Concorrente B", score: Math.floor(Math.random() * 10) + 65, fill: "#cccccc" },
        { name: "Concorrente C", score: Math.floor(Math.random() * 10) + 60, fill: "#cccccc" },
        { name: "Média", score: 68, fill: "#ff6b35" },
      ]);

      // Set product performance data
      setProductPerformance([
        { name: "Produto A", views: 258, sales: 42, conversion: 16.3 },
        { name: "Produto B", views: 195, sales: 27, conversion: 13.8 },
        { name: "Produto C", views: 145, sales: 18, conversion: 12.4 },
        { name: "Produto D", views: 102, sales: 12, conversion: 11.8 },
        { name: "Produto E", views: 87, sales: 8, conversion: 9.2 },
      ]);

      // Set traffic source data
      setTrafficSourceData([
        { name: "Busca", value: 65 },
        { name: "Anúncios", value: 15 },
        { name: "Direto", value: 10 },
        { name: "Recomendações", value: 10 },
      ]);
    }
  }, [analyticsData]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-12 w-12 animate-spin text-primary-500" />
        <span className="ml-2 text-xl font-medium text-primary-500">Carregando análise...</span>
      </div>
    );
  }

  if (!analyticsData) {
    return (
      <>
        <PageHeader 
          title="Analisador da Loja" 
          description="Análise completa da sua loja na Shopee com métricas detalhadas e recomendações."
        />
        <Card>
          <CardContent className="pt-6 flex flex-col items-center justify-center min-h-[400px]">
            <p className="text-gray-500 text-lg">Não foi possível carregar os dados da análise.</p>
            <button className="mt-4 px-4 py-2 bg-primary-500 text-white rounded-lg">
              Tentar novamente
            </button>
          </CardContent>
        </Card>
      </>
    );
  }

  return (
    <>
      <PageHeader 
        title="Analisador da Loja" 
        description="Análise completa da sua loja na Shopee com métricas detalhadas e recomendações."
      />
      
      {/* Formulário de análise de loja por URL */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Store className="w-5 h-5 mr-2" />
            Analisar Loja Shopee
          </CardTitle>
          <CardDescription>
            Cole o link da sua loja na Shopee para obter uma análise detalhada do desempenho e recomendações personalizadas.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="store-url">URL da Loja Shopee</Label>
              <div className="flex gap-2">
                <Input
                  id="store-url"
                  placeholder="https://shopee.com.br/seuusuario"
                  value={storeUrl}
                  onChange={(e) => setStoreUrl(e.target.value)}
                  className="flex-1"
                />
                <Button 
                  onClick={analyzeStoreByUrl} 
                  disabled={isAnalyzing || !storeUrl}
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analisando...
                    </>
                  ) : (
                    <>
                      <ArrowRight className="w-4 h-4 mr-2" />
                      Analisar
                    </>
                  )}
                </Button>
              </div>
              {analyzeError && (
                <p className="text-sm text-red-500">{analyzeError}</p>
              )}
            </div>
          </div>
        </CardContent>
        <CardFooter className="bg-muted/50">
          <p className="text-sm text-muted-foreground">
            A análise pode levar alguns minutos para ser concluída, dependendo do tamanho da loja e do número de produtos.
          </p>
        </CardFooter>
      </Card>
      
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid grid-cols-3 w-full max-w-md mx-auto">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="products">Produtos</TabsTrigger>
          <TabsTrigger value="competition">Concorrência</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <DataSourceWrapper source={DataSourceType.SCRAPING}>
              <Card className="h-full">
                <CardHeader>
                  <CardTitle className="text-lg font-semibold font-poppins">Score de Saúde da Loja</CardTitle>
                  <CardDescription>Pontuação geral e métricas principais</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col items-center">
                  <RadialProgress 
                    value={analyticsData.storeScore} 
                    color="hsl(var(--primary))"
                    size="12rem"
                    className="mb-8" 
                  />
                  
                  <div className="w-full">
                    <h3 className="text-sm font-semibold mb-3">Pontuação por dimensão</h3>
                    <div className="space-y-4">
                      {dimensionalScores.map((score, index) => (
                        <div key={index} className="relative pt-1">
                          <div className="flex items-center justify-between mb-1">
                            <div className="text-xs font-medium text-gray-700">{score.name}</div>
                            <div className="text-xs font-medium text-gray-700">{score.value}/100</div>
                          </div>
                          <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                            <div 
                              style={{ 
                                width: `${score.value}%`,
                                backgroundColor: score.fill
                              }} 
                              className="rounded"
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </DataSourceWrapper>
            
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="text-lg font-semibold font-poppins">Métricas de Desempenho</CardTitle>
                <CardDescription>Dados históricos e tendências</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-primary-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-500">Taxa de Conversão</div>
                    <div className="flex items-baseline mt-1">
                      <div className="text-2xl font-bold text-primary-600">2.7%</div>
                      <div className="ml-2 text-xs text-green-600 flex items-center">
                        <ArrowUp className="h-3 w-3 mr-1" />
                        0.3%
                      </div>
                    </div>
                  </div>
                  <div className="bg-secondary-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-500">Visualizações Mensais</div>
                    <div className="flex items-baseline mt-1">
                      <div className="text-2xl font-bold text-secondary-600">1,254</div>
                      <div className="ml-2 text-xs text-green-600 flex items-center">
                        <ArrowUp className="h-3 w-3 mr-1" />
                        12%
                      </div>
                    </div>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-500">Avaliação Média</div>
                    <div className="flex items-baseline mt-1">
                      <div className="text-2xl font-bold text-purple-600">4.7</div>
                      <div className="ml-2 text-xs text-gray-600 flex items-center">
                        <Minus className="h-3 w-3 mr-1" />
                        0%
                      </div>
                    </div>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-500">Taxa de Resposta</div>
                    <div className="flex items-baseline mt-1">
                      <div className="text-2xl font-bold text-green-600">92%</div>
                      <div className="ml-2 text-xs text-red-600 flex items-center">
                        <ArrowDown className="h-3 w-3 mr-1" />
                        3%
                      </div>
                    </div>
                  </div>
                </div>
                
                <h3 className="text-sm font-semibold mb-2">Tendências de Vendas (30 dias)</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={[
                        { day: "1", sales: 2 },
                        { day: "5", sales: 5 },
                        { day: "10", sales: 3 },
                        { day: "15", sales: 7 },
                        { day: "20", sales: 4 },
                        { day: "25", sales: 8 },
                        { day: "30", sales: 12 },
                      ]}
                      margin={{ top: 5, right: 20, left: 10, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="day" />
                      <YAxis />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="sales" 
                        stroke="hsl(var(--primary))" 
                        strokeWidth={2}
                        dot={{ r: 4 }}
                        activeDot={{ r: 6 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold font-poppins">Fontes de Tráfego</CardTitle>
                <CardDescription>De onde vêm seus visitantes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={trafficSourceData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {trafficSourceData.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={index === 0 
                              ? "hsl(var(--primary))" 
                              : index === 1 
                                ? "hsl(var(--secondary))" 
                                : index === 2 
                                  ? "hsl(var(--success))" 
                                  : "hsl(var(--purple))"}
                          />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend layout="vertical" verticalAlign="middle" align="right" />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold font-poppins">Ações Recomendadas</CardTitle>
                <CardDescription>Prioridades baseadas na análise</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  {(analyticsData.analytics.priorityActions || []).map((action: string, index: number) => (
                    <li key={index} className="flex items-start">
                      <div className="mt-0.5 w-6 h-6 flex-shrink-0 rounded-full bg-primary-500 text-white flex items-center justify-center">
                        <span className="text-xs font-bold">{index + 1}</span>
                      </div>
                      <div className="ml-3">
                        <p className="text-sm">{action}</p>
                        <div className="mt-1 flex items-center">
                          <div className={`text-xs px-2 py-0.5 rounded-full ${
                            index === 0 
                              ? 'bg-red-50 text-red-700' 
                              : index === 1 
                                ? 'bg-yellow-50 text-yellow-700'
                                : 'bg-blue-50 text-blue-700'
                          }`}>
                            {index === 0 
                              ? 'Crítica' 
                              : index === 1 
                                ? 'Alta' 
                                : 'Média'}
                          </div>
                          <a 
                            href="#" 
                            className="ml-3 text-xs font-medium text-primary-500 hover:text-primary-700"
                          >
                            Ver detalhes
                          </a>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="products">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold font-poppins">Desempenho dos Produtos</CardTitle>
                <CardDescription>Comparação de visualizações e vendas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={productPerformance}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis yAxisId="left" orientation="left" />
                      <YAxis yAxisId="right" orientation="right" />
                      <Tooltip />
                      <Legend />
                      <Bar yAxisId="left" dataKey="views" name="Visualizações" fill="hsl(var(--primary))" />
                      <Bar yAxisId="right" dataKey="sales" name="Vendas" fill="hsl(var(--secondary))" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold font-poppins">Taxa de Conversão por Produto</CardTitle>
                <CardDescription>Percentual de visualizações que resultam em vendas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={productPerformance}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      layout="vertical"
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" domain={[0, 20]} />
                      <YAxis dataKey="name" type="category" />
                      <Tooltip formatter={(value) => [`${value}%`, 'Taxa de Conversão']} />
                      <Legend />
                      <Bar dataKey="conversion" name="Taxa de Conversão (%)" fill="hsl(var(--success))" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold font-poppins">Análise Detalhada de Produtos</CardTitle>
                <CardDescription>Métricas e oportunidades de otimização</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-gray-50 border-b">
                        <th className="px-4 py-3 text-left">Produto</th>
                        <th className="px-4 py-3 text-center">Visualizações</th>
                        <th className="px-4 py-3 text-center">Vendas</th>
                        <th className="px-4 py-3 text-center">Conversão</th>
                        <th className="px-4 py-3 text-center">Ranking</th>
                        <th className="px-4 py-3 text-center">Score</th>
                        <th className="px-4 py-3 text-center">Status</th>
                        <th className="px-4 py-3 text-right">Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      {productPerformance.map((product, index) => (
                        <tr key={index} className="border-b">
                          <td className="px-4 py-3 font-medium">{product.name}</td>
                          <td className="px-4 py-3 text-center">{product.views}</td>
                          <td className="px-4 py-3 text-center">{product.sales}</td>
                          <td className="px-4 py-3 text-center">{product.conversion}%</td>
                          <td className="px-4 py-3 text-center">#{Math.floor(Math.random() * 20) + 5}</td>
                          <td className="px-4 py-3 text-center">
                            <div className="flex items-center justify-center">
                              <div 
                                className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs"
                                style={{ 
                                  backgroundColor: product.conversion > 15 
                                    ? "hsl(var(--success))" 
                                    : product.conversion > 10 
                                      ? "hsl(var(--primary))" 
                                      : "hsl(var(--destructive))" 
                                }}
                              >
                                {Math.floor(product.conversion * 5)}
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              product.conversion > 15 
                                ? 'bg-green-50 text-green-700' 
                                : product.conversion > 10 
                                  ? 'bg-blue-50 text-blue-700'
                                  : 'bg-red-50 text-red-700'
                            }`}>
                              {product.conversion > 15 
                                ? 'Bom' 
                                : product.conversion > 10 
                                  ? 'Médio' 
                                  : 'Melhorar'}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right">
                            <a 
                              href="#" 
                              className="text-primary-500 hover:text-primary-700 font-medium"
                            >
                              Otimizar
                            </a>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="competition">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold font-poppins">Comparação de Mercado</CardTitle>
                <CardDescription>Seu desempenho versus concorrentes diretos</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={competitorData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="score" name="Score de Saúde" fill="#8884d8">
                        {competitorData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold font-poppins">Análise de Preços</CardTitle>
                <CardDescription>Comparação de preços com o mercado</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-semibold mb-2">Posicionamento de Preço</h3>
                    <div className="relative h-8 bg-gray-200 rounded-full overflow-hidden">
                      <div className="absolute h-full w-full flex items-center">
                        <div className="w-1 h-4 bg-black z-10 absolute" style={{ left: '25%' }}></div>
                        <div className="w-1 h-4 bg-black z-10 absolute" style={{ left: '50%' }}></div>
                        <div className="w-1 h-4 bg-black z-10 absolute" style={{ left: '75%' }}></div>
                      </div>
                      <div className="absolute top-0 bottom-0 left-0 w-2/3 bg-gradient-to-r from-green-500 via-yellow-500 to-red-500"></div>
                      <div className="absolute top-0 bottom-0 h-full" style={{ left: '45%' }}>
                        <div className="w-6 h-6 -mt-3 -ml-3 rounded-full bg-white border-2 border-primary-500"></div>
                      </div>
                    </div>
                    <div className="flex justify-between text-xs mt-1">
                      <span>Mais barato</span>
                      <span>Média do mercado</span>
                      <span>Mais caro</span>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-semibold mb-3">Análise por Produto</h3>
                    <div className="space-y-4">
                      <div className="flex items-center">
                        <div className="w-32 text-sm">Produto A</div>
                        <div className="flex-1 h-6 bg-gray-200 rounded-full overflow-hidden relative">
                          <div className="absolute inset-0 flex items-center">
                            <div className="h-full w-1/2 bg-primary-500 rounded-l-full"></div>
                            <div className="h-4 w-4 rounded-full bg-white border-2 border-primary-500"></div>
                            <div className="ml-2 text-xs font-medium">5% abaixo da média</div>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <div className="w-32 text-sm">Produto B</div>
                        <div className="flex-1 h-6 bg-gray-200 rounded-full overflow-hidden relative">
                          <div className="absolute inset-0 flex items-center">
                            <div className="h-full w-3/4 bg-secondary-500 rounded-l-full"></div>
                            <div className="h-4 w-4 rounded-full bg-white border-2 border-secondary-500"></div>
                            <div className="ml-2 text-xs font-medium">15% acima da média</div>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <div className="w-32 text-sm">Produto C</div>
                        <div className="flex-1 h-6 bg-gray-200 rounded-full overflow-hidden relative">
                          <div className="absolute inset-0 flex items-center">
                            <div className="h-full w-2/3 bg-green-500 rounded-l-full"></div>
                            <div className="h-4 w-4 rounded-full bg-white border-2 border-green-500"></div>
                            <div className="ml-2 text-xs font-medium">Na média</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold font-poppins">Recomendações Competitivas</CardTitle>
                <CardDescription>Estratégias para se destacar da concorrência</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="bg-primary-50 rounded-lg p-5">
                    <h3 className="font-semibold text-primary-700 mb-2">Listagem de Produtos</h3>
                    <ul className="text-sm space-y-2">
                      <li className="flex items-start">
                        <span className="text-primary-500 mr-2">•</span>
                        <span>Adicione mais imagens de alta qualidade (mínimo 6)</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary-500 mr-2">•</span>
                        <span>Use todos os campos de especificação disponíveis</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary-500 mr-2">•</span>
                        <span>Melhore seus títulos com palavras-chave mais relevantes</span>
                      </li>
                    </ul>
                  </div>
                  
                  <div className="bg-secondary-50 rounded-lg p-5">
                    <h3 className="font-semibold text-secondary-700 mb-2">Estratégia de Preços</h3>
                    <ul className="text-sm space-y-2">
                      <li className="flex items-start">
                        <span className="text-secondary-500 mr-2">•</span>
                        <span>Ofereça bundles com desconto progressivo</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-secondary-500 mr-2">•</span>
                        <span>Implemente promoções relâmpago semanais</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-secondary-500 mr-2">•</span>
                        <span>Considere frete grátis para pedidos acima de R$150</span>
                      </li>
                    </ul>
                  </div>
                  
                  <div className="bg-purple-50 rounded-lg p-5">
                    <h3 className="font-semibold text-purple-700 mb-2">Atendimento ao Cliente</h3>
                    <ul className="text-sm space-y-2">
                      <li className="flex items-start">
                        <span className="text-purple-500 mr-2">•</span>
                        <span>Responda perguntas em até 12 horas (ideal: 4 horas)</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-purple-500 mr-2">•</span>
                        <span>Responda a todas as avaliações negativas</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-purple-500 mr-2">•</span>
                        <span>Crie modelos de resposta para perguntas frequentes</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </>
  );
}
