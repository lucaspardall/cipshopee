import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Alert, 
  AlertDescription, 
  AlertTitle 
} from '@/components/ui/alert';
import { 
  ShoppingBag, 
  Link as LinkIcon, 
  Check, 
  AlertTriangle, 
  RefreshCw,
  Loader2
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

// Interface para o status da conexão com a Shopee
interface ShopeeConnectionStatus {
  connected: boolean;
  hasValidToken?: boolean;
  shopId?: string;
  connectedAt?: string;
  shopUrl?: string | null;
}

export default function ShopeeIntegrationPage() {
  const { isAuthenticated, user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [authorizing, setAuthorizing] = useState(false);

  // Buscar o status da conexão com a Shopee
  const { data: connectionStatus, isLoading } = useQuery<ShopeeConnectionStatus>({
    queryKey: ['/api/shopee/status'],
    enabled: isAuthenticated,
    refetchInterval: 60000, // Atualiza a cada minuto
  });

  // Mutation para desconectar da Shopee
  const disconnectMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/shopee/disconnect');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Desconectado com sucesso',
        description: 'Sua loja Shopee foi desconectada.',
        variant: 'default',
      });
      // Invalidar a consulta para atualizar o status
      queryClient.invalidateQueries({ queryKey: ['/api/shopee/status'] });
    },
    onError: (error: any) => {
      toast({
        title: 'Erro ao desconectar',
        description: error.message || 'Não foi possível desconectar da Shopee.',
        variant: 'destructive',
      });
    },
  });

  // Iniciar o processo de autorização
  const startAuthorization = async () => {
    try {
      setAuthorizing(true);
      const response = await fetch('/api/shopee/authorize');
      const data = await response.json();
      
      if (data.success && data.authorizationUrl) {
        // Redirecionar para a URL de autorização da Shopee
        window.location.href = data.authorizationUrl;
      } else {
        throw new Error(data.message || 'Erro ao gerar URL de autorização');
      }
    } catch (error: any) {
      toast({
        title: 'Erro na Conexão',
        description: error.message || 'Não foi possível iniciar a conexão com a Shopee.',
        variant: 'destructive',
      });
    } finally {
      setAuthorizing(false);
    }
  };

  // Handler para desconectar
  const handleDisconnect = () => {
    if (window.confirm('Tem certeza que deseja desconectar sua loja Shopee? Isso removerá todas as integrações.')) {
      disconnectMutation.mutate();
    }
  };

  // Redirecionar para login se não estiver autenticado
  useEffect(() => {
    if (!isAuthenticated && !isLoading) {
      setLocation('/login?redirect=/integrations/shopee');
    }
  }, [isAuthenticated, isLoading, setLocation]);
  
  // Se não estiver autenticado, não renderiza o conteúdo
  if (!isAuthenticated || isLoading) {
    return (
      <div className="container mx-auto py-8">
        <Card>
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl flex items-center">
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Carregando...
            </CardTitle>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Integração com Shopee</h1>
      
      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <ShoppingBag className="mr-2 h-5 w-5 text-orange-500" />
              Status da Integração
            </CardTitle>
            <CardDescription>
              Conecte sua loja Shopee para sincronizar dados e otimizar seus produtos automaticamente.
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center p-4">
                <Loader2 className="h-6 w-6 animate-spin mr-2" />
                <span>Verificando conexão...</span>
              </div>
            ) : connectionStatus?.connected ? (
              <div className="space-y-4">
                <Alert className="bg-green-50 border-green-200">
                  <Check className="h-4 w-4 text-green-600" />
                  <AlertTitle>Loja Conectada</AlertTitle>
                  <AlertDescription>
                    Sua loja Shopee (ID: {connectionStatus.shopId}) está conectada.
                    {connectionStatus.connectedAt && (
                      <div className="text-sm text-gray-500 mt-1">
                        Conectada em: {new Date(connectionStatus.connectedAt).toLocaleString('pt-BR')}
                      </div>
                    )}
                  </AlertDescription>
                </Alert>
                
                {connectionStatus.hasValidToken === false && (
                  <Alert className="bg-amber-50 border-amber-200">
                    <AlertTriangle className="h-4 w-4 text-amber-600" />
                    <AlertTitle>Token Expirado</AlertTitle>
                    <AlertDescription>
                      Seu token de acesso expirou. Por favor, reconecte sua loja para continuar usando as integrações.
                    </AlertDescription>
                  </Alert>
                )}
                
                {connectionStatus.shopUrl && (
                  <div className="flex items-center text-sm text-gray-600">
                    <LinkIcon className="h-4 w-4 mr-1" />
                    <a 
                      href={connectionStatus.shopUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      Visitar loja na Shopee
                    </a>
                  </div>
                )}
              </div>
            ) : (
              <Alert className="bg-gray-50 border-gray-200">
                <AlertTitle>Loja não conectada</AlertTitle>
                <AlertDescription>
                  Você ainda não conectou sua loja Shopee. Clique no botão abaixo para iniciar o processo de integração.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
          
          <CardFooter className="flex justify-end space-x-2">
            {connectionStatus?.connected ? (
              <>
                {connectionStatus.hasValidToken === false && (
                  <Button 
                    variant="outline" 
                    onClick={startAuthorization}
                    disabled={authorizing}
                  >
                    {authorizing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Reconectando...
                      </>
                    ) : (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4" /> 
                        Reconectar
                      </>
                    )}
                  </Button>
                )}
                <Button 
                  variant="destructive" 
                  onClick={handleDisconnect}
                  disabled={disconnectMutation.isPending}
                >
                  {disconnectMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Desconectando...
                    </>
                  ) : (
                    'Desconectar Loja'
                  )}
                </Button>
              </>
            ) : (
              <Button 
                onClick={startAuthorization}
                disabled={authorizing}
                className="bg-orange-500 hover:bg-orange-600"
              >
                {authorizing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Iniciando Conexão...
                  </>
                ) : (
                  <>
                    <ShoppingBag className="mr-2 h-4 w-4" />
                    Conectar Loja Shopee
                  </>
                )}
              </Button>
            )}
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Como Funciona</CardTitle>
            <CardDescription>
              A integração com a Shopee permite o acesso direto a dados e operações de sua loja através da API oficial.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="text-lg font-medium mb-2">Processo de Autorização</h3>
              <ol className="list-decimal ml-5 space-y-2">
                <li>Clique no botão "Conectar Loja Shopee" acima</li>
                <li>Você será redirecionado para a página de autorização da Shopee</li>
                <li>Faça login na sua conta de vendedor Shopee</li>
                <li>Autorize nosso aplicativo a acessar sua loja</li>
                <li>Você será redirecionado de volta para nossa plataforma automaticamente</li>
              </ol>
            </div>
            
            <div>
              <h3 className="text-lg font-medium mb-2">Benefícios</h3>
              <ul className="list-disc ml-5 space-y-1">
                <li>Obtenha insights sobre o desempenho de seus produtos</li>
                <li>Otimize listagens de produtos com AI</li>
                <li>Sincronize e atualize produtos automaticamente</li>
                <li>Monitore métricas e desempenho de vendas</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}