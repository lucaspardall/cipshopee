import { useState } from "react";
import PageHeader from "@/components/ui/page-header";
import { ManualForm } from "@/components/optimize/manual-form";
import { OptimizationResultView } from "@/components/optimize/optimization-result";
import { OptimizationResult } from "@/types";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

export default function OptimizeListing() {
  const [optimizationResult, setOptimizationResult] = useState<OptimizationResult | null>(null);

  const handleOptimization = (result: OptimizationResult) => {
    setOptimizationResult(result);
    
    // Rolar para os resultados
    setTimeout(() => {
      const resultElement = document.getElementById('optimization-result');
      if (resultElement) {
        resultElement.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <>
      <PageHeader 
        title="Otimizador de Anúncios" 
        description="Melhore seus anúncios existentes na Shopee com conteúdo otimizado para maior visibilidade e conversão."
      />
      
      <div className="grid grid-cols-1 gap-6 mb-8">
        <Alert className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Novidade!</AlertTitle>
          <AlertDescription>
            Agora você pode inserir manualmente os dados do produto para otimização,
            evitando problemas com o scraping automático.
          </AlertDescription>
        </Alert>
        
        <ManualForm onOptimize={handleOptimization} />
        
        {optimizationResult && (
          <div id="optimization-result" className="pt-4">
            <OptimizationResultView result={optimizationResult} />
          </div>
        )}
      </div>
    </>
  );
}
