import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, CheckCircle, Pause, Play, RefreshCw, Trash2 } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import PageHeader from "@/components/ui/page-header";
import { Textarea } from "@/components/ui/textarea";

// Define o schema para validação do formulário
const agentFormSchema = z.object({
  storeUrl: z.string().url("URL da loja inválida").min(1, "URL da loja é obrigatória"),
  scanFrequency: z.enum(["daily", "weekly", "monthly"], {
    required_error: "Selecione a frequência de escaneamento",
  }),
  notificationEnabled: z.boolean().default(true),
  optimizationTargets: z.array(z.string()).min(1, "Selecione pelo menos um alvo de otimização"),
  useCustomAssistant: z.boolean().default(false),
  openaiAssistantId: z.string().optional(),
});

type AgentFormValues = z.infer<typeof agentFormSchema>;

// Componente principal
export default function AgentConfig() {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Redireciona se não estiver autenticado
  if (!authLoading && !isAuthenticated) {
    setLocation("/login");
    return null;
  }

  // Busca a configuração atual do agente
  const { data: agentConfig, isLoading, error } = useQuery({
    queryKey: ["/api/agent/config"],
    retry: false,
  });

  // Define ações para o agente
  const createAgent = useMutation({
    mutationFn: async (values: AgentFormValues) => {
      return await apiRequest("POST", "/api/agent/create", values);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/agent/config"] });
      toast({
        title: "Agente criado com sucesso",
        description: "Seu agente de automação foi configurado e está pronto para ser usado.",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Erro ao criar agente",
        description: error.message || "Ocorreu um erro ao criar o agente automatizado.",
      });
    },
  });

  const updateAgent = useMutation({
    mutationFn: async (values: { id: number; data: Partial<AgentFormValues> }) => {
      return await apiRequest("PUT", `/api/agent/update/${values.id}`, values.data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/agent/config"] });
      toast({
        title: "Agente atualizado com sucesso",
        description: "As configurações do agente foram atualizadas.",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Erro ao atualizar agente",
        description: error.message || "Ocorreu um erro ao atualizar o agente automatizado.",
      });
    },
  });

  const executeAgent = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("POST", `/api/agent/execute/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/agent/config"] });
      toast({
        title: "Agente executado com sucesso",
        description: "O agente está processando sua loja. Os resultados estarão disponíveis em breve.",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Erro ao executar agente",
        description: error.message || "Ocorreu um erro ao executar o agente automatizado.",
      });
    },
  });

  const pauseAgent = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("POST", `/api/agent/pause/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/agent/config"] });
      toast({
        title: "Agente pausado",
        description: "O agente foi pausado e não executará automaticamente.",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Erro ao pausar agente",
        description: error.message || "Ocorreu um erro ao pausar o agente automatizado.",
      });
    },
  });

  const resumeAgent = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("POST", `/api/agent/resume/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/agent/config"] });
      toast({
        title: "Agente reativado",
        description: "O agente foi reativado e executará conforme o agendamento.",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Erro ao reativar agente",
        description: error.message || "Ocorreu um erro ao reativar o agente automatizado.",
      });
    },
  });

  const deleteAgent = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/agent/delete/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/agent/config"] });
      toast({
        title: "Agente excluído",
        description: "O agente foi excluído com sucesso.",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Erro ao excluir agente",
        description: error.message || "Ocorreu um erro ao excluir o agente automatizado.",
      });
    },
  });

  // Formulário para criar/atualizar agente
  const form = useForm<AgentFormValues>({
    resolver: zodResolver(agentFormSchema),
    defaultValues: {
      storeUrl: agentConfig?.storeUrl || "",
      scanFrequency: agentConfig?.scanFrequency || "daily",
      notificationEnabled: agentConfig?.notificationEnabled ?? true,
      optimizationTargets: agentConfig?.optimizationTargets || ["title", "description", "price"],
      useCustomAssistant: agentConfig?.useCustomAssistant ?? false,
      openaiAssistantId: agentConfig?.openaiAssistantId || "",
    },
  });

  const optimizationOptions = [
    { id: "title", label: "Títulos" },
    { id: "description", label: "Descrições" },
    { id: "price", label: "Preços" },
    { id: "keywords", label: "Palavras-chave" },
  ];

  function onSubmit(values: AgentFormValues) {
    if (agentConfig) {
      updateAgent.mutate({ id: agentConfig.id, data: values });
    } else {
      createAgent.mutate(values);
    }
  }

  // Renderização com base no estado atual
  if (isLoading) {
    return (
      <div className="container mx-auto py-10">
        <PageHeader title="Agente Automatizado" description="Configure e gerencie seu agente automatizado" />
        <div className="flex items-center justify-center p-12">
          <p>Carregando configurações do agente...</p>
        </div>
      </div>
    );
  }

  // Se ocorrer um erro 404, significa que não há agente configurado
  const hasNoAgent = error && (error as any).status === 404;

  return (
    <div className="container mx-auto py-10">
      <PageHeader title="Agente Automatizado" description="Configure e gerencie seu agente automatizado" />

      {!hasNoAgent && agentConfig && (
        <div className="mb-8">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Status do Agente</CardTitle>
                <AgentStatusBadge status={agentConfig.status} />
              </div>
              <CardDescription>
                Agente configurado em {new Date(agentConfig.createdAt).toLocaleDateString()}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-medium mb-1">URL da Loja</h4>
                    <p className="text-sm text-muted-foreground">{agentConfig.storeUrl || "Não configurado"}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium mb-1">Frequência</h4>
                    <p className="text-sm text-muted-foreground capitalize">{agentConfig.scanFrequency}</p>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-1">Última Execução</h4>
                  <p className="text-sm text-muted-foreground">
                    {agentConfig.lastRun 
                      ? new Date(agentConfig.lastRun).toLocaleString() 
                      : "Nunca executado"}
                  </p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-1">Próxima Execução</h4>
                  <p className="text-sm text-muted-foreground">
                    {agentConfig.nextScheduledRun 
                      ? new Date(agentConfig.nextScheduledRun).toLocaleString() 
                      : "Não agendado"}
                  </p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-1">Alvos de Otimização</h4>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {agentConfig.optimizationTargets && agentConfig.optimizationTargets.map((target) => (
                      <Badge key={target} variant="outline">
                        {optimizationOptions.find(opt => opt.id === target)?.label || target}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <div className="flex flex-wrap gap-2">
                <Button 
                  onClick={() => executeAgent.mutate(agentConfig.id)}
                  disabled={executeAgent.isPending}
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Executar Agora
                </Button>
                
                {agentConfig.status === "paused" ? (
                  <Button 
                    variant="outline" 
                    onClick={() => resumeAgent.mutate(agentConfig.id)}
                    disabled={resumeAgent.isPending}
                  >
                    <Play className="mr-2 h-4 w-4" />
                    Reativar
                  </Button>
                ) : (
                  <Button 
                    variant="outline" 
                    onClick={() => pauseAgent.mutate(agentConfig.id)}
                    disabled={pauseAgent.isPending}
                  >
                    <Pause className="mr-2 h-4 w-4" />
                    Pausar
                  </Button>
                )}
                
                <Button 
                  variant="destructive" 
                  onClick={() => {
                    if (window.confirm("Tem certeza que deseja excluir este agente?")) {
                      deleteAgent.mutate(agentConfig.id);
                    }
                  }}
                  disabled={deleteAgent.isPending}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Excluir
                </Button>
              </div>
            </CardFooter>
          </Card>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>{hasNoAgent ? "Criar Agente Automatizado" : "Atualizar Configurações"}</CardTitle>
          <CardDescription>
            Configure um agente para analisar e otimizar automaticamente seus produtos na Shopee.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="storeUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>URL da Loja Shopee</FormLabel>
                    <FormControl>
                      <Input placeholder="https://shopee.com.br/loja_exemplo" {...field} />
                    </FormControl>
                    <FormDescription>
                      Informe a URL completa da sua loja na Shopee.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="scanFrequency"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Frequência de Escaneamento</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione a frequência" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="daily">Diariamente</SelectItem>
                        <SelectItem value="weekly">Semanalmente</SelectItem>
                        <SelectItem value="monthly">Mensalmente</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Com que frequência o agente deve analisar sua loja.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="optimizationTargets"
                render={() => (
                  <FormItem>
                    <div className="mb-4">
                      <FormLabel>Alvos de Otimização</FormLabel>
                      <FormDescription>
                        Selecione quais aspectos dos seus produtos o agente deve otimizar.
                      </FormDescription>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {optimizationOptions.map((option) => (
                        <FormField
                          key={option.id}
                          control={form.control}
                          name="optimizationTargets"
                          render={({ field }) => {
                            return (
                              <FormItem
                                key={option.id}
                                className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4"
                              >
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(option.id)}
                                    onCheckedChange={(checked) => {
                                      return checked
                                        ? field.onChange([...field.value, option.id])
                                        : field.onChange(
                                            field.value?.filter(
                                              (value) => value !== option.id
                                            )
                                          )
                                    }}
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <FormLabel className="text-sm font-normal">
                                    {option.label}
                                  </FormLabel>
                                </div>
                              </FormItem>
                            )
                          }}
                        />
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="notificationEnabled"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">
                        Notificações
                      </FormLabel>
                      <FormDescription>
                        Receber notificações quando o agente encontrar oportunidades de melhoria.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <Separator className="my-6" />
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium">Configuração Avançada - Assistente OpenAI</h3>
                  <p className="text-sm text-muted-foreground">
                    Use seu próprio assistente personalizado da OpenAI para análise especializada de produtos Shopee.
                  </p>
                </div>
                
                <FormField
                  control={form.control}
                  name="useCustomAssistant"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">
                          Usar Assistente Personalizado
                        </FormLabel>
                        <FormDescription>
                          Utilize seu próprio assistente OpenAI com conhecimento especializado sobre a Shopee.
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                {form.watch("useCustomAssistant") && (
                  <FormField
                    control={form.control}
                    name="openaiAssistantId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>ID do Assistente OpenAI</FormLabel>
                        <FormControl>
                          <Input placeholder="asst_abc123..." {...field} />
                        </FormControl>
                        <FormDescription>
                          Informe o ID do seu assistente personalizado da OpenAI que possui conhecimento especializado sobre a Shopee.
                          Você pode encontrar este ID no dashboard da OpenAI.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </div>

              <Button 
                type="submit" 
                className="w-full mt-6" 
                disabled={form.formState.isSubmitting || createAgent.isPending || updateAgent.isPending}
              >
                {hasNoAgent ? "Criar Agente" : "Atualizar Configurações"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {process.env.NODE_ENV === "development" && !hasNoAgent && agentConfig?.n8nWorkflowId && (
        <div className="mt-8">
          <Alert variant="info">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Informação de Desenvolvimento</AlertTitle>
            <AlertDescription>
              ID do Workflow no n8n: {agentConfig.n8nWorkflowId}
            </AlertDescription>
          </Alert>
        </div>
      )}
    </div>
  );
}

// Componente para exibir status do agente
function AgentStatusBadge({ status }: { status: string }) {
  let variant: "default" | "outline" | "destructive" = "outline";
  let icon = null;

  switch (status) {
    case "active":
      variant = "default";
      icon = <CheckCircle className="h-4 w-4 mr-1" />;
      break;
    case "paused":
      variant = "outline";
      icon = <Pause className="h-4 w-4 mr-1" />;
      break;
    case "error":
      variant = "destructive";
      icon = <AlertCircle className="h-4 w-4 mr-1" />;
      break;
  }

  return (
    <Badge variant={variant} className="flex items-center">
      {icon}
      <span className="capitalize">{status}</span>
    </Badge>
  );
}