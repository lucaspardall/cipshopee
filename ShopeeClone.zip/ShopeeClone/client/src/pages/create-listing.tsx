import { useState } from "react";
import PageHeader from "@/components/ui/page-header";
import { ProductForm } from "@/components/create/product-form";
import { ListingPreview } from "@/components/create/listing-preview";
import { ListingGenerationResult } from "@/types";

export default function CreateListing() {
  const [listingResult, setListingResult] = useState<ListingGenerationResult | null>(null);

  const handleGeneration = (result: ListingGenerationResult) => {
    setListingResult(result);
  };

  return (
    <>
      <PageHeader 
        title="Criador de Anúncios" 
        description="Crie anúncios completos para Shopee em segundos com nossa IA avançada."
      />
      
      <div className="grid grid-cols-1 gap-6">
        <ProductForm onGenerate={handleGeneration} />
        
        {listingResult && (
          <ListingPreview result={listingResult} />
        )}
      </div>
    </>
  );
}
