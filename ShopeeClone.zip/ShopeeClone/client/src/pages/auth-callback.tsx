import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function AuthCallback() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    // Verificar parâmetros na URL
    const urlParams = new URLSearchParams(window.location.search);
    const error = urlParams.get('error');
    const success = urlParams.get('success');
    
    if (error) {
      toast({
        title: 'Erro na autenticação',
        description: 'Não foi possível completar o login. Por favor, tente novamente.',
        variant: 'destructive',
      });
      setLocation('/login');
      return;
    }

    // Verificamos a sessão usando o endpoint de verificação de sessão
    // e redirecionamos para o dashboard diretamente
    const checkAuthAndRedirect = async () => {
      try {
        console.log("Verificando autenticação em auth-callback...");
        
        // Verificar a sessão primeiro com o endpoint simplificado
        const sessionResponse = await fetch('/api/auth/session-check');
        const sessionData = await sessionResponse.json();
        
        if (sessionData.authenticated) {
          console.log("Sessão válida encontrada:", sessionData);
          
          toast({
            title: 'Login realizado com sucesso!',
            description: 'Bem-vindo(a) de volta!',
          });
          
          // Redirecionamento direto para o dashboard
          console.log("Redirecionando para dashboard...");
          window.location.href = '/dashboard';
          return;
        }
        
        // Se não encontramos uma sessão válida, tentamos o endpoint de usuário 
        const userResponse = await fetch('/api/auth/user');
        
        if (userResponse.ok) {
          // Autenticação bem-sucedida via usuário
          const user = await userResponse.json();
          console.log("Usuário autenticado encontrado:", user);
          
          toast({
            title: 'Login realizado com sucesso!',
            description: `Bem-vindo(a) de volta, ${user.name || user.username || 'usuário'}!`,
          });
          
          // Redirecionamento direto
          window.location.href = '/dashboard';
        } else {
          // Verificamos se é login de teste
          const urlParams = new URLSearchParams(window.location.search);
          if (urlParams.get('source') === 'test') {
            console.log("Login de teste detectado, tentando forçar acesso...");
            
            toast({
              title: 'Login de teste',
              description: 'Tentando acesso com usuário de teste',
            });
            
            // Em login de teste, redirecionamos diretamente após curto delay
            setTimeout(() => {
              window.location.href = '/dashboard';
            }, 1000);
            return;
          }
          
          // Se tudo falhou até agora, esperamos um pouco e tentamos novamente
          console.log("Sessão não encontrada. Tentando novamente em 1s...");
          setTimeout(() => {
            window.location.reload(); // Recarregar a página para tentar novamente
          }, 1000);
        }
      } catch (error) {
        console.error('Erro ao verificar autenticação:', error);
        toast({
          title: 'Erro ao verificar autenticação',
          description: 'Ocorreu um erro. Tente fazer login novamente.',
          variant: 'destructive',
        });
        setTimeout(() => {
          window.location.href = '/login';
        }, 1000);
      }
    };
    
    // Iniciamos a verificação de autenticação
    checkAuthAndRedirect();
  }, [setLocation, toast]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50">
      <div className="text-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
        <h1 className="text-2xl font-semibold mb-2">Autenticando...</h1>
        <p className="text-gray-600">Você será redirecionado em instantes.</p>
      </div>
    </div>
  );
}