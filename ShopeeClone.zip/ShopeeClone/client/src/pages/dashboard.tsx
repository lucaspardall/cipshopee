import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { DataSourceAlert } from "@/components/dashboard/data-source-alert";
import { StoreHealthScore } from "@/components/dashboard/store-health-score";
import { KeyMetrics } from "@/components/dashboard/key-metrics";
import { RecommendedActions } from "@/components/dashboard/recommended-actions";
import { ProductPerformance } from "@/components/dashboard/product-performance";
import { SalesChart } from "@/components/dashboard/sales-chart";
import { ImportantAlerts } from "@/components/dashboard/important-alerts";
import { UpcomingEvents } from "@/components/dashboard/upcoming-events";
import { OptimizationTools } from "@/components/dashboard/optimization-tools";
import { NewsSection } from "@/components/dashboard/news-section";
import PageHeader from "@/components/ui/page-header";
import { DataSourceType } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { 
  MetricItem, 
  ActionItem, 
  ProductItem, 
  Alert, 
  UpcomingEvent, 
  OptimizationTool,
  NewsItem
} from "@/types";
import { Loader2 } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();

  // Fetch store analytics data
  const { data: analyticsData, isLoading: isLoadingAnalytics } = useQuery({
    queryKey: ["/api/store-analytics"],
    enabled: !!user,
  });

  // Fetch upcoming events 
  const { data: upcomingEventsData, isLoading: isLoadingEvents } = useQuery({
    queryKey: ["/api/upcoming-events"],
    enabled: !!user,
  });

  // Fetch latest news
  const { data: latestNewsData, isLoading: isLoadingNews } = useQuery({
    queryKey: ["/api/latest-news"],
    enabled: !!user,
  });

  // Fetch products
  const { data: productsData, isLoading: isLoadingProducts } = useQuery({
    queryKey: ["/api/products"],
    enabled: !!user,
  });

  const [storeHealthItems, setStoreHealthItems] = useState<any[]>([]);
  const [metrics, setMetrics] = useState<MetricItem[]>([]);
  const [actions, setActions] = useState<ActionItem[]>([]);
  const [products, setProducts] = useState<ProductItem[]>([]);
  const [salesData, setSalesData] = useState<any[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [events, setEvents] = useState<UpcomingEvent[]>([]);

  // Convert API events data to component format
  useEffect(() => {
    if (upcomingEventsData) {
      const formattedEvents = upcomingEventsData.map((event: any) => {
        const date = new Date(event.startDate);
        const month = date.toLocaleString('pt-BR', { month: 'short' }).toUpperCase();
        const day = date.getDate().toString();
        
        return {
          id: event.id,
          month,
          day,
          title: event.title,
          description: event.description || "",
          priority: event.priority || "MEDIUM",
          actionLink: `/events/${event.id}`,
        };
      });
      
      setEvents(formattedEvents);
    }
  }, [upcomingEventsData]);

  // Process analytics data when it loads
  useEffect(() => {
    if (analyticsData) {
      // Set store health items
      const scores = [
        { 
          color: analyticsData.analytics.listingQualityScore > 80 ? "#22c55e" : analyticsData.analytics.listingQualityScore > 60 ? "#eab308" : "#ef4444", 
          label: "Listings", 
          value: analyticsData.analytics.listingQualityScore, 
          max: 100 
        },
        { 
          color: analyticsData.analytics.priceCompetitivenessScore > 80 ? "#22c55e" : analyticsData.analytics.priceCompetitivenessScore > 60 ? "#eab308" : "#ef4444", 
          label: "Preços", 
          value: analyticsData.analytics.priceCompetitivenessScore, 
          max: 100 
        },
        { 
          color: analyticsData.analytics.marketingEffectivenessScore > 80 ? "#22c55e" : analyticsData.analytics.marketingEffectivenessScore > 60 ? "#eab308" : "#ef4444", 
          label: "Marketing", 
          value: analyticsData.analytics.marketingEffectivenessScore, 
          max: 100 
        },
        { 
          color: analyticsData.analytics.customerSatisfactionScore > 80 ? "#22c55e" : analyticsData.analytics.customerSatisfactionScore > 60 ? "#eab308" : "#ef4444", 
          label: "Sat. Cliente", 
          value: analyticsData.analytics.customerSatisfactionScore, 
          max: 100 
        },
      ];
      setStoreHealthItems(scores);

      // Set metrics based on metricsData
      if (analyticsData.analytics.metricsData) {
        const metricItems: MetricItem[] = [
          {
            label: "Taxa de Conversão",
            value: `${analyticsData.analytics.metricsData.conversion}%`,
            change: 0.3,
            direction: "up"
          },
          {
            label: "Tráfego Mensal",
            value: analyticsData.analytics.metricsData.traffic.toLocaleString(),
            change: 12,
            direction: "up"
          },
          {
            label: "Avaliação Média",
            value: `${analyticsData.analytics.metricsData.rating}/5.0`,
            change: 0,
            direction: "neutral"
          },
          {
            label: "Posição Média",
            value: `#${analyticsData.analytics.metricsData.avgPosition}`,
            change: 3,
            direction: "down"
          }
        ];
        setMetrics(metricItems);
      }

      // Set actions based on priorityActions
      if (analyticsData.analytics.priorityActions) {
        const actionItems: ActionItem[] = analyticsData.analytics.priorityActions.map((action: string, index: number) => {
          const icons = ["magic", "star", "comment-dots", "tags"];
          const links = ["/optimize-listing", "/events", "/manage-listings", "/analyze-store"];
          const actionTexts = ["Otimizar agora", "Ver detalhes", "Responder", "Ver sugestões"];
          
          return {
            icon: icons[index % icons.length],
            text: action,
            actionLink: links[index % links.length],
            actionText: actionTexts[index % actionTexts.length]
          };
        });
        setActions(actionItems);
      }

      // Set alerts
      setAlerts([
        {
          type: "error",
          title: "Responda avaliação negativa",
          description: "Um cliente deixou uma avaliação de 2 estrelas para o produto \"Fone Bluetooth TWS\" há 2 dias.",
          action: "Responder agora",
          actionLink: "/reviews"
        },
        {
          type: "warning",
          title: "Estoque baixo",
          description: "O produto \"Capa Premium iPhone 13\" está com apenas 3 unidades em estoque.",
          action: "Gerenciar estoque",
          actionLink: "/inventory"
        },
        {
          type: "info",
          title: "Oportunidade de voucher",
          description: "Você está elegível para criar um voucher de desconto com 10% de cashback da Shopee.",
          action: "Criar voucher",
          actionLink: "/vouchers"
        }
      ]);

      // Generate example sales data
      const lastWeek = Array.from({ length: 7 }, (_, i) => {
        const date = new Date();
        date.setDate(date.getDate() - (6 - i));
        return {
          date: date.toLocaleDateString('pt-BR', { weekday: 'short' }),
          value: Math.floor(Math.random() * 50) + 30
        };
      });
      setSalesData(lastWeek);
    }
  }, [analyticsData]);

  // Process products data when it loads
  useEffect(() => {
    if (productsData) {
      const formattedProducts: ProductItem[] = productsData.slice(0, 3).map((product: any, index: number) => {
        const imageUrls = [
          "https://images.unsplash.com/photo-1606041011872-596597976b25?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=70&h=70",
          "https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=70&h=70",
          "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=70&h=70"
        ];
        
        return {
          id: product.id,
          title: product.title,
          image: imageUrls[index % imageUrls.length],
          price: product.price || 99.99,
          views: product.views || 0,
          sales: product.sales || 0,
          rating: product.rating || 4.7
        };
      });
      
      // If we have less than 3 products, fill with sample data
      if (formattedProducts.length < 3) {
        const sampleProducts = [
          {
            id: -1,
            title: "Capa Premium iPhone 13 - Resistente a Impactos",
            image: "https://images.unsplash.com/photo-1606041011872-596597976b25?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=70&h=70",
            price: 59.90,
            views: 258,
            sales: 42,
            rating: 4.8
          },
          {
            id: -2,
            title: "Fone Bluetooth TWS - Som Premium e Bateria 40h",
            image: "https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=70&h=70",
            price: 129.90,
            views: 195,
            sales: 27,
            rating: 4.5
          },
          {
            id: -3,
            title: "Smartwatch X3 Pro - Monitor Cardíaco e Esportes",
            image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=70&h=70",
            price: 249.90,
            views: 145,
            sales: 18,
            rating: 4.7
          }
        ];
        
        const neededSamples = 3 - formattedProducts.length;
        setProducts([...formattedProducts, ...sampleProducts.slice(0, neededSamples)]);
      } else {
        setProducts(formattedProducts);
      }
    }
  }, [productsData]);

  // Process news data
  const [news, setNews] = useState<NewsItem[]>([]);
  useEffect(() => {
    if (latestNewsData) {
      const formattedNews = latestNewsData.map((item: any) => {
        return {
          id: item.id,
          title: item.title,
          description: item.content,
          date: new Date(item.publishDate).toLocaleDateString('pt-BR', { 
            day: 'numeric', 
            month: 'long', 
            year: 'numeric' 
          }),
          imageUrl: item.imageUrl || "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=200",
          link: item.url || `/news/${item.id}`
        };
      });
      setNews(formattedNews);
    }
  }, [latestNewsData]);

  // Optimization tools data
  const optimizationTools: OptimizationTool[] = [
    {
      id: "optimize",
      title: "Otimizador de Anúncios",
      description: "Melhore seus anúncios existentes com conteúdo otimizado para SEO e conversão.",
      icon: "magic",
      color: "#1a3a8f",
      link: "/optimize-listing",
      buttonText: "Otimizar Anúncio"
    },
    {
      id: "create",
      title: "Criador de Anúncios",
      description: "Crie anúncios completos e otimizados em segundos para novos produtos.",
      icon: "plus-circle",
      color: "#ff6b35",
      link: "/create-listing",
      buttonText: "Criar Anúncio"
    },
    {
      id: "analyze",
      title: "Analisador da Loja",
      description: "Análise profunda da sua loja com recomendações de melhoria personalizadas.",
      icon: "search-dollar",
      color: "#6247aa",
      link: "/analyze-store",
      buttonText: "Analisar Loja"
    }
  ];

  const isLoading = isLoadingAnalytics || isLoadingEvents || isLoadingNews || isLoadingProducts;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-12 w-12 animate-spin text-primary-500" />
        <span className="ml-2 text-xl font-medium text-primary-500">Carregando dashboard...</span>
      </div>
    );
  }

  return (
    <>
      <PageHeader 
        title="Dashboard Principal" 
        description={`Bem-vindo(a) de volta, ${user?.name || 'Vendedor'}! Veja como sua loja está hoje.`} 
      />
      
      <DataSourceAlert />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <StoreHealthScore 
          score={analyticsData?.storeScore || 78} 
          items={storeHealthItems}
          dataSource={DataSourceType.SCRAPING}
        />
        
        <KeyMetrics 
          metrics={metrics} 
          dataSource={DataSourceType.SCRAPING} 
        />
        
        <RecommendedActions actions={actions} />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <ProductPerformance 
          products={products} 
          dataSource={DataSourceType.SCRAPING} 
        />
        
        <SalesChart 
          title="Vendas nos Últimos 7 Dias" 
          data={salesData} 
          changePercentage={24} 
          dataSource={DataSourceType.SCRAPING} 
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <ImportantAlerts alerts={alerts} />
        <UpcomingEvents events={events} />
      </div>
      
      <OptimizationTools tools={optimizationTools} />
      
      <div className="mt-6">
        <NewsSection news={news} />
      </div>
    </>
  );
}
