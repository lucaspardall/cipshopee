import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

const registerSchema = z.object({
  username: z.string().min(3, {
    message: "Nome de usuário deve ter no mínimo 3 caracteres",
  }),
  email: z.string().email({
    message: "Email inválido",
  }),
  name: z.string().min(2, {
    message: "Nome deve ter no mínimo 2 caracteres",
  }),
  password: z.string().min(6, {
    message: "Senha deve ter no mínimo 6 caracteres",
  }),
  confirmPassword: z.string().min(6, {
    message: "Confirme sua senha",
  }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "As senhas não coincidem",
  path: ["confirmPassword"],
});

type RegisterFormValues = z.infer<typeof registerSchema>;

export default function Register() {
  const [isLoading, setIsLoading] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Gerar um nome de usuário aleatório para evitar conflitos
  const randomUsername = `user_${Math.floor(Math.random() * 10000)}`;

  const form = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: randomUsername,
      email: `${randomUsername}@example.com`,
      name: "Usuário Teste",
      password: "password123",
      confirmPassword: "password123",
    },
  });

  async function onSubmit(values: RegisterFormValues) {
    setIsLoading(true);

    const { confirmPassword, ...registerData } = values;

    try {
      await apiRequest("POST", "/api/auth/register", registerData);
      
      toast({
        title: "Registro realizado com sucesso!",
        description: "Você foi registrado com sucesso, redirecionando para o login...",
      });
      
      setTimeout(() => {
        setLocation("/login");
      }, 1500);
    } catch (error) {
      console.error("Registration error:", error);
      toast({
        title: "Erro no registro",
        description: "Ocorreu um erro ao tentar registrar. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-gray-50 p-4">
      <div className="bg-white rounded-xl shadow-md p-8 w-full max-w-md">
        <div className="flex justify-center mb-6">
          <div className="flex items-center">
            <div className="w-10 h-10 flex items-center justify-center bg-primary-500 text-white rounded-lg font-bold text-lg font-poppins">
              CIP
            </div>
            <h1 className="ml-2 text-xl font-semibold text-primary-500 font-poppins">
              Centro de<br/>Inteligência
            </h1>
          </div>
        </div>
        
        <h2 className="text-2xl font-bold text-center mb-6 font-poppins">Criar Conta</h2>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome de usuário</FormLabel>
                  <FormControl>
                    <Input placeholder="seunome" {...field} disabled={isLoading} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome completo</FormLabel>
                  <FormControl>
                    <Input placeholder="Seu Nome Completo" {...field} disabled={isLoading} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input placeholder="seu@email.com" {...field} disabled={isLoading} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Senha</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="******" {...field} disabled={isLoading} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="confirmPassword"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Confirmar senha</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="******" {...field} disabled={isLoading} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Registrando...
                </>
              ) : (
                "Criar conta"
              )}
            </Button>
          </form>
        </Form>
        
        <div className="mt-6 text-center text-sm">
          <span className="text-gray-600">Já tem uma conta?</span>{" "}
          <Link href="/login" className="text-primary-500 hover:text-primary-600 font-medium">
            Entrar
          </Link>
        </div>
      </div>
    </div>
  );
}
