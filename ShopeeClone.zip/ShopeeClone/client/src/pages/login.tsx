import { useState, useEffect } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { Separator } from "@/components/ui/separator";

const loginSchema = z.object({
  username: z.string().min(1, {
    message: "Nome de usuário é obrigatório",
  }),
  password: z.string().min(1, {
    message: "Senha é obrigatória",
  }),
  rememberMe: z.boolean().optional(),
});

type LoginFormValues = z.infer<typeof loginSchema>;

export default function Login() {
  const [isLoading, setIsLoading] = useState(false);
  const [googleAuthAvailable, setGoogleAuthAvailable] = useState(false);
  const [isDev, setIsDev] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Verificar se a autenticação com Google está disponível e se é ambiente dev
  useEffect(() => {
    async function checkGoogleAuth() {
      try {
        // Primeiro, vamos verificar se há muitos cookies no ambiente
        // Que possam estar causando conflitos
        const cookies = document.cookie;
        console.log("Cookies atuais:", cookies);
        
        // Se detectarmos múltiplos cookies de sessão, sugerir limpar antes de tentar login
        if (cookies.includes('connect.sid') && cookies.includes('cip-shopee.sid')) {
          console.log("Detectados múltiplos cookies de sessão, pode causar problemas de autenticação");
          const urlParams = new URLSearchParams(window.location.search);
          
          // Só limpar automaticamente se não estivermos voltando da limpeza
          if (!urlParams.has('cleaned')) {
            toast({
              title: "Limpando cookies",
              description: "Detectamos múltiplos cookies que podem causar problemas. Limpando...",
            });
            
            // Limpar cookies automaticamente
            fetch('/api/auth/limpar-cookies')
              .then(res => res.json())
              .then(data => {
                console.log("Resposta da limpeza automática:", data);
                if (data.success) {
                  // Redirecionar para a página de login com parâmetro de limpeza
                  window.location.href = '/login?cleaned=true';
                }
              })
              .catch(err => {
                console.error("Erro ao limpar cookies:", err);
              });
            return; // Interromper o resto da função
          }
        }
        
        const response = await fetch('/api/auth/google-status');
        const data = await response.json();
        setGoogleAuthAvailable(data.available === true);
        
        // Verificar se é ambiente de desenvolvimento
        // No ambiente de produção, NODE_ENV será definido como 'production'
        // Como estamos no Replit, podemos assumir que sempre estamos em modo de desenvolvimento
        // Se precisarmos detectar mais precisamente, podemos adicionar uma rota API para isso
        setIsDev(true);
      } catch (error) {
        console.error('Erro ao verificar status da autenticação Google:', error);
        setGoogleAuthAvailable(false);
      }
    }
    
    checkGoogleAuth();
  }, [toast]);

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
      rememberMe: false,
    },
  });

  async function onSubmit(values: LoginFormValues) {
    setIsLoading(true);

    try {
      await apiRequest("POST", "/api/auth/login", {
        username: values.username,
        password: values.password,
      });
      
      toast({
        title: "Login realizado com sucesso!",
        description: "Bem-vindo(a) de volta!",
      });
      
      setLocation("/dashboard");
    } catch (error) {
      console.error("Login error:", error);
      toast({
        title: "Erro no login",
        description: "Credenciais inválidas. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-gray-50 p-4">
      <div className="bg-white rounded-xl shadow-md p-8 w-full max-w-md">
        <div className="flex justify-center mb-6">
          <div className="flex items-center">
            <div className="w-10 h-10 flex items-center justify-center bg-primary-500 text-white rounded-lg font-bold text-lg font-poppins">
              CIP
            </div>
            <h1 className="ml-2 text-xl font-semibold text-primary-500 font-poppins">
              Centro de<br/>Inteligência
            </h1>
          </div>
        </div>
        
        <h2 className="text-2xl font-bold text-center mb-6 font-poppins">Entrar</h2>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome de usuário</FormLabel>
                  <FormControl>
                    <Input placeholder="seunome" {...field} disabled={isLoading} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Senha</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="******" {...field} disabled={isLoading} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="flex items-center justify-between">
              <FormField
                control={form.control}
                name="rememberMe"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        disabled={isLoading}
                      />
                    </FormControl>
                    <FormLabel className="text-sm font-normal">Lembrar-me</FormLabel>
                  </FormItem>
                )}
              />
              
              <Link href="/forgot-password" className="text-sm text-primary-500 hover:text-primary-600">
                Esqueceu a senha?
              </Link>
            </div>
            
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Entrando...
                </>
              ) : (
                "Entrar"
              )}
            </Button>
            
            {googleAuthAvailable && (
              <>
                <div className="relative my-4">
                  <div className="absolute inset-0 flex items-center">
                    <Separator className="w-full" />
                  </div>
                  <div className="relative flex justify-center">
                    <span className="bg-white px-2 text-xs text-gray-500">ou continue com</span>
                  </div>
                </div>
                
                <Button 
                  type="button"
                  variant="outline"
                  className="w-full flex items-center justify-center gap-2"
                  onClick={() => {
                    console.log("Iniciando autenticação com Google...");
                    toast({
                      title: "Redirecionando para o Google",
                      description: "Você será redirecionado para fazer login com sua conta Google."
                    });
                    // Pequeno atraso para mostrar o toast antes de redirecionar
                    setTimeout(() => {
                      window.location.href = "/api/auth/google";
                    }, 1000);
                  }}
                >
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18.1712 8.36791H17.5V8.33333H10V11.6667H14.6096C13.955 13.6071 12.1525 15 10 15C7.23875 15 5 12.7613 5 10C5 7.23875 7.23875 5 10 5C11.2746 5 12.4342 5.48625 13.3154 6.28458L15.6763 3.92375C14.1596 2.51625 12.1846 1.66667 10 1.66667C5.39792 1.66667 1.66667 5.39792 1.66667 10C1.66667 14.6021 5.39792 18.3333 10 18.3333C14.6021 18.3333 18.3333 14.6021 18.3333 10C18.3333 9.44125 18.2758 8.89583 18.1712 8.36791Z" fill="#FFC107"/>
                    <path d="M2.62708 6.12125L5.36625 8.12917C6.10958 6.29500 7.90042 5 10 5C11.2746 5 12.4342 5.48625 13.3154 6.28458L15.6763 3.92375C14.1596 2.51625 12.1846 1.66667 10 1.66667C6.83958 1.66667 4.11208 3.48708 2.62708 6.12125Z" fill="#FF3D00"/>
                    <path d="M10 18.3333C12.1538 18.3333 14.1029 17.5096 15.6088 16.1354L13.0467 13.9842C12.2288 14.6183 11.1542 15 10 15C7.8575 15 5.99917 13.6183 5.33583 11.6908L2.61583 13.7829C4.07667 16.4817 6.83292 18.3333 10 18.3333Z" fill="#4CAF50"/>
                    <path d="M18.1712 8.36791H17.5V8.33333H10V11.6667H14.6096C14.2971 12.5902 13.7188 13.3972 12.9613 13.9829L12.9633 13.9817L15.5254 16.1329C15.3396 16.3021 18.3333 14.1667 18.3333 10C18.3333 9.44125 18.2758 8.89583 18.1712 8.36791Z" fill="#1976D2"/>
                  </svg>
                  <span>Entrar com Google</span>
                </Button>
              </>
            )}
            
            {/* Botão de Login de Teste (apenas em desenvolvimento) */}
            {isDev && (
              <div className="mt-4">
                <div className="relative my-2">
                  <div className="absolute inset-0 flex items-center">
                    <Separator className="w-full" />
                  </div>
                  <div className="relative flex justify-center">
                    <span className="bg-white px-2 text-xs text-gray-500">testes</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  {/* Login Direto com ID 1 */}
                  <Button 
                    type="button"
                    variant="outline"
                    className="w-full flex items-center justify-center gap-2 bg-amber-50 border border-amber-300 text-amber-700 hover:bg-amber-100"
                    onClick={() => {
                      console.log("Iniciando login direto com ID 1...");
                      toast({
                        title: "Login de teste",
                        description: "Entrando com usuário de teste (ID: 1)..."
                      });
                      // Usar o novo endpoint de login direto
                      fetch('/api/auth/login-direto/1')
                        .then(res => res.json())
                        .then(data => {
                          console.log("Resposta do login direto:", data);
                          if (data.success) {
                            // Redirecionar para o dashboard
                            window.location.href = data.redirectTo || '/dashboard';
                          } else {
                            throw new Error(data.message || 'Erro no login direto');
                          }
                        })
                        .catch(error => {
                          console.error("Erro no login direto:", error);
                          toast({
                            title: "Erro no login",
                            description: "Não foi possível fazer login com o usuário de teste.",
                            variant: "destructive"
                          });
                        });
                    }}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-bug">
                      <path d="M8 2h8"></path>
                      <path d="M12 2v6"></path>
                      <path d="M5 8h14"></path>
                      <path d="M18 14c0 4-6 4-6 4s-6 0-6-4"></path>
                      <path d="M4 8v7a5 5 0 0 0 5 5h6a5 5 0 0 0 5-5V8"></path>
                      <path d="M6 14c0-2 1.8-4 6-4s6 2 6 4"></path>
                    </svg>
                    <span>Login Direto (Usuário ID: 1)</span>
                  </Button>
                  
                  {/* Botão para limpar cookies */}
                  <Button 
                    type="button"
                    variant="outline"
                    className="w-full flex items-center justify-center gap-2 bg-blue-50 border border-blue-300 text-blue-700 hover:bg-blue-100"
                    onClick={() => {
                      console.log("Limpando cookies...");
                      toast({
                        title: "Limpando cookies",
                        description: "Removendo cookies de sessão para resolver problemas..."
                      });
                      // Usar o endpoint de limpeza de cookies
                      fetch('/api/auth/limpar-cookies')
                        .then(res => res.json())
                        .then(data => {
                          console.log("Resposta da limpeza de cookies:", data);
                          if (data.success) {
                            toast({
                              title: "Cookies limpos",
                              description: "Cookies de sessão foram removidos com sucesso."
                            });
                            // Recarregar a página após limpar os cookies
                            setTimeout(() => {
                              window.location.reload();
                            }, 1000);
                          }
                        })
                        .catch(error => {
                          console.error("Erro ao limpar cookies:", error);
                          toast({
                            title: "Erro",
                            description: "Não foi possível limpar os cookies.",
                            variant: "destructive"
                          });
                        });
                    }}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-trash-2">
                      <path d="M3 6h18"></path>
                      <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path>
                      <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path>
                      <line x1="10" x2="10" y1="11" y2="17"></line>
                      <line x1="14" x2="14" y1="11" y2="17"></line>
                    </svg>
                    <span>Limpar Cookies</span>
                  </Button>
                </div>
              </div>
            )}
          </form>
        </Form>
        
        <div className="mt-6 text-center text-sm">
          <span className="text-gray-600">Não tem uma conta?</span>{" "}
          <Link href="/register" className="text-primary-500 hover:text-primary-600 font-medium">
            Criar conta
          </Link>
        </div>
      </div>
    </div>
  );
}
