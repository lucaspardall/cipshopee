import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import PageHeader from "@/components/ui/page-header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Product } from "@shared/schema";
import { Loader2, Edit, Plus, Trash2, BarChart2, Package, ShoppingBag } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { DataSourceWrapper } from "@/components/common/data-source-indicator";
import { DataSourceType } from "@shared/schema";

export default function ManageListings() {
  const { toast } = useToast();
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Fetch user's products
  const { data: products = [], isLoading, refetch } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    retry: false,
  });
  
  // Delete a product (would need to implement the DELETE endpoint on the backend)
  const handleDelete = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir este anúncio?")) return;
    
    try {
      await fetch(`/api/products/${id}`, {
        method: "DELETE",
      });
      
      toast({
        title: "Anúncio excluído",
        description: "O anúncio foi excluído com sucesso",
      });
      
      refetch();
    } catch (error) {
      toast({
        title: "Erro ao excluir",
        description: "Ocorreu um erro ao excluir o anúncio",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-12 w-12 animate-spin text-primary-500" />
        <span className="ml-2 text-xl font-medium text-primary-500">Carregando anúncios...</span>
      </div>
    );
  }

  return (
    <>
      <PageHeader 
        title="Gerenciar Anúncios" 
        description="Visualize e gerencie todos os seus anúncios da Shopee em um só lugar."
      />
      
      <div className="flex justify-between items-center mb-6">
        <div>
          <span className="text-sm text-gray-600">Total de anúncios: {products?.length || 0}</span>
        </div>
        <Link href="/create-listing">
          <Button className="flex items-center">
            <Plus className="mr-2 h-4 w-4" />
            Criar Novo Anúncio
          </Button>
        </Link>
      </div>
      
      {products?.length === 0 ? (
        <Card className="p-8 text-center">
          <div className="mb-4 text-gray-400">
            <BarChart2 className="h-12 w-12 mx-auto mb-2" />
            <h3 className="text-lg font-medium">Você ainda não tem anúncios</h3>
            <p className="text-sm text-gray-500 mb-4">Comece criando seu primeiro anúncio otimizado para Shopee.</p>
            <Link href="/create-listing">
              <Button>Criar meu primeiro anúncio</Button>
            </Link>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {products?.map((product: Product) => (
            <Card key={product.id} className="hover:border-primary-300 transition">
              <CardContent className="p-0">
                <div className="flex flex-col sm:flex-row p-4">
                  <div className="sm:w-16 sm:h-16 w-full h-32 mb-4 sm:mb-0 bg-gray-100 rounded overflow-hidden flex items-center justify-center">
                    {product.imageUrl ? (
                      <img 
                        src={product.imageUrl} 
                        alt={product.title} 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-primary-100 flex items-center justify-center text-primary-600">
                        <ShoppingBag className="h-8 w-8" />
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1 sm:ml-4">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-1 mb-1">
                      <h3 className="text-lg font-medium line-clamp-1 max-w-[70%]">{product.title}</h3>
                      <div className="flex-shrink-0">
                        <DataSourceWrapper source={product.dataSource as DataSourceType || DataSourceType.SCRAPING}>
                          <span className="text-xs sm:text-sm whitespace-nowrap">
                            Criado em: {product.createdAt ? format(new Date(product.createdAt), 'dd/MM/yyyy') : 'N/A'}
                          </span>
                        </DataSourceWrapper>
                      </div>
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-2 line-clamp-2">{product.description}</p>
                    
                    <div className="flex justify-between flex-wrap gap-2">
                      <div className="space-x-1 sm:space-x-2 flex flex-wrap">
                        {product.category && (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            {product.category}
                          </span>
                        )}
                        
                        {product.keywords && product.keywords.slice(0, 3).map((keyword, index) => (
                          <span 
                            key={index}
                            className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
                          >
                            {keyword}
                          </span>
                        ))}
                      </div>
                      
                      <div className="text-lg font-medium">
                        {product.price ? `R$ ${product.price.toFixed(2)}` : 'Preço não definido'}
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="border-t border-gray-100 p-3 bg-gray-50 flex justify-end space-x-2">
                  {product.shopeeUrl && (
                    <a href={product.shopeeUrl} target="_blank" rel="noopener noreferrer">
                      <Button variant="outline" size="sm">
                        Ver na Shopee
                      </Button>
                    </a>
                  )}
                  
                  <Link href={`/optimize-listing?id=${product.id}`}>
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4 mr-1" />
                      Otimizar
                    </Button>
                  </Link>
                  
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    onClick={() => handleDelete(product.id)}
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Excluir
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </>
  );
}