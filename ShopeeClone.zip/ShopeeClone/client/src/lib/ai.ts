import { apiRequest } from "@/lib/queryClient";

// Function to optimize an existing listing using the configured Shopee assistant
export async function optimizeProduct(productUrl: string) {
  try {
    const res = await apiRequest("POST", "/api/optimize", { 
      productUrl
    });
    return await res.json();
  } catch (error) {
    console.error("Error optimizing product:", error);
    throw error;
  }
}

// Function to create a new listing
export async function createNewListing(productInfo: string, shopeeUrl?: string) {
  try {
    const res = await apiRequest("POST", "/api/create-listing", { 
      productInfo,
      shopeeUrl: shopeeUrl && shopeeUrl.trim() ? shopeeUrl : undefined
    });
    return await res.json();
  } catch (error) {
    console.error("Error creating new listing:", error);
    throw error;
  }
}

// Function to get store analytics
export async function getStoreAnalytics() {
  try {
    const res = await apiRequest("GET", "/api/store-analytics");
    return await res.json();
  } catch (error) {
    console.error("Error getting store analytics:", error);
    throw error;
  }
}
