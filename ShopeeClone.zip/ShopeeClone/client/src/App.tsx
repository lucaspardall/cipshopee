import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { RootLayout } from "@/components/layout/root-layout";
import Home from "@/pages/home";
import Register from "@/pages/register";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import OptimizeListing from "@/pages/optimize-listing";
import CreateListing from "@/pages/create-listing";
import AnalyzeStore from "@/pages/analyze-store";
import AnalyzeAds from "@/pages/analyze-ads";
import News from "@/pages/news";
import ManageListings from "@/pages/manage-listings";
import AgentConfig from "@/pages/agent-config";
import Account from "@/pages/account";
import AssistantTester from "@/pages/assistant-tester";
import ShopeeIntegration from "@/pages/integrations/shopee";
import AuthCallback from "@/pages/auth-callback";
import { ProtectedRoute } from "@/components/auth/protected-route";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/register" component={Register} />
      <Route path="/login" component={Login} />
      <Route path="/auth-callback" component={AuthCallback} />
      <Route path="/dashboard">
        {() => (
          <ProtectedRoute>
            <RootLayout>
              <Dashboard />
            </RootLayout>
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/optimize-listing">
        {() => (
          <ProtectedRoute>
            <RootLayout>
              <OptimizeListing />
            </RootLayout>
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/create-listing">
        {() => (
          <ProtectedRoute>
            <RootLayout>
              <CreateListing />
            </RootLayout>
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/analyze-store">
        {() => (
          <ProtectedRoute>
            <RootLayout>
              <AnalyzeStore />
            </RootLayout>
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/news">
        {() => (
          <ProtectedRoute>
            <RootLayout>
              <News />
            </RootLayout>
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/manage-listings">
        {() => (
          <ProtectedRoute>
            <RootLayout>
              <ManageListings />
            </RootLayout>
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/agent-config">
        {() => (
          <ProtectedRoute>
            <RootLayout>
              <AgentConfig />
            </RootLayout>
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/analyze-ads">
        {() => (
          <ProtectedRoute>
            <RootLayout>
              <AnalyzeAds />
            </RootLayout>
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/account">
        {() => (
          <ProtectedRoute>
            <RootLayout>
              <Account />
            </RootLayout>
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/assistant-tester">
        {() => (
          <ProtectedRoute>
            <RootLayout>
              <AssistantTester />
            </RootLayout>
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/integrations/shopee">
        {() => (
          <ProtectedRoute>
            <RootLayout>
              <ShopeeIntegration />
            </RootLayout>
          </ProtectedRoute>
        )}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
