import { useQuery } from "@tanstack/react-query";
import { User } from "@/types";
import { useState, useEffect } from "react";

/**
 * Interface para armazenar dados do usuário localmente
 */
interface LocalStorageUser {
  userId: number;
  userName: string;
  email: string;
  authToken: string;
  timestamp: number;
}

/**
 * Verifica se há dados de autenticação no localStorage
 */
function getLocalAuth(): LocalStorageUser | null {
  try {
    const stored = localStorage.getItem('cip-auth');
    if (!stored) return null;
    
    const data = JSON.parse(stored) as LocalStorageUser;
    
    // Verificar validade (expira após 7 dias)
    const now = Date.now();
    const maxAge = 7 * 24 * 60 * 60 * 1000; // 7 dias
    
    if (now - data.timestamp > maxAge) {
      console.log('🔑 Dados de autenticação local expirados');
      localStorage.removeItem('cip-auth');
      return null;
    }
    
    return data;
  } catch (error) {
    console.error('🔑 Erro ao ler autenticação do localStorage:', error);
    return null;
  }
}

/**
 * Salva dados de autenticação no localStorage
 */
function saveLocalAuth(userId: number, userName: string, email: string, authToken: string) {
  try {
    const authData: LocalStorageUser = {
      userId,
      userName,
      email,
      authToken,
      timestamp: Date.now()
    };
    localStorage.setItem('cip-auth', JSON.stringify(authData));
    console.log('🔑 Dados de autenticação salvos localmente');
  } catch (error) {
    console.error('🔑 Erro ao salvar autenticação:', error);
  }
}

/**
 * Limpa dados de autenticação
 */
function clearAuth() {
  try {
    localStorage.removeItem('cip-auth');
    console.log('🔑 Dados de autenticação removidos localmente');
    
    // Tentar limpar cookies do servidor também
    fetch('/api/auth/limpar-cookies')
      .then(() => console.log('🔑 Cookies do servidor limpos'))
      .catch((err) => console.error('🔑 Erro ao limpar cookies do servidor:', err));
  } catch (error) {
    console.error('🔑 Erro ao limpar autenticação:', error);
  }
}

/**
 * Hook para gerenciar autenticação com redundância
 * Utiliza localStorage como principal mecanismo e
 * tenta sincronizar com servidor quando possível
 */
export function useAuth() {
  // Estado da autenticação
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [userId, setUserId] = useState<number | null>(null);
  const [userName, setUserName] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [usingLocalOnly, setUsingLocalOnly] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  
  // Efeito inicial para verificar autenticação local e do servidor
  useEffect(() => {
    async function checkAuth() {
      setIsLoading(true);
      
      // Primeiro verificar dados locais
      const localAuth = getLocalAuth();
      
      if (localAuth) {
        console.log('🔑 Dados de autenticação encontrados localmente:', localAuth.userId);
        setUserId(localAuth.userId);
        setUserName(localAuth.userName);
        setUserEmail(localAuth.email);
        setIsAuthenticated(true);
        
        // Tentar sincronizar com o servidor, mas não dependemos disso
        try {
          const loginRes = await fetch(`/api/auth/login-direto/${localAuth.userId}`);
          await loginRes.json();
          console.log('🔑 Sessão sincronizada com o servidor');
          setUsingLocalOnly(false);
        } catch (error) {
          console.warn('🔑 Não foi possível sincronizar com o servidor, usando autenticação local');
          setUsingLocalOnly(true);
        }
        
        setIsLoading(false);
        return;
      }
      
      // Se não tem dados locais, verificar com o servidor
      try {
        const res = await fetch('/api/auth/session-check');
        const data = await res.json();
        
        if (data.authenticated && data.userId) {
          console.log('🔑 Autenticado pelo servidor:', data.userId);
          setUserId(data.userId);
          setIsAuthenticated(true);
          setUsingLocalOnly(false);
          
          // Se temos dados do usuário do servidor, salvamos localmente para backup
          if (data.user) {
            setUserName(data.user.name || data.user.username);
            setUserEmail(data.user.email);
            
            saveLocalAuth(
              data.userId,
              data.user.name || data.user.username,
              data.user.email,
              `server_${Date.now()}`
            );
          }
        } else {
          console.log('🔑 Não autenticado pelo servidor');
          setIsAuthenticated(false);
          setUsingLocalOnly(false);
        }
      } catch (error) {
        console.error('🔑 Erro na verificação do servidor:', error);
        setIsAuthenticated(false);
        setUsingLocalOnly(false);
        setError(error instanceof Error ? error : new Error(String(error)));
      }
      
      setIsLoading(false);
    }
    
    checkAuth();
    
    // Configurar verificação periódica da sessão (a cada 30 segundos)
    const interval = setInterval(checkAuth, 30000);
    
    return () => {
      clearInterval(interval);
    };
  }, []);
  
  // Criar um usuário simplificado com base nos dados locais quando necessário
  const localUser: User | null = usingLocalOnly && userId ? {
    id: userId,
    username: userName || 'user',
    name: userName || 'Usuário',
    email: userEmail || '',
    createdAt: new Date(),
    shopeeApiEnabled: false,
    profileImageUrl: undefined
  } : null;
  
  // Verificar dados de usuário da API apenas se estivermos autenticados e não usando apenas localStorage
  const { 
    data: apiUser,
    isLoading: isUserLoading
  } = useQuery<User>({
    queryKey: ["/api/auth/user"],
    retry: 1,
    enabled: isAuthenticated && !usingLocalOnly,
    staleTime: 10000, // Considera dados frescos por 10 segundos
  });
  
  // Determinar o usuário final baseado na fonte disponível
  const user = apiUser || localUser;
  
  // Função para fazer login diretamente com ID
  const login = async (userId: number) => {
    setIsLoading(true);
    
    try {
      const res = await fetch(`/api/auth/login-direto/${userId}`);
      const data = await res.json();
      
      if (data.success) {
        setIsAuthenticated(true);
        setUserId(data.userId);
        setUserName(data.userName || '');
        setUserEmail(data.email || '');
        setUsingLocalOnly(false);
        
        // Salvar dados no localStorage para redundância
        saveLocalAuth(
          data.userId,
          data.userName || 'Usuário',
          data.email || '',
          data.authToken || `login_${Date.now()}`
        );
        
        console.log('🔑 Login bem-sucedido para usuário:', data.userId);
      } else {
        setError(new Error(data.message || 'Erro de login não especificado'));
        console.error('🔑 Erro no login:', data.message);
      }
    } catch (error) {
      setError(error instanceof Error ? error : new Error(String(error)));
      console.error('🔑 Erro na requisição de login:', error);
    }
    
    setIsLoading(false);
  };
  
  // Função para logout
  const logout = async () => {
    setIsLoading(true);
    
    // Limpar localStorage primeiro
    clearAuth();
    
    // Tentar deslogar do servidor
    try {
      await fetch('/api/auth/logout');
      console.log('🔑 Logout do servidor realizado');
    } catch (error) {
      console.error('🔑 Erro ao fazer logout do servidor:', error);
    }
    
    // Atualizar estado mesmo se o logout do servidor falhar
    setIsAuthenticated(false);
    setUserId(null);
    setUserName(null);
    setUserEmail(null);
    setUsingLocalOnly(false);
    
    setIsLoading(false);
    
    // Redirecionar para página de login
    window.location.href = '/login?logout=true';
  };
  
  return {
    user,
    userId,
    userName,
    userEmail,
    isAuthenticated, 
    isLoading: isLoading || (isAuthenticated && isUserLoading && !usingLocalOnly && !localUser),
    usingLocalOnly,
    error,
    login,
    logout
  };
}