import React from "react";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger 
} from "@/components/ui/tooltip";
import { Check, Lock, ChevronRight, Star } from "lucide-react";
import { User } from "@/types";

// Definir os estágios da jornada do vendedor
export interface JourneyStep {
  id: number;
  name: string;
  description: string;
  requirements: string[];
  progressPoints: number;
  unlocks: string[];
  requiredProducts?: number;
  requiredOptimizations?: number;
  requiredConnections?: string[];
}

// Journey steps para a jornada do vendedor
export const journeySteps: JourneyStep[] = [
  {
    id: 1,
    name: "Iniciante",
    description: "Primeiros passos na Shopee",
    requirements: ["Criar uma conta", "Completar perfil"],
    progressPoints: 0,
    unlocks: ["Acesso básico"],
  },
  {
    id: 2,
    name: "Aprendiz",
    description: "Comece a otimizar produtos",
    requirements: ["Otimize 1 produto", "Explore o dashboard"],
    progressPoints: 20,
    requiredOptimizations: 1,
    unlocks: ["Análise básica de produto"],
  },
  {
    id: 3,
    name: "Intermediário",
    description: "Expanda sua presença",
    requirements: ["Otimize 5 produtos", "Conecte a API Shopee"],
    progressPoints: 40,
    requiredOptimizations: 5,
    requiredConnections: ["shopee"],
    unlocks: ["Análise de concorrência"],
  },
  {
    id: 4,
    name: "Avançado",
    description: "Torne-se um profissional",
    requirements: ["Otimize 15 produtos", "Tenha análises completas"],
    progressPoints: 70,
    requiredOptimizations: 15,
    unlocks: ["Análises avançadas", "Sugestões personalizadas"],
  },
  {
    id: 5,
    name: "Expert",
    description: "Domínio da plataforma Shopee",
    requirements: ["Tenha 30+ produtos otimizados", "Integração completa da loja"],
    progressPoints: 90,
    requiredOptimizations: 30,
    unlocks: ["Recursos premium", "Análise competitiva"],
  }
];

export interface SellerJourneyProgressProps {
  user?: User;
  className?: string;
  compact?: boolean;
}

export function SellerJourneyProgress({ 
  user, 
  className = "", 
  compact = false 
}: SellerJourneyProgressProps) {
  // Se não houver usuário, mostrar versão genérica
  if (!user) {
    return (
      <div className={`p-5 bg-white rounded-lg shadow ${className}`}>
        <h3 className="font-medium text-lg mb-2">Jornada do Vendedor</h3>
        <p className="text-sm text-gray-500 mb-3">Faça login para acompanhar seu progresso</p>
        <Progress value={0} />
      </div>
    );
  }

  // Calcular a etapa atual com base nos dados do usuário
  const currentStep = user.sellerJourneyStep || 1;
  const progress = user.sellerJourneyProgress || 0;
  const tier = user.sellerJourneyTier || "novice";

  // Determinar próximos passos com base na jornada
  const currentJourneyStep = journeySteps.find(step => step.id === currentStep) || journeySteps[0];
  const nextJourneyStep = journeySteps.find(step => step.id === currentStep + 1);

  // Renderização da versão compacta para sidebar
  if (compact) {
    return (
      <div className={`p-3 rounded-lg bg-gradient-to-r from-primary-50 to-white ${className}`}>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-primary-700">Sua Jornada</h3>
          <Badge variant="outline" className="text-xs font-normal capitalize">
            {tier === "novice" ? "Novato" : 
             tier === "intermediate" ? "Intermediário" : 
             tier === "advanced" ? "Avançado" : "Expert"}
          </Badge>
        </div>
        
        <Progress value={progress} className="h-2 mb-2" />
        
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>Nível {currentStep}</span>
          <span>{progress}%</span>
        </div>
        
        {nextJourneyStep && (
          <div className="mt-2 flex items-center text-xs text-primary-600">
            <ChevronRight size={14} />
            <span>Próximo: {nextJourneyStep.name}</span>
          </div>
        )}
      </div>
    );
  }

  // Versão completa para exibição no dashboard
  return (
    <div className={`p-5 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700 ${className}`}>
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-medium text-lg">Jornada do Vendedor</h3>
        <Badge variant={tier === "novice" ? "outline" : "default"} className="capitalize">
          {tier === "novice" ? "Novato" : 
           tier === "intermediate" ? "Intermediário" : 
           tier === "advanced" ? "Avançado" : "Expert"}
        </Badge>
      </div>
      
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium">Nível {currentStep}: {currentJourneyStep.name}</span>
          <span className="text-sm text-gray-500">{progress}% Concluído</span>
        </div>
        <Progress value={progress} className="h-3" />
      </div>
      
      <div className="grid grid-cols-5 gap-2 mt-4">
        {journeySteps.map((step) => (
          <TooltipProvider key={step.id}>
            <Tooltip>
              <TooltipTrigger asChild>
                <div 
                  className={`flex flex-col items-center p-2 rounded-lg transition-all ${
                    step.id < currentStep 
                      ? "bg-primary-100 text-primary-700" 
                      : step.id === currentStep 
                        ? "bg-primary-600 text-white ring-2 ring-primary-300" 
                        : "bg-gray-100 text-gray-400"
                  }`}
                >
                  <div className="w-8 h-8 rounded-full flex items-center justify-center mb-1 bg-white bg-opacity-20">
                    {step.id < currentStep ? (
                      <Check size={16} />
                    ) : step.id > currentStep ? (
                      <Lock size={16} />
                    ) : (
                      <Star size={16} />
                    )}
                  </div>
                  <span className="text-xs font-medium">{step.name}</span>
                </div>
              </TooltipTrigger>
              <TooltipContent className="p-3 max-w-xs">
                <div>
                  <p className="font-medium mb-1">{step.name}</p>
                  <p className="text-xs mb-2">{step.description}</p>
                  <p className="text-xs font-medium mt-1">Requisitos:</p>
                  <ul className="text-xs list-disc list-inside">
                    {step.requirements.map((req, idx) => (
                      <li key={idx}>{req}</li>
                    ))}
                  </ul>
                  <p className="text-xs font-medium mt-1">Desbloqueia:</p>
                  <ul className="text-xs list-disc list-inside">
                    {step.unlocks.map((unlock, idx) => (
                      <li key={idx}>{unlock}</li>
                    ))}
                  </ul>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        ))}
      </div>
      
      {nextJourneyStep && (
        <div className="mt-6 bg-primary-50 dark:bg-primary-900/20 rounded-lg p-3 border border-primary-100 dark:border-primary-800/30">
          <h4 className="font-medium text-sm mb-2 flex items-center text-primary-700 dark:text-primary-400">
            <ChevronRight size={16} className="mr-1" />
            Próximo Nível: {nextJourneyStep.name}
          </h4>
          <ul className="text-xs space-y-1 text-gray-700 dark:text-gray-300">
            {nextJourneyStep.requirements.map((req, idx) => (
              <li key={idx} className="flex items-center">
                <div className="w-4 h-4 rounded-full border border-primary-200 dark:border-primary-700 flex items-center justify-center mr-2">
                  <div className="w-2 h-2 rounded-full bg-primary-400 dark:bg-primary-600"></div>
                </div>
                {req}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}