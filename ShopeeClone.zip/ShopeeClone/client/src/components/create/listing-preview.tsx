import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ListingGenerationResult } from "@/types";
import { DataSourceWrapper } from "@/components/common/data-source-indicator";
import { useToast } from "@/hooks/use-toast";

interface ListingPreviewProps {
  result: ListingGenerationResult;
}

export function ListingPreview({ result }: ListingPreviewProps) {
  const { product, generatedListing } = result;
  const [activeTab, setActiveTab] = useState("title");
  const { toast } = useToast();
  
  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copiado!",
      description: `${label} copiado para a área de transferência`,
      variant: "default",
    });
  };
  
  const copyAll = () => {
    const allContent = `
TÍTULO:
${generatedListing.title}

DESCRIÇÃO:
${generatedListing.description}

CATEGORIA:
${generatedListing.category}

VARIAÇÕES:
${JSON.stringify(generatedListing.variations, null, 2)}

ESPECIFICAÇÕES:
${JSON.stringify(generatedListing.specifications, null, 2)}

PREÇO SUGERIDO:
R$ ${generatedListing.suggestedPrice.toFixed(2).replace('.', ',')}

PALAVRAS-CHAVE:
${generatedListing.keywords.join(", ")}
    `.trim();
    
    copyToClipboard(allContent, "Anúncio completo");
  };
  
  return (
    <DataSourceWrapper source={product.dataSource || "SCRAPING"} className="mt-8">
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold font-poppins text-primary-800">
            Anúncio Completo Gerado
          </CardTitle>
          <p className="text-gray-600 text-sm">
            Seu anúncio está pronto! Revise, copie os elementos e cole diretamente na Shopee.
          </p>
        </CardHeader>
        
        <CardContent>
          <div className="bg-green-50 p-3 rounded-md mb-4">
            <div className="flex items-center">
              <div className="text-green-600 mr-2">
                <i className="fas fa-check-circle"></i>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-green-800">Anúncio Otimizado para Conversão</h3>
                <p className="text-xs text-green-700">
                  Todos os elementos foram criados com técnicas de copywriting e SEO para maximizar visibilidade e vendas.
                </p>
              </div>
            </div>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 md:grid-cols-6 mb-4 gap-1">
              <TabsTrigger value="title" className="text-xs md:text-sm">Título</TabsTrigger>
              <TabsTrigger value="description" className="text-xs md:text-sm">Descrição</TabsTrigger>
              <TabsTrigger value="variations" className="text-xs md:text-sm">Variações</TabsTrigger>
              <TabsTrigger value="specs" className="text-xs md:text-sm">Especific.</TabsTrigger>
              <TabsTrigger value="price" className="text-xs md:text-sm">Preço</TabsTrigger>
              <TabsTrigger value="keywords" className="text-xs md:text-sm">Keywords</TabsTrigger>
            </TabsList>
            
            <TabsContent value="title" className="border p-4 rounded-md min-h-[200px]">
              <div className="flex flex-wrap justify-between items-start mb-2 gap-2">
                <h3 className="text-sm font-semibold">Título Otimizado</h3>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="text-xs h-8"
                  onClick={() => copyToClipboard(generatedListing.title, "Título")}
                >
                  <i className="fas fa-copy mr-1"></i> Copiar
                </Button>
              </div>
              <p className="text-gray-800 border border-dashed border-gray-300 p-2 rounded">
                {generatedListing.title}
              </p>
              
              <div className="mt-4 text-sm text-gray-600">
                <h4 className="font-semibold">Por que este título funciona:</h4>
                <ul className="list-disc list-inside mt-1 space-y-1">
                  <li>Inclui palavras-chave relevantes para SEO</li>
                  <li>Destaca os principais benefícios do produto</li>
                  <li>Tem o comprimento ideal para visualização completa</li>
                  <li>Usa elementos chamativos (emoji, símbolos) com moderação</li>
                </ul>
              </div>
            </TabsContent>
            
            <TabsContent value="description" className="border p-4 rounded-md min-h-[200px]">
              <div className="flex flex-wrap justify-between items-start mb-2 gap-2">
                <h3 className="text-sm font-semibold">Descrição Completa</h3>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="text-xs h-8"
                  onClick={() => copyToClipboard(generatedListing.description, "Descrição")}
                >
                  <i className="fas fa-copy mr-1"></i> Copiar
                </Button>
              </div>
              <div className="text-gray-800 border border-dashed border-gray-300 p-2 rounded whitespace-pre-line h-[300px] overflow-y-auto">
                {generatedListing.description}
              </div>
              
              <div className="mt-4 text-sm text-gray-600">
                <h4 className="font-semibold">Elementos incluídos:</h4>
                <ul className="list-disc list-inside mt-1 space-y-1">
                  <li>Destaques principais com emojis para melhor visualização</li>
                  <li>Descrição detalhada dos benefícios</li>
                  <li>Especificações técnicas em formato de lista</li>
                  <li>Call-to-action para estimular a compra</li>
                </ul>
              </div>
            </TabsContent>
            
            <TabsContent value="variations" className="border p-4 rounded-md min-h-[200px]">
              <div className="flex flex-wrap justify-between items-start mb-2 gap-2">
                <h3 className="text-sm font-semibold">Variações do Produto</h3>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="text-xs h-8"
                  onClick={() => copyToClipboard(JSON.stringify(generatedListing.variations, null, 2), "Variações")}
                >
                  <i className="fas fa-copy mr-1"></i> Copiar
                </Button>
              </div>
              
              <div className="bg-gray-50 p-3 rounded border text-sm">
                <pre className="whitespace-pre-wrap">
                  {JSON.stringify(generatedListing.variations, null, 2)}
                </pre>
              </div>
              
              <div className="mt-4 text-sm text-gray-600">
                <p>
                  Configure estas variações no painel da Shopee para permitir que os clientes escolham entre diferentes opções do produto.
                </p>
              </div>
            </TabsContent>
            
            <TabsContent value="specs" className="border p-4 rounded-md min-h-[200px]">
              <div className="flex flex-wrap justify-between items-start mb-2 gap-2">
                <h3 className="text-sm font-semibold">Especificações Técnicas</h3>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="text-xs h-8"
                  onClick={() => copyToClipboard(JSON.stringify(generatedListing.specifications, null, 2), "Especificações")}
                >
                  <i className="fas fa-copy mr-1"></i> Copiar
                </Button>
              </div>
              
              <div className="bg-gray-50 p-3 rounded border">
                <table className="w-full text-sm">
                  <tbody>
                    {Object.entries(generatedListing.specifications).map(([key, value]) => (
                      <tr key={key} className="border-b border-gray-200 last:border-b-0">
                        <td className="py-2 font-medium">{key}</td>
                        <td className="py-2">{value as string}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="mt-4 text-sm text-gray-600">
                <p>
                  Adicione estas especificações nos campos apropriados para melhorar a classificação nos resultados de busca.
                </p>
              </div>
            </TabsContent>
            
            <TabsContent value="price" className="border p-4 rounded-md min-h-[200px]">
              <div className="flex flex-wrap justify-between items-start mb-2 gap-2">
                <h3 className="text-sm font-semibold">Sugestão de Preço</h3>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="text-xs h-8"
                  onClick={() => copyToClipboard(
                    `R$ ${generatedListing.suggestedPrice.toFixed(2).replace('.', ',')}`, 
                    "Preço sugerido"
                  )}
                >
                  <i className="fas fa-copy mr-1"></i> Copiar
                </Button>
              </div>
              
              <div className="flex items-center mb-6">
                <div className="text-xl font-bold text-primary-600">
                  R$ {generatedListing.suggestedPrice.toFixed(2).replace('.', ',')}
                </div>
              </div>
              
              <div className="text-sm text-gray-600">
                <h4 className="font-semibold">Análise de preço:</h4>
                <p className="mt-1">
                  Este preço foi sugerido com base em análise de mercado para produtos similares na Shopee. 
                  Está posicionado para equilibrar competitividade e margem de lucro adequada. 
                  Considere oferecer frete grátis ou descontos progressivos para compras múltiplas.
                </p>
              </div>
            </TabsContent>
            
            <TabsContent value="keywords" className="border p-4 rounded-md min-h-[200px]">
              <div className="flex flex-wrap justify-between items-start mb-2 gap-2">
                <h3 className="text-sm font-semibold">Palavras-chave Recomendadas</h3>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="text-xs h-8"
                  onClick={() => copyToClipboard(
                    generatedListing.keywords.join(", "), 
                    "Palavras-chave"
                  )}
                >
                  <i className="fas fa-copy mr-1"></i> Copiar
                </Button>
              </div>
              
              <div className="flex flex-wrap gap-2 my-4">
                {generatedListing.keywords.map((keyword, index) => (
                  <div key={index} className="bg-primary-50 text-primary-700 px-3 py-2 rounded-full text-xs border border-primary-100 shadow-sm">
                    {keyword}
                  </div>
                ))}
              </div>
              
              <div className="text-sm text-gray-600 mt-4">
                <p>
                  Utilize estas palavras-chave no título, descrição e campos de busca da Shopee para melhorar 
                  o SEO do seu anúncio e aumentar a visibilidade nos resultados de busca.
                </p>
              </div>
            </TabsContent>
          </Tabs>
          
          <div className="flex flex-wrap justify-center gap-3 mt-6">
            <Button 
              onClick={copyAll}
              className="text-sm px-4 py-2"
            >
              <i className="fas fa-copy mr-2"></i> Copiar Anúncio Completo
            </Button>
            <Button 
              variant="outline"
              className="text-sm px-4 py-2"
            >
              <i className="fas fa-save mr-2"></i> Salvar como Modelo
            </Button>
          </div>
        </CardContent>
      </Card>
    </DataSourceWrapper>
  );
}
