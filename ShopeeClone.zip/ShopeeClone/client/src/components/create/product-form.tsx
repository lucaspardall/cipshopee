import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FormEvent } from "react";
import { createNewListing } from "@/lib/ai";
import { LoaderCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ProductFormProps {
  onGenerate: (result: any) => void;
}

export function ProductForm({ onGenerate }: ProductFormProps) {
  const [productInfo, setProductInfo] = useState("");
  const [shopeeUrl, setShopeeUrl] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!productInfo.trim()) {
      toast({
        title: "Informação necessária",
        description: "Descreva o produto que deseja anunciar",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Passa a URL da Shopee se estiver disponível
      const result = await createNewListing(productInfo, shopeeUrl);
      onGenerate(result);
    } catch (error) {
      console.error("Error creating listing:", error);
      toast({
        title: "Erro na criação",
        description: "Ocorreu um erro ao criar o anúncio. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl font-bold font-poppins">Criador de Anúncios</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <p className="text-gray-600">
            Descreva o produto que deseja vender e nossa IA criará automaticamente um anúncio completo e otimizado para a Shopee, incluindo título, descrição, variações e especificações.
          </p>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="productInfo" className="block text-sm font-medium text-gray-700 mb-1">
                O que você deseja vender?
              </label>
              <Textarea
                id="productInfo"
                placeholder="Ex: Fone de ouvido bluetooth TWS com cancelamento de ruído, bateria de longa duração e resistente à água"
                value={productInfo}
                onChange={(e) => setProductInfo(e.target.value)}
                disabled={isLoading}
                className="min-h-[100px]"
              />
              <p className="text-xs text-gray-500 mt-1">
                Seja específico: inclua características, materiais, diferenciais e público-alvo do produto.
              </p>
            </div>
            
            <div>
              <label htmlFor="shopeeUrl" className="block text-sm font-medium text-gray-700 mb-1">
                URL do produto na Shopee (opcional)
              </label>
              <Input
                id="shopeeUrl"
                placeholder="Ex: https://shopee.com.br/product/123456789/987654321"
                value={shopeeUrl}
                onChange={(e) => setShopeeUrl(e.target.value)}
                disabled={isLoading}
              />
              <p className="text-xs text-gray-500 mt-1">
                Se você fornecer uma URL da Shopee, usaremos técnicas de scraping para extrair dados reais do produto e melhorar os resultados.
              </p>
            </div>
            
            <Button
              type="submit"
              className="w-full"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <LoaderCircle className="mr-2 h-4 w-4 animate-spin" />
                  Gerando anúncio...
                </>
              ) : (
                <>
                  <i className="fas fa-wand-magic-sparkles mr-2"></i>
                  Gerar Anúncio Completo
                </>
              )}
            </Button>
          </form>
          
          <div className="text-sm text-gray-500 mt-4">
            <h3 className="font-semibold">Como funciona:</h3>
            <ol className="list-decimal list-inside space-y-1 mt-2">
              <li>Descreva o produto com o máximo de detalhes</li>
              <li>Nossa IA gera um anúncio completo otimizado para a Shopee</li>
              <li>Personalize se necessário e copie com um clique</li>
              <li>Cole diretamente na criação de anúncios da Shopee</li>
            </ol>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
