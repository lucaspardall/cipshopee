import React from "react";
import { Header } from "@/components/layout/header";
import { useLocation } from "wouter";

interface MainContentProps {
  children: React.ReactNode;
}

export function MainContent({ children }: MainContentProps) {
  const [location] = useLocation();
  
  // Páginas públicas que não precisam de header
  const publicRoutes = ["/login", "/register"];
  const shouldShowHeader = !publicRoutes.includes(location);
  
  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {shouldShowHeader && <Header />}
      
      <main className="flex-1 overflow-auto">
        <div className="p-3 sm:p-6 lg:p-8 pt-16 sm:pt-6 lg:pt-8">
          {children}
          
          <footer className="mt-16 text-center py-4 text-xs text-gray-500">
            <p>© {new Date().getFullYear()} Centro de Inteligência Pardal (CIP) - Todos os direitos reservados</p>
          </footer>
        </div>
      </main>
    </div>
  );
}
