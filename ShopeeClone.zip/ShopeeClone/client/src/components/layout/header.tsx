import React, { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Search, Bell, User, ChevronDown, MessageCircle, Settings, HelpCircle, LogIn, Loader2 } from "lucide-react";

export function Header() {
  const { user, isLoading } = useAuth();
  const [isLoginLoading, setIsLoginLoading] = useState(false);
  const { toast } = useToast();
  
  const handleLogin = async () => {
    setIsLoginLoading(true);
    try {
      // Limpar cookies primeiro para evitar problemas
      const clearResponse = await fetch('/api/auth/limpar-cookies');
      const clearData = await clearResponse.json();
      
      if (clearData.success) {
        toast({
          title: "Cookies limpos",
          description: "Preparando login direto..."
        });
        
        // Tentar login direto
        const loginResponse = await fetch('/api/auth/login-direto/1');
        const loginData = await loginResponse.json();
        
        if (loginData.success) {
          toast({
            title: "Login com sucesso",
            description: "Redirecionando para o dashboard..."
          });
          setTimeout(() => {
            window.location.href = loginData.redirectTo || '/dashboard';
          }, 500);
        } else {
          throw new Error(loginData.message || "Erro no login");
        }
      }
    } catch (error) {
      console.error("Erro no processo de login:", error);
      toast({
        title: "Erro no login",
        description: "Tente novamente ou limpe os cookies manualmente.",
        variant: "destructive"
      });
    } finally {
      setIsLoginLoading(false);
    }
  };
  
  return (
    <header className="border-b border-gray-200 bg-white">
      <div className="flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Área de pesquisa */}
        <div className="flex-1 sm:mr-4 lg:mr-6 relative max-w-xl ml-14 lg:ml-0">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Pesquisar..."
              className="w-full h-10 pl-10 pr-4 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent text-sm"
            />
          </div>
        </div>

        {/* Ferramentas e ações rápidas */}
        <div className="flex items-center gap-2 sm:gap-4">
          <div className="hidden md:flex gap-2">
            <Button
              variant="outline"
              size="sm"
              className="text-gray-600 flex items-center gap-2"
            >
              <MessageCircle className="h-4 w-4" />
              <span className="hidden lg:inline">Suporte</span>
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              className="text-gray-600 flex items-center gap-2"
            >
              <HelpCircle className="h-4 w-4" />
              <span className="hidden lg:inline">Ajuda</span>
            </Button>
          </div>

          {/* Notificações */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="relative w-9 h-9 flex items-center justify-center"
              >
                <Bell className="h-5 w-5 text-gray-600" />
                <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-primary-500"></span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[90vw] sm:w-80">
              <DropdownMenuLabel>Notificações</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <div className="max-h-[40vh] sm:max-h-80 overflow-y-auto">
                <div className="p-3 border-b border-gray-100 hover:bg-gray-50">
                  <div className="flex items-start">
                    <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-3 flex-shrink-0">
                      <Bell className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Nova funcionalidade disponível</p>
                      <p className="text-xs text-gray-500 mt-1">Agora você pode exportar relatórios em PDF.</p>
                      <p className="text-xs text-gray-400 mt-1">Há 2 horas</p>
                    </div>
                  </div>
                </div>
                <div className="p-3 border-b border-gray-100 hover:bg-gray-50">
                  <div className="flex items-start">
                    <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-3 flex-shrink-0">
                      <Settings className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Otimização de produto concluída</p>
                      <p className="text-xs text-gray-500 mt-1">Seu produto "Fone de Ouvido" foi otimizado.</p>
                      <p className="text-xs text-gray-400 mt-1">Há 1 dia</p>
                    </div>
                  </div>
                </div>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="justify-center text-primary-500 cursor-pointer">
                Ver todas as notificações
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Botão de login/logout */}
          {isLoading ? (
            <Button variant="ghost" disabled className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Carregando...</span>
            </Button>
          ) : user ? (
            <div className="flex items-center gap-1">
              {/* Botão de perfil que vai direto para página de conta */}
              <Link href="/account">
                <Button 
                  variant="ghost" 
                  className="w-12 h-12 p-0 rounded-full relative bg-blue-100 border-2 border-blue-300 shadow-sm"
                >
                  <User className="h-5 w-5 text-blue-600" />
                </Button>
              </Link>
              
              {/* Dropdown menu para opções adicionais */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="flex items-center gap-2 p-1 sm:p-2"
                  >
                    <div className="hidden sm:block text-left">
                      <div className="text-sm font-medium truncate max-w-[100px]">
                        {user.name || user.username}
                      </div>
                      <div className="text-xs text-gray-500">Plano Essencial</div>
                    </div>
                    <ChevronDown className="h-4 w-4 text-blue-500" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-[90vw] sm:w-56">
                  <DropdownMenuLabel>Minha conta</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <Link href="/account">
                    <DropdownMenuItem className="cursor-pointer">
                      <User className="mr-2 h-4 w-4" />
                      <span>Perfil</span>
                    </DropdownMenuItem>
                  </Link>
                  <Link href="/account?tab=settings">
                    <DropdownMenuItem className="cursor-pointer">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Configurações</span>
                    </DropdownMenuItem>
                  </Link>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    className="cursor-pointer text-red-500 font-medium"
                    onClick={() => {
                      // Primeiro limpar localStorage
                      localStorage.removeItem('cip-auth');
                      
                      // Então limpar cookies
                      fetch('/api/auth/limpar-cookies')
                        .then(res => res.json())
                        .catch(err => console.error('Erro ao limpar cookies:', err))
                        .finally(() => {
                          // Então sair via API
                          fetch('/api/auth/logout')
                            .then(() => {
                              console.log('Logout realizado com sucesso');
                              window.location.href = '/login?logout=success';
                            })
                            .catch(err => {
                              console.error('Erro ao fazer logout:', err);
                              window.location.href = '/login?logout=error';
                            });
                        });
                    }}
                  >
                    <span>Sair</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm"
                className="text-primary-600 border-primary-300 hover:bg-primary-50"
                onClick={handleLogin}
                disabled={isLoginLoading}
              >
                {isLoginLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    <span>Entrando...</span>
                  </>
                ) : (
                  <>
                    <LogIn className="mr-2 h-4 w-4" />
                    <span>Entrar</span>
                  </>
                )}
              </Button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}