import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { siteConfig } from "@/config/site";
import { useAuth } from "@/hooks/use-auth";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  
  // Fechar a sidebar quando mudar de página em dispositivos móveis
  useEffect(() => {
    setIsOpen(false);
  }, [location]);
  
  // Fechar a sidebar quando clicar fora dela em dispositivos móveis
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const sidebar = document.getElementById('mobile-sidebar');
      if (isOpen && sidebar && !sidebar.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);
  
  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };
  
  return (
    <>
      {/* Botão do menu mobile - fixo no canto superior esquerdo com cores fortes */}
      <button 
        className="lg:hidden fixed top-4 left-4 z-50 w-14 h-14 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg border-4 border-blue-300"
        onClick={toggleSidebar}
        aria-label="Menu"
        style={{ backgroundColor: '#2563eb', borderColor: '#93c5fd' }}
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>
      
      {/* Sobreposição escura quando o menu está aberto no mobile */}
      {isOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-20"
          onClick={() => setIsOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <aside 
        id="mobile-sidebar"
        className={`fixed lg:static z-30 w-64 max-w-[85vw] bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 h-screen overflow-y-auto transition-all duration-300 ease-in-out shadow-xl ${
          isOpen ? "left-0" : "-left-full lg:left-0"
        }`}
      >
        <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-primary-50 to-white dark:from-primary-900 dark:to-gray-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-10 h-10 flex items-center justify-center bg-primary-600 text-white rounded-lg font-bold text-lg font-poppins shadow-md">
                CIP
              </div>
              <h1 className="ml-2 text-xl font-semibold text-primary-700 dark:text-primary-300 font-poppins">Centro de<br/>Inteligência</h1>
            </div>
            <button 
              className="lg:hidden text-gray-700 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-700 p-2 rounded-full" 
              onClick={toggleSidebar}
            >
              <X size={18} />
            </button>
          </div>
        </div>
        
        {user && (
          <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800">
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-full bg-primary-100 dark:bg-primary-800 flex items-center justify-center shadow-sm">
                <i className="fas fa-user text-primary-600 dark:text-primary-300"></i>
              </div>
              <div className="ml-3">
                <div className="text-sm font-medium text-gray-800 dark:text-gray-100">{user.name || user.username}</div>
                <div className="flex items-center mt-1">
                  <div className="text-xs bg-primary-100 dark:bg-primary-800 text-primary-700 dark:text-primary-300 px-2 py-0.5 rounded-full font-medium">Plano: Essencial</div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        <nav className="p-2">
          <ul className="space-y-1">
            {siteConfig.mainNav.map((item) => (
              <li key={item.href}>
                <Link href={item.href} className={`flex items-center p-3 rounded-lg font-medium ${
                  location === item.href 
                    ? "text-white bg-primary-600 shadow-sm" 
                    : "text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                }`}>
                  <i className={`fas fa-${item.icon} w-6`}></i>
                  <span>{item.title}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        
        <div className="mt-auto p-4 border-t border-gray-200 dark:border-gray-700">
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-primary-700 dark:text-primary-300 mb-2">Status da Fonte de Dados</h3>
            
            {user?.shopeeApiEnabled ? (
              <>
                <div className="mt-2 flex items-center">
                  <div className="w-3 h-3 rounded-full bg-green-500 shadow-sm animate-pulse"></div>
                  <span className="ml-2 text-xs font-medium text-gray-800 dark:text-gray-200">API Shopee (Ativo)</span>
                </div>
                <div className="mt-1 flex items-center">
                  <div className="w-3 h-3 rounded-full bg-gray-300 dark:bg-gray-500"></div>
                  <span className="ml-2 text-xs text-gray-500 dark:text-gray-400">Web Scraping (Inativo)</span>
                </div>
                <Button
                  variant="link"
                  size="sm"
                  className="mt-3 text-xs text-primary-600 dark:text-primary-400 font-semibold p-0 h-auto"
                >
                  <i className="fas fa-cog mr-1"></i> Configurar API
                </Button>
              </>
            ) : (
              <>
                <div className="mt-2 flex items-center">
                  <div className="w-3 h-3 rounded-full bg-green-500 shadow-sm animate-pulse"></div>
                  <span className="ml-2 text-xs font-medium text-gray-800 dark:text-gray-200">Web Scraping (Ativo)</span>
                </div>
                <div className="mt-1 flex items-center">
                  <div className="w-3 h-3 rounded-full bg-gray-300 dark:bg-gray-500"></div>
                  <span className="ml-2 text-xs text-gray-500 dark:text-gray-400">API Shopee (Inativo)</span>
                </div>
                <Link href="/integrations/shopee">
                  <Button
                    variant="link"
                    size="sm"
                    className="mt-3 text-xs text-primary-600 dark:text-primary-400 font-semibold p-0 h-auto"
                  >
                    <i className="fas fa-plug mr-1"></i> Conectar API Shopee
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </aside>
    </>
  );
}