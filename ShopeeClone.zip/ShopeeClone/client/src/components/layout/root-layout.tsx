import React, { useEffect } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { MainContent } from "@/components/layout/main-content";
import { useAuth } from "@/hooks/use-auth"; 
import { useLocation } from "wouter";
import { Loader2 } from "lucide-react";

interface RootLayoutProps {
  children: React.ReactNode;
  requireAuth?: boolean;
}

export function RootLayout({ children, requireAuth = true }: RootLayoutProps) {
  const { user, isLoading, isAuthenticated } = useAuth();
  const [location, setLocation] = useLocation();
  
  useEffect(() => {
    if (!isLoading && requireAuth && !isAuthenticated) {
      setLocation("/login");
    }
  }, [isLoading, requireAuth, isAuthenticated, setLocation]);
  
  // Public routes that don't require authentication
  const publicRoutes = ["/", "/login", "/register"];
  
  if (isLoading && requireAuth && !publicRoutes.includes(location)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
        <span className="ml-2 text-lg">Carregando...</span>
      </div>
    );
  }
  
  // For public routes, don't show the sidebar
  if (publicRoutes.includes(location)) {
    return <MainContent>{children}</MainContent>;
  }
  
  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      <Sidebar />
      <MainContent>{children}</MainContent>
    </div>
  );
}
