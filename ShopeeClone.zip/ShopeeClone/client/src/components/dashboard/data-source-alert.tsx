import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { X, Info } from "lucide-react";
import { useState } from "react";

export function DataSourceAlert() {
  const [isVisible, setIsVisible] = useState(true);
  
  if (!isVisible) return null;
  
  return (
    <Alert className="mb-6 bg-blue-50 border border-blue-200 text-blue-800">
      <Info className="h-4 w-4 text-blue-500" />
      <AlertTitle className="text-sm font-semibold text-blue-700">Sobre a Fonte de Dados</AlertTitle>
      <AlertDescription className="text-sm text-blue-600">
        Atualmente, estamos coletando dados diretamente da Shopee. Isso significa que algumas informações podem ter atrasos ou precisão limitada. Para dados em tempo real e recursos avançados, considere conectar a API oficial da Shopee.
        <Button variant="link" className="mt-2 text-xs font-medium text-blue-700 hover:text-blue-900 p-0 h-auto">
          Saiba mais
        </Button>
      </AlertDescription>
      <Button
        variant="ghost"
        size="icon"
        className="absolute top-1 right-1 text-gray-400 hover:text-gray-600 h-6 w-6"
        onClick={() => setIsVisible(false)}
      >
        <X className="h-4 w-4" />
      </Button>
    </Alert>
  );
}
