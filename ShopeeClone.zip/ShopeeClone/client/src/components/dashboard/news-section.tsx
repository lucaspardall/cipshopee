import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { NewsItem } from "@/types";
import { Link } from "wouter";

interface NewsSectionProps {
  news: NewsItem[];
}

export function NewsSection({ news }: NewsSectionProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-semibold font-poppins">Últimas do Centro de Notícias</CardTitle>
        <Link href="/news" className="text-sm text-primary-500 font-medium hover:text-primary-600">
          Ver tudo
        </Link>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {news.map((item) => (
            <div key={item.id} className="border border-gray-100 rounded-lg overflow-hidden hover:shadow-md transition cursor-pointer">
              <img src={item.imageUrl} alt={item.title} className="w-full h-36 object-cover" />
              <div className="p-4">
                <div className="flex items-center text-xs text-gray-500 mb-2">
                  <i className="fas fa-calendar-alt mr-1"></i> {item.date}
                </div>
                <h3 className="font-semibold text-sm mb-2">{item.title}</h3>
                <p className="text-xs text-gray-500 mb-3">{item.description}</p>
                <Link href={item.link} className="text-xs font-semibold text-primary-500">
                  Ler mais
                </Link>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
