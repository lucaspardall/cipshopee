import { RadialProgress } from "@/components/common/radial-progress";
import { DataSourceWrapper } from "@/components/common/data-source-indicator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DataSourceType } from "@shared/schema";

interface ScoreItem {
  color: string;
  label: string;
  value: number;
  max: number;
}

interface StoreHealthScoreProps {
  score: number;
  items: ScoreItem[];
  dataSource: DataSourceType;
}

export function StoreHealthScore({ score, items, dataSource }: StoreHealthScoreProps) {
  return (
    <DataSourceWrapper source={dataSource}>
      <Card className="h-full">
        <CardHeader>
          <CardTitle className="text-lg font-semibold font-poppins">Score de Saúde da Loja</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <RadialProgress 
              value={score} 
              color="hsl(var(--primary))"
              size="8rem"
              className="flex-shrink-0" 
            />
            <div className="space-y-3">
              {items.map((item, index) => (
                <div key={index} className="flex items-center">
                  <div 
                    className="w-2 h-2 rounded-full mr-2" 
                    style={{ backgroundColor: item.color }} 
                  />
                  <span className="text-sm text-gray-600">
                    {item.label}: {item.value}/{item.max}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </DataSourceWrapper>
  );
}
