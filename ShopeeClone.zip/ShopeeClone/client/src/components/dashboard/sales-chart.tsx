import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DataSourceWrapper } from "@/components/common/data-source-indicator";
import { DataSourceType } from "@shared/schema";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

interface SalesData {
  date: string;
  value: number;
}

interface SalesChartProps {
  title: string;
  data: SalesData[];
  changePercentage: number;
  dataSource: DataSourceType;
}

export function SalesChart({ title, data, changePercentage, dataSource }: SalesChartProps) {
  return (
    <DataSourceWrapper source={dataSource}>
      <Card className="h-full">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg font-semibold font-poppins">{title}</CardTitle>
          <div className="text-xs bg-primary-50 text-primary-600 px-2 py-1 rounded-full font-medium">
            {changePercentage > 0 ? "+" : ""}{changePercentage}% vs anterior
          </div>
        </CardHeader>
        <CardContent>
          <div className="chart-container">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={data}
                margin={{
                  top: 10,
                  right: 10,
                  left: 10,
                  bottom: 10,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis 
                  dataKey="date" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12 }}
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12 }}
                  width={30}
                />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  dot={{ r: 3, strokeWidth: 2, fill: "white" }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </DataSourceWrapper>
  );
}
