import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ActionItem } from "@/types";
import { Link } from "wouter";

interface RecommendedActionsProps {
  actions: ActionItem[];
}

export function RecommendedActions({ actions }: RecommendedActionsProps) {
  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="text-lg font-semibold font-poppins">Ações Recomendadas</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-3">
          {actions.map((action, index) => (
            <li key={index} className="flex items-start">
              <div className="mt-0.5 w-6 h-6 flex-shrink-0 rounded-full bg-secondary-500 text-white flex items-center justify-center">
                <i className={`fas fa-${action.icon} text-xs`}></i>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium">{action.text}</p>
                <Link href={action.actionLink} className="text-xs text-primary-500 font-medium">
                  {action.actionText}
                </Link>
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
