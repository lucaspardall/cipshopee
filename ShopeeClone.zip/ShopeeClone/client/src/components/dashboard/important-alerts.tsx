import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert } from "@/types";
import { Button } from "@/components/ui/button";

interface ImportantAlertsProps {
  alerts: Alert[];
}

export function ImportantAlerts({ alerts }: ImportantAlertsProps) {
  const getAlertBorderColor = (type: Alert['type']) => {
    switch (type) {
      case 'error':
        return 'border-red-500';
      case 'warning':
        return 'border-yellow-500';
      case 'info':
        return 'border-blue-500';
      case 'success':
        return 'border-green-500';
      default:
        return 'border-gray-500';
    }
  };
  
  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-semibold font-poppins">Alertas Importantes</CardTitle>
        <div className="px-2 py-1 bg-red-50 text-red-500 rounded text-xs font-medium">
          {alerts.length} {alerts.length === 1 ? 'novo' : 'novos'}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {alerts.map((alert, index) => (
            <div 
              key={index} 
              className={`border-l-4 ${getAlertBorderColor(alert.type)} pl-3 py-2`}
            >
              <h3 className="text-sm font-semibold">{alert.title}</h3>
              <p className="text-xs text-gray-500 mt-1">{alert.description}</p>
              {alert.action && (
                <Button 
                  variant="link" 
                  size="sm" 
                  className="mt-2 text-xs font-semibold text-primary-500 p-0 h-auto"
                  asChild
                >
                  <a href={alert.actionLink || '#'}>{alert.action}</a>
                </Button>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
