import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DataSourceWrapper } from "@/components/common/data-source-indicator";
import { DataSourceType } from "@shared/schema";
import { ProductItem } from "@/types";
import { Link } from "wouter";

interface ProductPerformanceProps {
  products: ProductItem[];
  dataSource: DataSourceType;
}

export function ProductPerformance({ products, dataSource }: ProductPerformanceProps) {
  return (
    <DataSourceWrapper source={dataSource}>
      <Card className="h-full">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg font-semibold font-poppins">Produtos em Destaque</CardTitle>
          <Link href="/manage-listings" className="text-sm text-primary-500 font-medium hover:text-primary-600">
            Ver todos
          </Link>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {products.map((product) => (
              <div key={product.id} className="flex items-center p-2 hover:bg-gray-50 rounded-lg transition cursor-pointer">
                <img src={product.image} alt={product.title} className="w-14 h-14 rounded-lg object-cover border border-gray-200" />
                <div className="ml-3 flex-1">
                  <h3 className="text-sm font-medium text-gray-900 line-clamp-1">{product.title}</h3>
                  <div className="flex items-center text-xs text-gray-500 mt-1">
                    <span className="flex items-center mr-3">
                      <i className="fas fa-eye mr-1"></i> {product.views}
                    </span>
                    <span className="flex items-center mr-3">
                      <i className="fas fa-shopping-cart mr-1"></i> {product.sales}
                    </span>
                    <span className="flex items-center">
                      <i className="fas fa-star mr-1 text-yellow-400"></i> {product.rating}
                    </span>
                  </div>
                </div>
                <div className="text-sm font-semibold text-primary-500">
                  R$ {product.price.toFixed(2).replace('.', ',')}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </DataSourceWrapper>
  );
}
