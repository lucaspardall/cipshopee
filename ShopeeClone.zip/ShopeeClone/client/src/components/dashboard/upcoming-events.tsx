import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UpcomingEvent } from "@/types";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

interface UpcomingEventsProps {
  events: UpcomingEvent[];
}

export function UpcomingEvents({ events }: UpcomingEventsProps) {
  const getPriorityBadgeClass = (priority: UpcomingEvent['priority']) => {
    switch (priority) {
      case 'HIGH':
        return 'bg-green-50 text-green-700';
      case 'MEDIUM':
        return 'bg-yellow-50 text-yellow-700';
      case 'LOW':
        return 'bg-gray-50 text-gray-600';
      default:
        return 'bg-gray-50 text-gray-600';
    }
  };
  
  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-semibold font-poppins">Eventos Próximos</CardTitle>
        <Link href="/events" className="text-sm text-primary-500 font-medium hover:text-primary-600">
          Ver todos
        </Link>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {events.map((event) => (
            <div key={event.id} className="flex items-start">
              <div className="flex-shrink-0 w-12 h-12 bg-secondary-50 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <div className="text-xs font-bold text-secondary-500">{event.month}</div>
                  <div className="text-sm font-bold text-secondary-600">{event.day}</div>
                </div>
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-semibold">{event.title}</h3>
                <p className="text-xs text-gray-500 mt-1">{event.description}</p>
                <div className="flex items-center mt-2">
                  <div className={`text-xs px-2 py-1 rounded-full ${getPriorityBadgeClass(event.priority)}`}>
                    {event.priority === 'HIGH' ? 'Alta prioridade' : 
                     event.priority === 'MEDIUM' ? 'Média prioridade' : 'Baixa prioridade'}
                  </div>
                  <Button 
                    variant="link"
                    size="sm"
                    className="ml-3 text-xs font-semibold text-primary-500 p-0 h-auto"
                    asChild
                  >
                    <Link href={event.actionLink}>Participar</Link>
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
