import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DataSourceWrapper } from "@/components/common/data-source-indicator";
import { DataSourceType } from "@shared/schema";
import { MetricItem } from "@/types";

interface KeyMetricsProps {
  metrics: MetricItem[];
  dataSource: DataSourceType;
}

export function KeyMetrics({ metrics, dataSource }: KeyMetricsProps) {
  return (
    <DataSourceWrapper source={dataSource}>
      <Card className="h-full">
        <CardHeader>
          <CardTitle className="text-lg font-semibold font-poppins">Métricas-chave</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {metrics.map((metric, index) => (
              <div key={index} className="flex justify-between items-center">
                <div>
                  <p className="text-xs text-gray-500">{metric.label}</p>
                  <p className="text-lg font-semibold">{metric.value}</p>
                </div>
                <div className={`text-xs px-2 py-1 rounded ${
                  metric.direction === 'up' 
                    ? 'bg-green-50 text-green-700' 
                    : metric.direction === 'down' 
                      ? 'bg-red-50 text-red-700'
                      : 'bg-yellow-50 text-yellow-700'
                } flex items-center`}>
                  {metric.direction === 'up' && <i className="fas fa-arrow-up mr-1"></i>}
                  {metric.direction === 'down' && <i className="fas fa-arrow-down mr-1"></i>}
                  {metric.direction === 'neutral' && <i className="fas fa-equals mr-1"></i>}
                  {metric.change !== undefined ? (
                    typeof metric.change === 'number' 
                      ? `${metric.change > 0 ? '+' : ''}${metric.change}${typeof metric.value === 'string' && metric.value.includes('%') ? '%' : ''}`
                      : metric.change
                  ) : '0%'}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </DataSourceWrapper>
  );
}
