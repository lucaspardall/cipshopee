import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { OptimizationTool } from "@/types";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface OptimizationToolsProps {
  tools: OptimizationTool[];
}

export function OptimizationTools({ tools }: OptimizationToolsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold font-poppins">Ferramentas de Otimização</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {tools.map((tool) => (
            <div key={tool.id} className={`rounded-xl p-5`} style={{ backgroundColor: `${tool.color}10` }}>
              <div 
                className="w-12 h-12 rounded-lg flex items-center justify-center mb-4"
                style={{ backgroundColor: tool.color }}
              >
                <i className={`fas fa-${tool.icon} text-white text-xl`}></i>
              </div>
              <h3 className="font-semibold" style={{ color: `${tool.color}` }}>{tool.title}</h3>
              <p className="text-xs mt-1 mb-4" style={{ color: `${tool.color}` }}>{tool.description}</p>
              <Button 
                className="w-full py-2 px-4 text-white rounded-lg text-sm font-medium transition"
                style={{ backgroundColor: tool.color, "&:hover": { backgroundColor: tool.color + "CC" } }}
                asChild
              >
                <Link href={tool.link}>{tool.buttonText}</Link>
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
