import { useState, FormEvent } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Sparkles } from "lucide-react";
import axios from "axios";

interface ManualFormProps {
  onOptimize: (result: any) => void;
}

export function ManualForm({ onOptimize }: ManualFormProps) {
  const [productUrl, setProductUrl] = useState("");
  const [productTitle, setProductTitle] = useState("");
  const [productDescription, setProductDescription] = useState("");
  const [productPrice, setProductPrice] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!productTitle.trim() || !productDescription.trim() || !productPrice) {
      toast({
        title: "Informações incompletas",
        description: "Preencha todos os campos: título, descrição e preço",
        variant: "destructive",
      });
      return;
    }
    
    // Verificar se o preço é um número válido
    const priceValue = parseFloat(productPrice.replace(",", "."));
    if (isNaN(priceValue) || priceValue <= 0) {
      toast({
        title: "Preço inválido",
        description: "Insira um valor numérico válido para o preço",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Otimizar com entrada manual
      const result = await axios.post("/api/optimize-direct", {
        productUrl,
        productTitle,
        productDescription,
        productPrice: parseFloat(productPrice.replace(",", "."))
      });
      
      onOptimize(result.data);
    } catch (error) {
      console.error("Error optimizing product:", error);
      toast({
        title: "Erro na otimização",
        description: "Ocorreu um erro ao otimizar o produto. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl font-bold font-poppins flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          Otimizador de Anúncios
        </CardTitle>
        <CardDescription>
          Transforme seu anúncio da Shopee em uma máquina de vendas com nossa otimização profissional
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="productTitle">Título do Produto</Label>
              <Input
                id="productTitle"
                placeholder="Título do seu produto"
                value={productTitle}
                onChange={(e) => setProductTitle(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="productDescription">Descrição do Produto</Label>
              <Textarea
                id="productDescription"
                placeholder="Descrição completa do seu produto"
                value={productDescription}
                onChange={(e) => setProductDescription(e.target.value)}
                rows={6}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="productPrice">Preço do Produto (R$)</Label>
              <Input
                id="productPrice"
                placeholder="99,90"
                value={productPrice}
                onChange={(e) => setProductPrice(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="productUrl">URL do Produto (opcional)</Label>
              <Input
                id="productUrl"
                type="url"
                placeholder="https://shopee.com.br/product/..."
                value={productUrl}
                onChange={(e) => setProductUrl(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Campo opcional para referência interna
              </p>
            </div>
          </div>
          
          <Button 
            type="submit" 
            className="w-full" 
            disabled={isLoading}
          >
            {isLoading ? "Otimizando..." : "Otimizar Anúncio"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}