import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { OptimizationResult } from "@/types";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DataSourceWrapper } from "@/components/common/data-source-indicator";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { DataSourceType } from "@/types";

interface OptimizationResultProps {
  result: OptimizationResult;
}

export function OptimizationResultView({ result }: OptimizationResultProps) {
  const { product, optimization } = result;
  const [activeTab, setActiveTab] = useState("title");
  const { toast } = useToast();
  
  const copyToClipboard = (text: string | undefined, label: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    toast({
      title: "Copiado!",
      description: `${label} copiado para a área de transferência`,
      variant: "default",
    });
  };
  
  const copyAll = () => {
    const allContent = `
TÍTULO:
${optimization.optimizedTitle || product.title}
${optimization.titleJustification ? `\nPor que melhoramos: ${optimization.titleJustification}` : ''}

DESCRIÇÃO:
${optimization.optimizedDescription || product.description}
${optimization.descriptionJustification ? `\nPor que melhoramos: ${optimization.descriptionJustification}` : ''}

PREÇO SUGERIDO:
R$ ${optimization.suggestedPrice?.toFixed(2).replace('.', ',') || product.price?.toFixed(2).replace('.', ',')}
${optimization.discountPrice ? `\nPREÇO COM DESCONTO: R$ ${optimization.discountPrice.toFixed(2).replace('.', ',')}` : ''}
${optimization.priceJustification ? `\nPor que sugerimos: ${optimization.priceJustification}` : ''}

PALAVRAS-CHAVE:
${optimization.optimizedKeywords?.join(", ") || product.keywords?.join(", ")}
${optimization.keywordsJustification ? `\nPor que escolhemos: ${optimization.keywordsJustification}` : ''}

MELHORIAS RECOMENDADAS:
${(optimization.generalImprovements || []).map((imp: string) => `- ${imp}`).join("\n")}
${optimization.improvementsJustification ? `\nPor que recomendamos: ${optimization.improvementsJustification}` : ''}

PLANO DE BOOST 7 DIAS:
${(optimization.boostPlan || []).map((step: string) => `- ${step}`).join("\n")}
    `.trim();
    
    copyToClipboard(allContent, "Pacote completo");
  };
  
  return (
    <DataSourceWrapper source={product.dataSource as DataSourceType || DataSourceType.SCRAPING} className="mt-8">
      <Card>
        <CardContent className="pt-6">
          <div className="mb-4">
            <h2 className="text-lg font-bold font-poppins mb-2 text-primary-800">
              Pacote de Otimização
            </h2>
            <p className="text-gray-600 text-sm">
              A otimização está pronta! Copie os elementos abaixo e cole diretamente no seu anúncio na Shopee.
            </p>
          </div>
          
          <div className="bg-green-50 p-3 rounded-md mb-4">
            <div className="flex items-center">
              <div className="text-green-600 mr-2">
                <i className="fas fa-check-circle"></i>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-green-800">Melhoria Estimada</h3>
                <p className="text-xs text-green-700">
                  Estima-se um aumento de {optimization.estimatedImprovement || "15-25"}% na visibilidade e conversão.
                </p>
              </div>
            </div>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-6 mb-4">
              <TabsTrigger value="title">Título</TabsTrigger>
              <TabsTrigger value="description">Descrição</TabsTrigger>
              <TabsTrigger value="price">Preço</TabsTrigger>
              <TabsTrigger value="keywords">Keywords</TabsTrigger>
              <TabsTrigger value="improvements">Melhorias</TabsTrigger>
              <TabsTrigger value="boost">Boost 7 Dias</TabsTrigger>
            </TabsList>
            
            <TabsContent value="title" className="border p-4 rounded-md min-h-[200px]">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-sm font-semibold">Título Otimizado</h3>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => copyToClipboard(optimization.optimizedTitle || product.title, "Título")}
                >
                  <i className="fas fa-copy mr-1"></i> Copiar
                </Button>
              </div>
              <p className="text-gray-800 border border-dashed border-gray-300 p-2 rounded">
                {optimization.optimizedTitle || product.title}
              </p>
              
              {product.originalTitle && (
                <div className="mt-4">
                  <h4 className="text-xs font-semibold text-gray-500">Título Original:</h4>
                  <p className="text-xs text-gray-500 italic">{product.originalTitle}</p>
                  
                  {optimization.titleJustification && (
                    <div className="mt-2 bg-yellow-50 p-3 rounded-md border border-yellow-100">
                      <h4 className="text-xs font-semibold text-amber-800">Justificativa:</h4>
                      <p className="text-xs text-amber-700 mt-1">{optimization.titleJustification}</p>
                    </div>
                  )}
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="description" className="border p-4 rounded-md min-h-[200px]">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-sm font-semibold">Descrição Otimizada</h3>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => copyToClipboard(optimization.optimizedDescription || product.description, "Descrição")}
                >
                  <i className="fas fa-copy mr-1"></i> Copiar
                </Button>
              </div>
              <div className="text-gray-800 border border-dashed border-gray-300 p-2 rounded whitespace-pre-line h-[300px] overflow-y-auto">
                {optimization.optimizedDescription || product.description}
              </div>
              
              {product.originalDescription && (
                <div className="mt-4">
                  <h4 className="text-xs font-semibold text-gray-500">Descrição Original:</h4>
                  <p className="text-xs text-gray-500 italic line-clamp-3">{product.originalDescription}</p>
                </div>
              )}
              
              {optimization.descriptionJustification && (
                <div className="mt-4 bg-yellow-50 p-3 rounded-md border border-yellow-100">
                  <h4 className="text-xs font-semibold text-amber-800">Justificativa:</h4>
                  <p className="text-xs text-amber-700 mt-1">{optimization.descriptionJustification}</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="price" className="border p-4 rounded-md min-h-[200px]">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-sm font-semibold">Sugestão de Preço</h3>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => copyToClipboard(
                    `R$ ${optimization.suggestedPrice?.toFixed(2).replace('.', ',') || product.price?.toFixed(2).replace('.', ',')}`, 
                    "Preço sugerido"
                  )}
                >
                  <i className="fas fa-copy mr-1"></i> Copiar
                </Button>
              </div>
              
              <div className="flex flex-col mb-6">
                <div className="flex items-center">
                  <div className="text-xl font-bold text-primary-600">
                    R$ {optimization.suggestedPrice?.toFixed(2).replace('.', ',') || product.price?.toFixed(2).replace('.', ',')}
                  </div>
                  {product.price && optimization.suggestedPrice && optimization.suggestedPrice > product.price && (
                    <div className="ml-3 text-xs px-2 py-1 rounded bg-green-50 text-green-700">
                      +{Math.round((optimization.suggestedPrice / product.price - 1) * 100)}% aumento sugerido
                    </div>
                  )}
                </div>
                
                {optimization.discountPrice && (
                  <div className="flex items-center gap-2 mt-3">
                    <div className="text-lg font-bold text-green-600">
                      R$ {optimization.discountPrice?.toFixed(2).replace('.', ',')}
                    </div>
                    <div className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                      Preço com desconto
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => optimization.discountPrice && copyToClipboard(
                        `R$ ${optimization.discountPrice.toFixed(2).replace('.', ',')}`, 
                        "Preço com desconto"
                      )}
                    >
                      <i className="fas fa-copy mr-1"></i> Copiar
                    </Button>
                  </div>
                )}
              </div>
              
              <div className="bg-yellow-50 p-3 rounded-md border border-yellow-100">
                <h4 className="text-sm font-semibold text-amber-800">Justificativa:</h4>
                <p className="text-sm text-amber-700 mt-1">
                  {optimization.priceJustification || "Este preço foi sugerido com base em análise competitiva e no valor percebido das melhorias de listagem. Nossa análise indica que este valor está dentro da faixa de preço aceitável para produtos similares, enquanto destaca o posicionamento premium do seu produto."}
                </p>
              </div>
            </TabsContent>
            
            <TabsContent value="keywords" className="border p-4 rounded-md min-h-[200px]">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-sm font-semibold">Palavras-chave Otimizadas</h3>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => copyToClipboard(
                    optimization.optimizedKeywords?.join(", ") || product.keywords?.join(", "), 
                    "Palavras-chave"
                  )}
                >
                  <i className="fas fa-copy mr-1"></i> Copiar
                </Button>
              </div>
              
              <div className="flex flex-wrap gap-2 my-4">
                {(optimization.optimizedKeywords || product.keywords || []).map((keyword, index) => (
                  <div key={index} className="bg-primary-50 text-primary-700 px-2 py-1 rounded-full text-xs">
                    {keyword}
                  </div>
                ))}
              </div>
              
              <div className="text-sm text-gray-600 mt-4">
                <p>Inclua estas palavras-chave no seu título, descrição e campos de busca para melhorar a visibilidade do seu produto nos resultados de pesquisa.</p>
              </div>
              
              {optimization.keywordsJustification && (
                <div className="mt-4 bg-yellow-50 p-3 rounded-md border border-yellow-100">
                  <h4 className="text-xs font-semibold text-amber-800">Justificativa:</h4>
                  <p className="text-xs text-amber-700 mt-1">{optimization.keywordsJustification}</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="improvements" className="border p-4 rounded-md min-h-[200px]">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-sm font-semibold">Sugestões de Melhorias Gerais</h3>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => copyToClipboard(
                    (optimization.generalImprovements || []).join("\n"), 
                    "Sugestões de melhorias"
                  )}
                >
                  <i className="fas fa-copy mr-1"></i> Copiar
                </Button>
              </div>
              
              <ul className="space-y-2 my-4">
                {(optimization.generalImprovements || []).map((improvement: string, index: number) => (
                  <li key={index} className="flex items-start">
                    <i className="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                    <span className="text-gray-700">{improvement}</span>
                  </li>
                ))}
              </ul>
              
              {optimization.improvementsJustification && (
                <div className="mt-4 bg-yellow-50 p-3 rounded-md border border-yellow-100">
                  <h4 className="text-xs font-semibold text-amber-800">Justificativa:</h4>
                  <p className="text-xs text-amber-700 mt-1">{optimization.improvementsJustification}</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="boost" className="border p-4 rounded-md min-h-[200px]">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-sm font-semibold">Plano de Boost para 7 Dias</h3>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => copyToClipboard(
                    (optimization.boostPlan || []).join("\n"), 
                    "Plano de Boost"
                  )}
                >
                  <i className="fas fa-copy mr-1"></i> Copiar
                </Button>
              </div>
              
              <div className="bg-blue-50 border border-blue-100 p-4 rounded-md">
                <h4 className="text-blue-800 font-medium mb-3">Siga este plano para alavancar seu anúncio nos primeiros 7 dias:</h4>
                
                <ul className="space-y-3 my-3">
                  {(optimization.boostPlan || []).map((step, index) => (
                    <li key={index} className="flex items-start">
                      <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2 flex-shrink-0">
                        <i className="fas fa-rocket text-xs"></i>
                      </span>
                      <div>
                        <span className="text-blue-800 font-medium">{step}</span>
                      </div>
                    </li>
                  ))}
                </ul>
                
                <p className="text-sm text-blue-600 mt-4">
                  <i className="fas fa-info-circle mr-1"></i> 
                  Este plano de ação intensivo é otimizado para maximizar a visibilidade e vendas nos primeiros dias após a publicação ou atualização do seu anúncio.
                </p>
              </div>
            </TabsContent>
          </Tabs>
          
          <div className="flex justify-center mt-6">
            <Button className="mr-3" onClick={copyAll}>
              <i className="fas fa-copy mr-2"></i> Copiar Todo o Pacote
            </Button>
            <Button variant="outline">
              <i className="fas fa-save mr-2"></i> Salvar no Histórico
            </Button>
          </div>
        </CardContent>
      </Card>
    </DataSourceWrapper>
  );
}
