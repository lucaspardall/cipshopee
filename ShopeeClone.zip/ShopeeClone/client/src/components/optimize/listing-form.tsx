import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { FormEvent } from "react";
import { optimizeProduct } from "@/lib/ai";
import { LoaderCircle, ChevronDown, Sparkles } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Label } from "@/components/ui/label";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface ListingFormProps {
  onOptimize: (result: any) => void;
}

export function ListingForm({ onOptimize }: ListingFormProps) {
  const [productUrl, setProductUrl] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!productUrl.trim()) {
      toast({
        title: "URL necessária",
        description: "Insira a URL do produto que deseja otimizar",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Chamar a API só com a URL do produto
      const result = await optimizeProduct(productUrl);
      onOptimize(result);
    } catch (error) {
      console.error("Error optimizing product:", error);
      toast({
        title: "Erro na otimização",
        description: "Ocorreu um erro ao otimizar o produto. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl font-bold font-poppins flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          Otimizador de Anúncios
        </CardTitle>
        <CardDescription>
          Transforme seu anúncio da Shopee em uma máquina de vendas com nossa otimização profissional
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="product-url">URL do Produto na Shopee</Label>
            <Input
              id="product-url"
              type="text"
              placeholder="https://shopee.com.br/seu-produto"
              value={productUrl}
              onChange={(e) => setProductUrl(e.target.value)}
              disabled={isLoading}
              className="w-full"
            />
          </div>
          
          <Button
            type="submit"
            className="w-full"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <LoaderCircle className="mr-2 h-4 w-4 animate-spin" />
                Otimizando...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Otimizar Anúncio
              </>
            )}
          </Button>
        </form>
        
        <div className="space-y-4 mt-4">
          <Collapsible className="mb-4">
            <CollapsibleTrigger className="flex items-center text-sm text-primary-600 hover:text-primary-800 transition-colors cursor-pointer">
              <ChevronDown className="h-4 w-4 mr-1" />
              <span>Como funciona?</span>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <div className="text-sm text-gray-500 mt-2 pl-4">
                <h3 className="font-semibold">O processo de otimização:</h3>
                <ol className="list-decimal list-inside space-y-1 mt-2">
                  <li>Cole a URL do seu anúncio atual na Shopee</li>
                  <li>Nosso Assistente de IA analisa automaticamente seu anúncio</li>
                  <li>Receba um título otimizado com palavras-chave estratégicas</li>
                  <li>Obtenha uma descrição completa e persuasiva com emojis</li>
                  <li>Receba recomendações de preço e desconto ideais</li>
                  <li>Ganhe um plano de 7 dias para impulsionar suas vendas</li>
                </ol>
              </div>
            </CollapsibleContent>
          </Collapsible>
          
          <div className="text-xs rounded bg-green-50 p-2 border border-green-200">
            <p className="font-medium text-green-800">Assistente Shopee Master</p>
            <p className="text-green-700 mt-1">
              Este otimizador utiliza um Assistente OpenAI especializado para Shopee, treinado com técnicas avançadas de SEO e conversão específicas para o marketplace.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}