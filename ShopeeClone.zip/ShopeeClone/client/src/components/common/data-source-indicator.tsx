import React from "react";
import { DataSourceType } from "@shared/schema";
import { themeConfig } from "@/config/theme";

interface DataSourceIndicatorProps {
  source: DataSourceType;
  className?: string;
}

export function DataSourceIndicator({ source, className = "" }: DataSourceIndicatorProps) {
  const style = source === DataSourceType.API 
    ? themeConfig.dataSourceStyles.api 
    : themeConfig.dataSourceStyles.scraping;
  
  return (
    <div className={`absolute top-2 right-2 text-xs px-1.5 py-0.5 rounded ${className}`}
         style={{ backgroundColor: style.backgroundColor, color: style.textColor }}>
      {style.label}
    </div>
  );
}

interface DataSourceWrapperProps {
  source: DataSourceType;
  children: React.ReactNode;
  className?: string;
}

export function DataSourceWrapper({ source, children, className = "" }: DataSourceWrapperProps) {
  const sourceClass = source === DataSourceType.API ? "data-source-api" : "data-source-scraping";
  
  return (
    <div className={`relative ${sourceClass} ${className}`}>
      {children}
    </div>
  );
}
