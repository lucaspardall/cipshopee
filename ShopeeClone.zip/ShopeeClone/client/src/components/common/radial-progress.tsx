import React from "react";

interface RadialProgressProps {
  value: number;
  size?: string;
  thickness?: string;
  color?: string;
  bgColor?: string;
  className?: string;
  labelClassName?: string;
}

export function RadialProgress({
  value,
  size = "10rem",
  thickness = "0.6rem",
  color = "hsl(var(--primary))",
  bgColor = "hsl(var(--muted))",
  className = "",
  labelClassName = ""
}: RadialProgressProps) {
  // Ensure value is between 0-100
  const normalizedValue = Math.max(0, Math.min(100, value));
  
  // Style variables
  const sizeStyle = { width: size, height: size };
  const rotation = `rotate(${(normalizedValue / 100) * 360}deg)`;
  const maskSize = `calc(100% - ${thickness})`;
  
  return (
    <div 
      className={`relative rounded-full ${className}`}
      style={sizeStyle}
    >
      {/* Background circle */}
      <div 
        className="absolute inset-0 rounded-full"
        style={{ backgroundColor: bgColor }}
      />
      
      {/* Progress circle */}
      <div 
        className="absolute inset-0 rounded-full overflow-hidden"
        style={{ 
          background: `conic-gradient(${color} ${normalizedValue}%, transparent 0%)`,
          transform: rotation
        }}
      />
      
      {/* Center mask */}
      <div 
        className="absolute rounded-full"
        style={{ 
          inset: `calc(${thickness} / 2)`,
          backgroundColor: "hsl(var(--background))" 
        }}
      />
      
      {/* Label */}
      <div className="absolute inset-0 flex items-center justify-center">
        <span className={`text-3xl font-bold ${labelClassName}`}>
          {normalizedValue}
        </span>
      </div>
    </div>
  );
}
