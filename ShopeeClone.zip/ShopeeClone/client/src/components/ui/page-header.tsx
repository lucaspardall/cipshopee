import React from "react";

interface PageHeaderProps {
  title: string;
  description?: string;
}

export default function PageHeader({ title, description }: PageHeaderProps) {
  return (
    <div className="mb-6">
      <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">{title}</h1>
      {description && (
        <p className="text-sm sm:text-base text-gray-600">{description}</p>
      )}
    </div>
  );
}