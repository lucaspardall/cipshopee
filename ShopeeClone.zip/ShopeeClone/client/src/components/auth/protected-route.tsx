import { ReactNode, useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';

interface ProtectedRouteProps {
  children: ReactNode;
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { user, isLoading, isAuthenticated, userId } = useAuth();
  const [, setLocation] = useLocation();
  const [hasAttemptedNavigation, setHasAttemptedNavigation] = useState(false);
  const [forcedAuthCheck, setForcedAuthCheck] = useState(false);
  const { toast } = useToast();
  
  // Verificação manual forçada de autenticação 
  // Para resolver problemas em ambiente de produção
  useEffect(() => {
    if (forcedAuthCheck) return;
    
    const checkAuthDirectly = async () => {
      try {
        // Verificar sessão diretamente com o servidor
        const resp = await fetch('/api/auth/session-check');
        const data = await resp.json();
        console.log("Verificação direta de autenticação:", data);
        
        if (!data.authenticated) {
          // Se não estiver autenticado, limpar cookies e redirecionar
          console.log("Não autenticado, limpando cookies e redirecionando");
          
          // Limpar cookies primeiro
          try {
            const clearResp = await fetch('/api/auth/limpar-cookies');
            await clearResp.json();
            console.log("Cookies limpos");
          } catch (err) {
            console.error("Erro ao limpar cookies:", err);
          }
          
          // Redirecionar para login (com atraso para garantir que os cookies sejam limpos)
          setTimeout(() => {
            window.location.href = '/login?redirected=true';
          }, 500);
        } else {
          console.log("Autenticado diretamente:", data);
        }
        
        setForcedAuthCheck(true);
      } catch (error) {
        console.error("Erro na verificação direta:", error);
        setForcedAuthCheck(true); // Marcamos como verificado mesmo em caso de erro
      }
    };
    
    // Executar verificação manual apenas se a verificação automática está demorando
    const timeout = setTimeout(() => {
      if (isLoading && !isAuthenticated) {
        console.log("Verificação automática está demorando, fazendo verificação manual");
        checkAuthDirectly();
      }
    }, 1500); // Se demorar mais de 1.5 segundos, fazemos verificação manual
    
    return () => clearTimeout(timeout);
  }, [isLoading, isAuthenticated]);
  
  // Efeito original para redirecionamento quando não autenticado
  useEffect(() => {
    // Se ainda estamos carregando, aguardar
    if (isLoading) return;
    
    // Se já estamos autenticados, não fazemos nada
    if (isAuthenticated) return;
    
    // Para evitar loops infinitos - só tentamos redirecionar uma vez
    if (hasAttemptedNavigation) return;
    
    // Se não estamos autenticados após o carregamento
    setHasAttemptedNavigation(true);
    
    console.log('Usuário não autenticado, redirecionando para login');
    toast({
      title: 'Acesso restrito',
      description: 'Por favor, faça login para continuar.',
      variant: 'destructive'
    });
    
    // Limpar cookies primeiro para resolver problemas
    fetch('/api/auth/limpar-cookies')
      .then(res => res.json())
      .then(() => {
        console.log("Cookies limpos antes do redirecionamento");
        // Redirecionamento direto para login
        window.location.href = '/login?from=protected';
      })
      .catch(err => {
        console.error("Erro ao limpar cookies:", err);
        // Continuar com redirecionamento mesmo assim
        window.location.href = '/login?from=protected&error=cookies';
      });
  }, [isLoading, isAuthenticated, hasAttemptedNavigation, toast]);
  
  // Exibindo estado de carregamento enquanto verificamos a autenticação
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="mt-4 text-lg text-gray-600">Carregando...</p>
          <p className="text-sm text-gray-500">Verificando sua sessão...</p>
          {isLoading && !isAuthenticated && (
            <Button 
              variant="link" 
              className="mt-4 text-primary-500"
              onClick={() => {
                // Limpar cookies e redirecionar manualmente
                fetch('/api/auth/limpar-cookies')
                  .then(res => res.json())
                  .then(() => {
                    window.location.href = '/login?manual=true';
                  });
              }}
            >
              Problemas para carregar? Clique aqui
            </Button>
          )}
        </div>
      </div>
    );
  }
  
  // Se detectamos que não está autenticado e estamos aguardando redirecionamento
  if (!isAuthenticated && hasAttemptedNavigation) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="mt-4 text-lg text-gray-600">Redirecionando para o login...</p>
        </div>
      </div>
    );
  }
  
  // Se chegamos aqui, estamos autenticados (seja via userId ou userObject)
  if (isAuthenticated || userId) {
    return <>{children}</>;
  }
  
  // Fallback caso nenhuma das condições anteriores seja atendida - forçar redirecionamento
  setTimeout(() => {
    window.location.href = '/login?fallback=true';
  }, 500);
  
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="flex flex-col items-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="mt-4 text-lg text-gray-600">Redirecionando...</p>
      </div>
    </div>
  );
}