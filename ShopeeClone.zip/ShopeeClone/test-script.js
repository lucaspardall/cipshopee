// Gerar um nome de usuário aleatório para evitar conflitos
const randomUsername = `user_${Math.floor(Math.random() * 10000)}`;

console.log(`Tentando registrar usuário: ${randomUsername}`);

fetch('http://localhost:5000/api/auth/register', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    username: randomUsername,
    password: 'password123',
    email: `${randomUsername}@example.com`
  })
})
.then(response => response.json())
.then(data => {
  console.log('Resposta do registro:', data);
  
  // Tentar fazer login com o novo usuário
  return fetch('http://localhost:5000/api/auth/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      username: randomUsername,
      password: 'password123'
    })
  });
})
.then(response => response.json())
.then(data => {
  console.log('Resposta do login:', data);
})
.catch(error => {
  console.error('Erro:', error);
});